/* =========================================================
   SINCRONIZAÇÃO ENTRE DISPOSITIVOS
   Quando você salva em um celular/computador, os outros aparelhos que estão
   com o app aberto recebem a atualização e recarregam os dados automaticamente.
========================================================= */
let realtimeChannel = null;
let syncing = false;
// Guarda o "lastUpdated" que sabemos estar salvo no servidor, para detectar se outra aba/
// dispositivo salvou algo depois da última vez que sincronizamos aqui (ver checkForRemoteConflict).
let lastSyncedAt = null;

function applyServerState(data){
  if(!data) return;
  const incoming = Object.assign(emptyState(), data);
  // não sobrescreve alterações locais ainda não salvas
  if(dirty){
    showToast('Há dados novos em outro aparelho. Salve ou recarregue a página.', true);
    return;
  }
  if(state && state.lastUpdated && incoming.lastUpdated && incoming.lastUpdated === state.lastUpdated) return;
  const keepSelected = state ? state.selectedMonth : null;
  const keepDashboard = state ? state.dashboardMonth : null;
  state = incoming;
  lastSyncedAt = state.lastUpdated || null;
  if(keepSelected && (state.months||[]).some(m=>m.id===keepSelected)) state.selectedMonth = keepSelected;
  if(keepDashboard && (state.months||[]).some(m=>m.id===keepDashboard)) state.dashboardMonth = keepDashboard;
  undoStack = []; redoStack = []; updateUndoRedoButtons();
  ensureNavConfig();
  renderNav();
  renderSection();
  renderStampAll();
  renderNotifications();
  showToast('atualizado com os dados mais recentes', false);
}

// Confere se o servidor tem uma versão mais nova do que a última que sincronizamos aqui —
// acontece quando outra aba/dispositivo salvou algo enquanto esta aba estava com alterações
// pendentes (que bloqueiam a sincronização automática, ver applyServerState acima).
async function checkForRemoteConflict(){
  if(!lastSyncedAt || !currentSession) return false;
  try{
    const { data, error } = await sb.from('financial_data')
      .select('data').eq('user_id', currentSession.user.id).maybeSingle();
    if(error || !data || !data.data) return false;
    const remoteUpdatedAt = data.data.lastUpdated;
    return !!(remoteUpdatedAt && remoteUpdatedAt !== lastSyncedAt);
  }catch(e){
    return false; // se a checagem falhar, não bloqueia o salvamento por causa disso
  }
}

// Busca no servidor e aplica se houver algo mais novo (usado ao voltar pro app).
async function refreshStateFromServer(){
  if(!currentSession || syncing || saving) return;
  syncing = true;
  try{
    const { data, error } = await sb.from('financial_data')
      .select('data').eq('user_id', currentSession.user.id).maybeSingle();
    if(error) throw error;
    if(data && data.data) applyServerState(data.data);
  }catch(e){ console.error('Falha ao sincronizar', e); }
  finally{ syncing = false; }
}

function startRealtimeSync(){
  if(!sb || !currentSession) return;
  stopRealtimeSync();
  realtimeChannel = sb.channel('financial_data_' + currentSession.user.id)
    .on('postgres_changes', {
      event: '*', schema: 'public', table: 'financial_data',
      filter: 'user_id=eq.' + currentSession.user.id,
    }, (payload)=>{
      if(saving) return;
      if(payload.new && payload.new.data) applyServerState(payload.new.data);
      else refreshStateFromServer();
    })
    .subscribe();

  // rede/aba: sempre que o app volta a ficar visível, confere se há algo mais novo
  document.addEventListener('visibilitychange', onVisibleSync);
  window.addEventListener('focus', onVisibleSync);
  window.addEventListener('online', refreshStateFromServer);
}

function onVisibleSync(){
  if(document.visibilityState === 'visible') refreshStateFromServer();
}

function stopRealtimeSync(){
  if(realtimeChannel){ try{ sb.removeChannel(realtimeChannel); }catch(e){} realtimeChannel = null; }
  document.removeEventListener('visibilitychange', onVisibleSync);
  window.removeEventListener('focus', onVisibleSync);
  window.removeEventListener('online', refreshStateFromServer);
}

async function loadStateFromServer(){
  const userId = currentSession.user.id;
  const { data, error } = await sb.from('financial_data').select('data').eq('user_id', userId).maybeSingle();
  if(error){ console.error(error); state = emptyState(); lastSyncedAt = null; return; }
  if(data && data.data && Object.keys(data.data).length){
    state = Object.assign(emptyState(), data.data);
  } else {
    state = emptyState();
    await sb.from('financial_data').insert({ user_id: userId, data: state });
  }
  lastSyncedAt = state.lastUpdated || null;
}

// O app não salva mais sozinho a cada alteração — só marca que existe algo
// pendente e atualiza os indicadores. O salvamento de fato só acontece
// quando o usuário aperta o botão "Salvar" (ver manualSave()).
function scheduleSave(){
  dirty = true;
  updateSaveIndicators();
}

async function persistState(){
  if(!currentSession) return false;

  // Alguém pode ter salvo em outra aba/aparelho depois da última vez que sincronizamos aqui
  // (isso acontece quando a sincronização automática ficou bloqueada por termos alterações
  // pendentes no momento — ver applyServerState). Sem essa checagem, o upsert abaixo
  // sobrescreveria silenciosamente aquelas mudanças com os dados desta aba.
  if(await checkForRemoteConflict()){
    const ok = confirm('Os dados foram alterados em outro aparelho/aba desde a última vez que sincronizamos aqui. Salvar agora vai sobrescrever essas mudanças.\n\nSalvar mesmo assim?\n\n(Cancelar mantém suas alterações só nesta aba, sem salvar — recarregue a página para ver os dados mais recentes antes de decidir.)');
    if(!ok){
      showToast('Salvamento cancelado. Recarregue a página para ver os dados mais recentes.', true);
      return false;
    }
  }

  state.lastUpdated = new Date().toISOString();
  saving = true;
  updateSaveIndicators();
  try{
    const { error } = await sb.from('financial_data')
      .upsert({ user_id: currentSession.user.id, data: state, updated_at: new Date().toISOString() });
    if(error) throw error;
    dirty = false;
    lastSyncedAt = state.lastUpdated;
    undoStack = []; redoStack = []; // depois de salvar não há mais o que desfazer
    updateUndoRedoButtons();
    showToast('✓ salvo', false);
    renderStampAll();
    renderNotifications();
    return true;
  }catch(e){
    console.error('Falha ao salvar', e);
    showToast('Não foi possível salvar. Verifique sua conexão e tente novamente.', true);
    return false;
  }finally{
    saving = false;
    updateSaveIndicators();
  }
}

// chamado pelo clique nos botões "Salvar" espalhados pela interface
async function manualSave(){
  if(saving) return;
  await persistState();
}

function updateSaveIndicators(){
  document.querySelectorAll('.js-save-btn').forEach(btn=>{
    btn.classList.toggle('is-dirty', dirty && !saving);
    btn.classList.toggle('is-saving', saving);
    btn.disabled = saving;
    const label = btn.querySelector('.js-save-label');
    if(label) label.textContent = saving ? 'salvando…' : (dirty ? 'salvar' : 'salvo');
  });
  updateUndoRedoButtons();
}

// avisa antes de fechar/recarregar a aba se houver alterações não salvas
window.addEventListener('beforeunload', (e)=>{
  if(dirty){ e.preventDefault(); e.returnValue = ''; }
});

function showToast(msg, isError){
  const t = document.getElementById('saveToast');
  t.textContent = msg;
  t.classList.toggle('error', !!isError);
  t.classList.add('show');
  clearTimeout(showToast._t);
  showToast._t = setTimeout(()=>t.classList.remove('show'), isError ? 3200 : 1600);
}

