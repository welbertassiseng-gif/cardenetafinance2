/* =========================================================
   RENDER: CARTEIRA DE INVESTIMENTOS — saldo por item, aporte/retirada com histórico,
   taxa mensal (varia mês a mês) e projeção automática de rendimento.
========================================================= */
let carteiraDetailId = null;
let chartWalletRef = null;
let chartWalletSimRef = null;

function getWallet(){
  if(!state.wallet || typeof state.wallet!=='object') state.wallet = { monthlyGoal:0, items:[] };
  if(!Array.isArray(state.wallet.items)) state.wallet.items = [];
  if(typeof state.wallet.monthlyGoal!=='number') state.wallet.monthlyGoal = Number(state.wallet.monthlyGoal)||0;
  if(!state.wallet.simulator || typeof state.wallet.simulator!=='object'){
    state.wallet.simulator = { saldoInicial:0, aporteMensal:0, taxaMensal:0.5, horizonteAnos:5 };
  }
  return state.wallet;
}
// Simulador "cenário hipotético": juros compostos com aporte mensal fixo, taxa mensal direta (não anual).
function walletSimResult(saldoInicial, aporteMensal, taxaMensalPct, anos){
  const im = (Number(taxaMensalPct)||0)/100;
  const n = Math.max(0, Math.round((Number(anos)||0)*12));
  const growth = Math.pow(1+im, n);
  const fromP = (Number(saldoInicial)||0)*growth;
  const fromPMT = im===0 ? (Number(aporteMensal)||0)*n : (Number(aporteMensal)||0)*((growth-1)/im);
  const valorFinal = fromP+fromPMT;
  const totalAportado = (Number(saldoInicial)||0) + (Number(aporteMensal)||0)*n;
  return { valorFinal, totalAportado, totalRendido: valorFinal-totalAportado, n };
}
function walletSimSeries(saldoInicial, aporteMensal, taxaMensalPct, anos){
  const im = (Number(taxaMensalPct)||0)/100;
  const n = Math.max(0, Math.round((Number(anos)||0)*12));
  const out = [Number(saldoInicial)||0];
  let v = Number(saldoInicial)||0;
  for(let i=0;i<n;i++){ v = v*(1+im) + (Number(aporteMensal)||0); out.push(v); }
  return out;
}
function walletMonthKey(d){ d = d || new Date(); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0'); }
function walletAportadoNoMes(monthKey){
  let total = 0;
  getWallet().items.forEach(it=>{
    (it.history||[]).forEach(h=>{
      if(!h.date || h.date.slice(0,7)!==monthKey) return;
      if(h.tipo==='aporte') total += Number(h.valor)||0;
      else if(h.tipo==='retirada') total -= Number(h.valor)||0;
    });
  });
  return total;
}
// Taxa do mês informada; se não houver, cai pra taxa mais recente já cadastrada (as taxas variam mês a mês).
function walletItemCurrentRate(item, monthKey){
  if(!item.rates) item.rates = {};
  if(typeof item.rates[monthKey]==='number') return item.rates[monthKey];
  const keys = Object.keys(item.rates).sort();
  return keys.length ? item.rates[keys[keys.length-1]] : 0;
}
function nextMonthKey(mk){
  const [y,m] = String(mk).split('-').map(Number);
  const d = new Date(y, (m-1)+1, 1);
  return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0');
}
// aporte/ajuste já entram com o sinal certo no histórico; retirada é guardada como valor positivo.
function walletTxDelta(h){
  const v = Number(h.valor)||0;
  return h.tipo==='retirada' ? -v : v;
}
/* Recalcula o saldo real de um item mês a mês: a taxa registrada num mês rende sobre o que já
   estava investido desde o mês anterior; o dinheiro que entra (ou sai) num mês só passa a render
   a partir do mês seguinte. Assim a taxa fica "amarrada" ao aporte que a originou — em vez do
   modelo antigo, que pegava a taxa do mês corrente e a aplicava sobre o saldo acumulado inteiro,
   inflando a projeção com juros que o dinheiro recém-aportado nunca chegou a render.
   Meses sem taxa registrada carregam a última taxa conhecida até então (nunca uma taxa futura). */
function walletItemAccruedBalance(item, uptoMonthKey){
  uptoMonthKey = uptoMonthKey || walletMonthKey();
  const history = Array.isArray(item.history) ? item.history : [];
  if(!history.length) return Number(item.saldo)||0;
  const rates = item.rates || {};
  const byMonth = {};
  history.forEach(h=>{
    if(!h.date) return;
    const mk = h.date.slice(0,7);
    byMonth[mk] = (byMonth[mk]||0) + walletTxDelta(h);
  });
  const months = Object.keys(byMonth).sort();
  if(!months.length) return Number(item.saldo)||0;
  let cursor = months[0];
  let balance = 0;
  let lastRate = 0;
  let guard = 0;
  while(cursor <= uptoMonthKey && guard < 2400){
    if(typeof rates[cursor]==='number') lastRate = rates[cursor];
    if(balance !== 0) balance = balance * (1 + lastRate/100);
    balance += (byMonth[cursor]||0);
    cursor = nextMonthKey(cursor);
    guard++;
  }
  return balance;
}
// Atualiza o saldo de cada item da carteira para o valor realmente acumulado (histórico + juros
// mês a mês), em vez do simples somatório de aportes. Chamar sempre antes de exibir/projetar.
function refreshWalletBalances(){
  const w = getWallet();
  const mk = walletMonthKey();
  w.items.forEach(it=>{ it.saldo = walletItemAccruedBalance(it, mk); });
}
function walletProjection(saldo, ratePctMonth, months){
  const r = (Number(ratePctMonth)||0)/100;
  const out = [saldo];
  let v = saldo;
  for(let i=0;i<months;i++){ v = v*(1+r); out.push(v); }
  return out;
}
function brDate(iso){
  if(!iso) return '';
  const parts = String(iso).slice(0,10).split('-');
  return parts.length===3 ? `${parts[2]}/${parts[1]}/${parts[0]}` : iso;
}

function renderCarteira(){
  refreshWalletBalances();
  return carteiraDetailId ? renderCarteiraDetail(carteiraDetailId) : renderCarteiraOverview();
}

function renderCarteiraOverview(){
  const el = document.createElement('div');
  const w = getWallet();
  const totalSaldo = w.items.reduce((s,it)=>s+(Number(it.saldo)||0),0);
  const mk = walletMonthKey();
  const aportadoMes = walletAportadoNoMes(mk);
  const goal = Number(w.monthlyGoal)||0;
  const pct = goal>0 ? Math.min(100, Math.max(0,(aportadoMes/goal)*100)) : 0;

  el.innerHTML = `
    <div class="page-header">
      <div><h2>Carteira de Investimentos ${eyeToggleBtn()}</h2><div class="desc">Saldo de cada investimento/reserva, aportes e retiradas com histórico, e projeção automática de rendimento a partir da taxa mensal de cada item.</div></div>
      <button class="btn gold" id="btnAddWalletItem">+ novo item</button>
    </div>
    <div class="stat pos"><div class="label">Total investido/reservado</div><div class="value mono">${fmtPriv(totalSaldo)}</div></div>
    <div class="card" style="margin-top:22px;">
      <div style="display:flex; justify-content:space-between; align-items:center; gap:10px;">
        <h3 style="margin:0;">Meta de investimento este mês</h3>
        <button class="icon-btn" id="btnEditGoal" title="editar meta">✎</button>
      </div>
      <div class="value mono" style="font-size:22px; margin-top:8px;">${fmtPriv(aportadoMes)} <span style="font-size:13px; color:var(--ink-soft); font-weight:400;">de ${fmtPriv(goal)}</span></div>
      <div style="background:var(--paper-dark); border-radius:20px; height:8px; margin-top:10px; overflow:hidden;">
        <div style="background:var(--forest); height:100%; width:${pct}%; border-radius:20px;"></div>
      </div>
    </div>
    <div id="walletItemsList"></div>
    <div class="card">
      <h3>Rendimento e projeção</h3>
      ${!w.items.length ? `<div class="empty-state">Adicione ao menos um item pra ver a projeção.</div>` : `
        <div class="chart-wrap" id="walletChartWrap">
          <div class="chart-skeleton" id="walletChartSkeleton">
            <div class="skel-bars"><span></span><span></span><span></span><span></span><span></span></div>
            <div class="skel-label">carregando gráfico…</div>
          </div>
          <canvas id="chartWallet" style="display:none;"></canvas>
        </div>
      `}
    </div>
    <div class="card">
      <h3>Simular cenário hipotético</h3>
      <div class="desc" style="margin-bottom:16px;">Um teste à parte, sem mexer na sua carteira real — informe saldo, aporte e taxa mensal pra ver aonde chegam num horizonte de anos.</div>
      <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(120px,1fr)); gap:14px; margin-bottom:18px;">
        <div>
          <label style="display:block; font-size:10.5px; text-transform:uppercase; letter-spacing:0.05em; color:var(--ink-soft); font-family:'JetBrains Mono',monospace; margin-bottom:5px;">Saldo inicial</label>
          <input type="text" inputmode="decimal" class="money" id="simSaldoInicial" style="width:100%;">
        </div>
        <div>
          <label style="display:block; font-size:10.5px; text-transform:uppercase; letter-spacing:0.05em; color:var(--ink-soft); font-family:'JetBrains Mono',monospace; margin-bottom:5px;">Aporte mensal</label>
          <input type="text" inputmode="decimal" class="money" id="simAporteMensal" style="width:100%;">
        </div>
        <div>
          <label style="display:block; font-size:10.5px; text-transform:uppercase; letter-spacing:0.05em; color:var(--ink-soft); font-family:'JetBrains Mono',monospace; margin-bottom:5px;">Taxa mensal (%)</label>
          <input type="text" inputmode="decimal" class="money" id="simTaxaMensal" style="width:100%;">
        </div>
        <div>
          <label style="display:block; font-size:10.5px; text-transform:uppercase; letter-spacing:0.05em; color:var(--ink-soft); font-family:'JetBrains Mono',monospace; margin-bottom:5px;">Horizonte (anos)</label>
          <input type="text" inputmode="decimal" class="money" id="simHorizonteAnos" style="width:100%;">
        </div>
      </div>
      <div class="chart-wrap" id="simChartWrap" style="height:220px;">
        <canvas id="chartWalletSim"></canvas>
      </div>
      <div class="grid-3" style="margin-top:18px;">
        <div class="stat pos"><div class="label">Valor final</div><div class="value mono" id="sim-valor-final"></div></div>
        <div class="stat"><div class="label">Total aportado</div><div class="value mono" id="sim-total-aportado"></div></div>
        <div class="stat pos"><div class="label">Total rendido</div><div class="value mono" id="sim-total-rendido"></div></div>
      </div>
    </div>
  `;

  const listEl = el.querySelector('#walletItemsList');
  if(!w.items.length){
    listEl.innerHTML = `<div class="card"><div class="empty-state">Nenhum item na carteira ainda. Clique em "+ novo item" para adicionar um investimento ou reserva.</div></div>`;
  } else {
    w.items.forEach(it=>{
      const card = document.createElement('div');
      card.className = 'card';
      card.style.cssText = 'margin-top:14px; cursor:pointer;';
      card.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:14px;">
          <div>
            <div style="font-weight:600; font-size:15.5px;">${escapeHtml(it.nome||'(sem nome)')}</div>
            <div style="font-size:12px; color:var(--ink-soft); text-transform:uppercase; letter-spacing:0.04em; font-family:'JetBrains Mono',monospace;">${it.tipo==='reserva'?'Reserva':'Investimento'}</div>
          </div>
          <div class="value mono" style="font-size:19px;">${fmtPriv(it.saldo)}</div>
        </div>
        <div style="display:flex; gap:10px; margin-top:12px; flex-wrap:wrap;">
          <button class="btn small secondary" data-role="updbal">Atualizar saldo</button>
          <button class="btn small link" data-role="detail">Aporte / retirada / histórico →</button>
        </div>
      `;
      card.querySelector('[data-role=updbal]').addEventListener('click', (e)=>{
        e.stopPropagation();
        const val = prompt(`Novo saldo de "${it.nome}":`, moneyDisplay(it.saldo||0));
        if(val===null) return;
        const num = parseMoney(val);
        if(!Array.isArray(it.history)) it.history=[];
        it.history.push({id:uid(), date:new Date().toISOString().slice(0,10), tipo:'ajuste', valor:num-(Number(it.saldo)||0), nota:'Saldo atualizado manualmente'});
        it.saldo = num;
        scheduleSave(); renderSection();
      });
      card.querySelector('[data-role=detail]').addEventListener('click', (e)=>{
        e.stopPropagation();
        carteiraDetailId = it.id;
        renderSection();
      });
      card.addEventListener('click', ()=>{ carteiraDetailId = it.id; renderSection(); });
      listEl.appendChild(card);
    });
  }

  el.querySelector('#btnAddWalletItem').addEventListener('click', ()=>{
    const nome = prompt('Nome do investimento/reserva (ex: Tesouro IPCA+, Caixinha Nubank):');
    if(!nome || !nome.trim()) return;
    let tipo = (prompt('Tipo: digite "investimento" ou "reserva"', 'investimento')||'investimento').trim().toLowerCase();
    tipo = tipo.startsWith('res') ? 'reserva' : 'investimento';
    w.items.push({id:uid(), nome:nome.trim(), tipo, saldo:0, rates:{}, history:[]});
    scheduleSave(); renderSection();
  });
  el.querySelector('#btnEditGoal').addEventListener('click', ()=>{
    const val = prompt('Meta de aporte para este mês:', moneyDisplay(goal));
    if(val===null) return;
    w.monthlyGoal = parseMoney(val);
    scheduleSave(); renderSection();
  });

  const sim = w.simulator;
  const updateSimStats = ()=>{
    const r = walletSimResult(sim.saldoInicial, sim.aporteMensal, sim.taxaMensal, sim.horizonteAnos);
    const vf = el.querySelector('#sim-valor-final'); if(vf) vf.textContent = fmt(r.valorFinal);
    const ta = el.querySelector('#sim-total-aportado'); if(ta) ta.textContent = fmt(r.totalAportado);
    const tr = el.querySelector('#sim-total-rendido'); if(tr) tr.textContent = fmt(r.totalRendido);
  };
  [['simSaldoInicial','saldoInicial'],['simAporteMensal','aporteMensal'],['simTaxaMensal','taxaMensal'],['simHorizonteAnos','horizonteAnos']].forEach(([id,key])=>{
    const input = el.querySelector('#'+id);
    bindMoneyInput(input, ()=>sim[key], v=>{ sim[key]=v; }, ()=>{ updateSimStats(); drawWalletSimChart(); });
  });
  updateSimStats();

  bindEyeToggles(el);
  return el;
}

function renderCarteiraDetail(itemId){
  const w = getWallet();
  const it = w.items.find(i=>i.id===itemId);
  if(!it){ carteiraDetailId = null; return renderCarteiraOverview(); }
  if(!Array.isArray(it.history)) it.history = [];
  if(!it.rates) it.rates = {};
  const mk = walletMonthKey();
  const el = document.createElement('div');

  el.innerHTML = `
    <div class="page-header">
      <div>
        <div class="btn link" id="btnBackWallet" style="padding:0; margin-bottom:6px;">‹ Carteira de Investimentos</div>
        <h2>${escapeHtml(it.nome)} ${eyeToggleBtn()}</h2>
      </div>
      <button class="icon-btn" id="btnRenameItem" title="renomear">✎</button>
    </div>
    <div class="stat pos"><div class="label">Investimento</div><div class="value mono">${fmtPriv(it.saldo)}</div></div>
    <div class="card" style="margin-top:22px;">
      <h3>Taxa mensal (%)</h3>
      <div class="desc" style="margin-bottom:10px;">As taxas variam de mês a mês — informe a taxa de ${PT_MONTH_NAMES[new Date().getMonth()]} e a projeção abaixo recalcula automaticamente.</div>
      <input type="text" inputmode="decimal" class="money" id="itemRateInput" style="max-width:140px;">
    </div>
    <div class="card">
      <h3>Aporte / retirada</h3>
      <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
        <select id="txTipo" style="max-width:130px;">
          <option value="aporte">Aporte</option>
          <option value="retirada">Retirada</option>
        </select>
        <input type="text" inputmode="decimal" class="money" id="txValor" placeholder="valor do aporte" style="max-width:160px;">
        <input type="date" id="txData">
        <input type="text" id="txNota" placeholder="nota (opcional)" style="flex:1; min-width:140px;">
        <button class="btn gold small" id="btnTxOk">OK</button>
      </div>
    </div>
    <div class="card">
      <h3>Rendimento e projeção</h3>
      <div class="chart-wrap" id="walletChartWrap">
        <div class="chart-skeleton" id="walletChartSkeleton">
          <div class="skel-bars"><span></span><span></span><span></span><span></span><span></span></div>
          <div class="skel-label">carregando gráfico…</div>
        </div>
        <canvas id="chartWallet" style="display:none;"></canvas>
      </div>
    </div>
    <div class="card">
      <h3>Histórico completo</h3>
      <div id="walletHistList"></div>
    </div>
  `;

  el.querySelector('#btnBackWallet').addEventListener('click', ()=>{ carteiraDetailId = null; renderSection(); });
  el.querySelector('#btnRenameItem').addEventListener('click', ()=>{
    const novo = prompt('Renomear item:', it.nome);
    if(novo && novo.trim()){ it.nome = novo.trim(); scheduleSave(); renderSection(); }
  });

  const rateInput = el.querySelector('#itemRateInput');
  bindMoneyInput(rateInput, ()=>walletItemCurrentRate(it, mk), v=>{ it.rates[mk]=v; }, ()=>{ scheduleSave(); drawWalletChart(); });

  el.querySelector('#txData').value = new Date().toISOString().slice(0,10);
  el.querySelector('#btnTxOk').addEventListener('click', ()=>{
    const tipo = el.querySelector('#txTipo').value;
    const valor = parseMoney(el.querySelector('#txValor').value);
    const data = el.querySelector('#txData').value || new Date().toISOString().slice(0,10);
    const nota = el.querySelector('#txNota').value.trim();
    if(!valor || valor<=0){ alert('Informe um valor válido.'); return; }
    it.history.push({id:uid(), date:data, tipo, valor, nota});
    it.saldo = (Number(it.saldo)||0) + (tipo==='aporte' ? valor : -valor);
    scheduleSave();
    renderSection();
  });

  const histEl = el.querySelector('#walletHistList');
  const sorted = [...it.history].sort((a,b)=>(b.date||'').localeCompare(a.date||''));
  if(!sorted.length){
    histEl.innerHTML = `<div class="empty-state">Nenhuma movimentação registrada ainda.</div>`;
  } else {
    sorted.forEach(h=>{
      const row = document.createElement('div');
      row.style.cssText = 'display:flex; justify-content:space-between; align-items:center; gap:10px; padding:9px 0; border-bottom:1px solid var(--paper-line);';
      const negativo = h.tipo==='retirada' || (h.tipo==='ajuste' && h.valor<0);
      const rotulo = h.tipo==='aporte' ? 'Aporte' : h.tipo==='retirada' ? 'Retirada' : 'Ajuste de saldo';
      row.innerHTML = `
        <div>
          <div style="font-size:13.5px;">${brDate(h.date)} · ${rotulo}</div>
          ${h.nota ? `<div style="font-size:12px; color:var(--ink-soft);">${escapeHtml(h.nota)}</div>` : ''}
        </div>
        <div style="display:flex; align-items:center; gap:10px;">
          <div class="mono" style="color:${negativo?'var(--rust)':'var(--forest)'}; font-weight:600;">${negativo?'-':'+'} ${fmtPriv(Math.abs(h.valor))}</div>
          <button class="icon-btn" data-role="delh" title="excluir">✕</button>
        </div>
      `;
      row.querySelector('[data-role=delh]').addEventListener('click', ()=>{
        let delta = 0;
        if(h.tipo==='aporte') delta = -h.valor;
        else if(h.tipo==='retirada') delta = h.valor;
        else delta = -h.valor;
        it.saldo = (Number(it.saldo)||0) + delta;
        it.history = it.history.filter(x=>x.id!==h.id);
        scheduleSave(); renderSection();
      });
      histEl.appendChild(row);
    });
  }

  bindEyeToggles(el);
  return el;
}

function drawWalletChart(){
  const canvas = document.getElementById('chartWallet');
  const skeleton = document.getElementById('walletChartSkeleton');
  if(!canvas) return;
  if(privacyMode){ // modo privado: ocultar projeção da carteira
    if(chartWalletRef){ chartWalletRef.destroy(); chartWalletRef = null; }
    canvas.style.display = 'none';
    if(skeleton){ skeleton.style.display = 'flex'; skeleton.innerHTML = `<div class="empty-state" style="padding:44px 16px;">🔒 Valores ocultos — toque no olhinho para mostrar o gráfico.</div>`; }
    return;
  }
  try{
    if(typeof Chart === 'undefined') throw new Error('Chart.js indisponível');
    const w = getWallet();
    const mk = walletMonthKey();
    const months = 12;
    let labels, dataset, seriesLabel;
    if(carteiraDetailId){
      const it = w.items.find(i=>i.id===carteiraDetailId);
      if(!it) throw new Error('item não encontrado');
      const rate = walletItemCurrentRate(it, mk);
      dataset = walletProjection(Number(it.saldo)||0, rate, months);
      seriesLabel = it.nome;
    } else {
      const series = new Array(months+1).fill(0);
      w.items.forEach(it=>{
        const rate = walletItemCurrentRate(it, mk);
        walletProjection(Number(it.saldo)||0, rate, months).forEach((v,i)=>{ series[i]+=v; });
      });
      dataset = series;
      seriesLabel = 'Patrimônio projetado';
    }
    labels = dataset.map((_,i)=> i===0 ? 'hoje' : `+${i}m`);

    if(chartWalletRef){ chartWalletRef.destroy(); chartWalletRef = null; }
    const ctx = canvas.getContext('2d');
    chartWalletRef = new Chart(ctx, {
      type:'line',
      data:{ labels, datasets:[{ label:seriesLabel, data:dataset, borderColor:'#3B82F6', backgroundColor:'rgba(59,130,246,0.10)', borderWidth:2, borderDash:[5,4], tension:0.25, fill:true, pointRadius:0 }] },
      options:{ responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}}, scales:{ y:{ ticks:{ callback:v=>fmt(v) } } } }
    });
    canvas.style.display = 'block';
    if(skeleton) skeleton.style.display = 'none';
  }catch(err){
    console.error('Erro ao renderizar gráfico da carteira:', err);
    if(skeleton) skeleton.innerHTML = `<div class="empty-state">Não foi possível carregar o gráfico agora. Recarregue a página.</div>`;
  }
}

function drawWalletSimChart(){
  const canvas = document.getElementById('chartWalletSim');
  if(!canvas) return; // só existe na visão geral da carteira
  const simWrap = document.getElementById('simChartWrap');
  if(privacyMode){ // modo privado: ocultar simulação
    if(chartWalletSimRef){ chartWalletSimRef.destroy(); chartWalletSimRef = null; }
    canvas.style.display = 'none';
    if(simWrap && !simWrap.querySelector('.chart-privacy-note')){
      simWrap.insertAdjacentHTML('beforeend', `<div class="empty-state chart-privacy-note" style="height:100%%; display:flex; align-items:center; justify-content:center;">🔒 Valores ocultos — toque no olhinho para mostrar o gráfico.</div>`);
    }
    return;
  }
  const privNote = simWrap ? simWrap.querySelector('.chart-privacy-note') : null;
  if(privNote) privNote.remove();
  canvas.style.display = 'block';
  try{
    if(typeof Chart === 'undefined') throw new Error('Chart.js indisponível');
    const sim = getWallet().simulator;
    const dataset = walletSimSeries(sim.saldoInicial, sim.aporteMensal, sim.taxaMensal, sim.horizonteAnos);
    const n = dataset.length - 1;
    const stepYears = sim.horizonteAnos > 6; // com horizontes longos, rotula por ano pra não poluir o eixo
    const labels = dataset.map((_,i)=>{
      if(i===0) return 'hoje';
      if(stepYears) return i%12===0 ? `${i/12}a` : '';
      return `+${i}m`;
    });
    if(chartWalletSimRef){ chartWalletSimRef.destroy(); chartWalletSimRef = null; }
    const ctx = canvas.getContext('2d');
    chartWalletSimRef = new Chart(ctx, {
      type:'line',
      data:{ labels, datasets:[{ label:'Cenário simulado', data:dataset, borderColor:'#60A5FA', backgroundColor:'rgba(96,165,250,0.12)', borderWidth:2, borderDash:[5,4], tension:0.25, fill:true, pointRadius:0 }] },
      options:{ responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}}, scales:{ x:{ ticks:{ autoSkip:!stepYears, maxRotation:0 } }, y:{ ticks:{ callback:v=>fmt(v) } } } }
    });
  }catch(err){
    console.error('Erro ao renderizar gráfico do simulador:', err);
  }
}

