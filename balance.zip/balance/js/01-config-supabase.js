/* =========================================================
   CONFIGURAÇÃO DO SUPABASE
   Preencha com os dados do SEU projeto (Project Settings > API).
   Sem isso, o site não consegue entrar, cadastrar ou salvar nada.
========================================================= */
const SUPABASE_URL = "https://apcspognnfymkemmqyzd.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_3EVv-sQvRcQAoebiCoUdFw_2FtXb_I8";

const supabaseConfigured = SUPABASE_URL.startsWith('http') && SUPABASE_ANON_KEY.length > 20;
// Além de configurado, o SDK do Supabase precisa ter realmente carregado do CDN — se a rede
// falhar, for bloqueada por firewall/ad-blocker, ou o CDN cair, `window.supabase` não existe
// e chamar createClient() direto quebraria o script inteiro com uma exceção não tratada.
let supabaseLoadError = false;
let sb = null;
if(supabaseConfigured){
  if(typeof window.supabase !== 'undefined' && typeof window.supabase.createClient === 'function'){
    try{ sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY); }
    catch(e){ console.error('Falha ao iniciar o Supabase', e); supabaseLoadError = true; }
  } else {
    supabaseLoadError = true;
  }
}
const supabaseReady = supabaseConfigured && !!sb;

/* ---------- Endereço de retorno dos e-mails (convite / recuperar senha) ----------
   O Supabase só abre o link do e-mail se este endereço estiver cadastrado em
   Authentication > URL Configuration (campos "Site URL" e "Redirect URLs").
   SITE_URL vazio = usa o endereço da página atual. Se você publica o app sempre no mesmo
   endereço, coloque ele aqui (ex.: "https://meuapp.netlify.app/") para o link do e-mail de
   "Esqueci minha senha" nunca apontar para um endereço de teste/prévia. */
const SITE_URL = "";
function getRedirectUrl(){
  return (SITE_URL || window.location.href).split('#')[0].split('?')[0];
}
