/* =========================================================
   RENDER: INVESTIMENTOS
========================================================= */
function renderInvestimentos(sectionId){
  sectionId = sectionId || 'investimentos';
  const el = document.createElement('div');
  const cfg = state.navConfig.find(n=>n.id===sectionId);
  const title = cfg ? cfg.label : 'Investimentos';
  const list = getInvArray(sectionId);
  const totalBaixa = investmentsTotal(sectionId, false);
  const totalAlta = investmentsTotal(sectionId, true);
  const totalAporte = list.reduce((s,i)=>s+(Number(i.valorInicial)||Number(i.valorFixo)||0),0);

  el.innerHTML = `
    <div class="page-header">
      <div><h2>${escapeHtml(title)} ${eyeToggleBtn()}</h2><div class="desc">Informe valor inicial, aporte mensal, prazo e taxa — o valor futuro é calculado automaticamente (juros compostos), em dois cenários de taxa.</div></div>
    </div>
    <div class="grid-3">
      <div class="stat"><div class="label">Total investido/aportado hoje</div><div class="value mono" id="stat-inv-aportado">${fmtPriv(totalAporte)}</div></div>
      <div class="stat pos"><div class="label">Projeção · taxa conservadora</div><div class="value mono" id="stat-inv-baixa">${fmtPriv(totalBaixa)}</div></div>
      <div class="stat pos"><div class="label">Projeção · taxa otimista</div><div class="value mono" id="stat-inv-alta">${fmtPriv(totalAlta)}</div></div>
    </div>
    <div class="card" style="margin-top:22px;">
      <h3>Carteira</h3>
      <div class="table-wrap"><table class="responsive-table">
        <thead><tr>
          <th>Nome</th><th style="width:110px">Tipo</th>
          <th class="num" style="width:100px">Inicial</th>
          <th class="num" style="width:90px">Aporte/mês</th>
          <th class="num" style="width:70px">Anos</th>
          <th class="num" style="width:80px">Taxa a.a. baixa</th>
          <th class="num" style="width:80px">Taxa a.a. alta</th>
          <th class="num" style="width:130px">Valor projetado</th>
          <th style="width:50px"></th>
        </tr></thead>
        <tbody id="invBody"></tbody>
        <tfoot>
          <tr class="total-row"><td colspan="7">TOTAL (conservador / otimista)</td><td class="num" data-label="Total" id="inv-total-cell">${fmtPriv(totalBaixa)}<br><span style="opacity:0.75; font-size:12px;">${fmtPriv(totalAlta)}</span></td><td></td></tr>
        </tfoot>
      </table></div>
      <button class="btn secondary small" id="btnAddInv" style="margin-top:14px;">+ novo item</button>
      <div class="small-note">Fórmula: valor futuro = inicial × (1+taxa mensal)^meses + aporte × [((1+taxa mensal)^meses − 1) ÷ taxa mensal], com a taxa mensal derivada da taxa anual informada.</div>
    </div>
  `;
  bindEyeToggles(el);
  const body = el.querySelector('#invBody');
  if(list.length===0){
    body.innerHTML = `<tr><td colspan="9"><div class="empty-state">Nenhum investimento cadastrado ainda. Clique em "+ novo item" para começar.</div></td></tr>`;
  }
  const recalc = ()=>recalcInvestimentos(sectionId);
  list.forEach((inv,i)=>{
    const isFixo = inv.tipo==='fixo';
    const projBaixa = investmentValue(inv,false);
    const projAlta = investmentValue(inv,true);
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="cell-plain"><input type="text" value="${escAttr(inv.nome)}" data-role="nome"></td>
      <td data-label="Tipo">
        <select data-role="tipo">
          <option value="rendimento" ${!isFixo?'selected':''}>Rende juros</option>
          <option value="fixo" ${isFixo?'selected':''}>Valor fixo</option>
        </select>
      </td>
      ${isFixo ? `
        <td class="num" colspan="4" data-label="Valor fixo"><input type="text" inputmode="decimal" class="money" data-role="valorFixo" placeholder="valor fixo"></td>
      ` : `
        <td class="num" data-label="Inicial"><input type="text" inputmode="decimal" class="money" data-role="valorInicial"></td>
        <td class="num" data-label="Aporte/mês"><input type="text" inputmode="decimal" class="money" data-role="aporteMensal"></td>
        <td class="num" data-label="Anos"><input type="text" inputmode="decimal" class="money" data-role="anos"></td>
        <td class="num" data-label="Taxa baixa"><input type="text" inputmode="decimal" class="money" data-role="taxaBaixa"></td>
        <td class="num" data-label="Taxa alta"><input type="text" inputmode="decimal" class="money" data-role="taxaAlta"></td>
      `}
      <td class="num mono" data-label="Projetado" id="inv-proj-${i}" style="font-weight:600;">${fmtPriv(projBaixa)}${!isFixo?`<br><span style="opacity:0.6; font-size:11.5px;">${fmtPriv(projAlta)}</span>`:''}</td>
      <td><button class="icon-btn" data-role="del">✕</button></td>
    `;
    tr.querySelector('[data-role=nome]').addEventListener('input', e=>{ inv.nome=e.target.value; scheduleSave(); });
    tr.querySelector('[data-role=tipo]').addEventListener('change', e=>{
      inv.tipo = e.target.value;
      if(inv.tipo==='fixo' && inv.valorFixo===undefined) inv.valorFixo = inv.valorInicial||0;
      if(inv.tipo==='rendimento' && inv.valorInicial===undefined){ inv.valorInicial=inv.valorFixo||0; inv.aporteMensal=0; inv.anos=1; inv.taxaBaixa=6; inv.taxaAlta=12.5; }
      scheduleSave(); renderSection();
    });
    tr.querySelector('[data-role=del]').addEventListener('click', ()=>{ list.splice(i,1); scheduleSave(); renderSection(); });
    const sensitiveRoles = ['valorFixo','valorInicial','aporteMensal'];
    ['valorFixo','valorInicial','aporteMensal','anos','taxaBaixa','taxaAlta'].forEach(role=>{
      const input = tr.querySelector(`[data-role=${role}]`);
      if(input){
        if(sensitiveRoles.includes(role)) bindMoneyInputPriv(input, ()=>inv[role], v=>inv[role]=v, recalc);
        else bindMoneyInput(input, ()=>inv[role], v=>inv[role]=v, recalc);
      }
    });
    body.appendChild(tr);
  });
  el.querySelector('#btnAddInv').addEventListener('click', ()=>{
    list.push({id:uid(), nome:'', tipo:'rendimento', valorInicial:0, aporteMensal:0, anos:1, taxaBaixa:6, taxaAlta:12.5, obs:''});
    scheduleSave(); renderSection();
  });

  return el;
}
function recalcInvestimentos(sectionId){
  const list = getInvArray(sectionId);
  list.forEach((inv,i)=>{
    const cell = document.getElementById('inv-proj-'+i);
    if(cell){
      const projBaixa = investmentValue(inv,false);
      const projAlta = investmentValue(inv,true);
      const isFixo = inv.tipo==='fixo';
      cell.innerHTML = fmtPriv(projBaixa) + (!isFixo? `<br><span style="opacity:0.6; font-size:11.5px;">${fmtPriv(projAlta)}</span>` : '');
    }
  });
  const totalBaixa = investmentsTotal(sectionId, false);
  const totalAlta = investmentsTotal(sectionId, true);
  const totalAporte = list.reduce((s,i)=>s+(Number(i.valorInicial)||Number(i.valorFixo)||0),0);
  const a = document.getElementById('stat-inv-aportado'); if(a) a.textContent = fmtPriv(totalAporte);
  const b = document.getElementById('stat-inv-baixa'); if(b) b.textContent = fmtPriv(totalBaixa);
  const c = document.getElementById('stat-inv-alta'); if(c) c.textContent = fmtPriv(totalAlta);
  const t = document.getElementById('inv-total-cell'); if(t) t.innerHTML = fmtPriv(totalBaixa) + `<br><span style="opacity:0.75; font-size:12px;">${fmtPriv(totalAlta)}</span>`;
}

