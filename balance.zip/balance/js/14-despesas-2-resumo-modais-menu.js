/* ---------- resumo do mês (anel/donut já existente + indicadores) ---------- */
function gxSummaryHTML(month){
  const total = monthTotal(month);
  const txs = gxTx([month]);
  const cats = (month.categories||[]).map(c=>({c, t:categoryTotal(c)})).filter(x=>x.t>0).sort((a,b)=>b.t-a.t);
  const top = cats[0];
  const rank = monthLabelRank(month.label);
  let cmp = null;
  if(rank!==null){
    const prev = (state.months||[]).filter(m=>m!==month && monthLabelRank(m.label)===rank-1);
    if(prev.length){ const pt = prev.reduce((s,m)=>s+monthTotal(m),0); if(pt>0 && total>0) cmp = (total-pt)/pt*100; }
  }
  const third = cmp===null
    ? `<div class="stat"><div class="label">Categorias com gasto</div><div class="value mono">${cats.length}</div></div>`
    : `<div class="stat ${cmp>0?'neg':'pos'}"><div class="label">vs. mês anterior${rank===currentMonthRank()?' (parcial)':''}</div><div class="value mono">${cmp>0?'+':''}${Math.round(cmp)}%</div></div>`;
  return `
    <div class="summary-total-row">
      <div>
        <div class="summary-total-value mono">${fmt(total)}</div>
        <div class="summary-total-label">total gasto</div>
      </div>
      ${buildCategoryRing(month.categories, total)}
    </div>
    <div class="gx-stats">
      <div class="stat"><div class="label">Transações</div><div class="value mono">${txs.length}</div></div>
      <div class="stat"><div class="label" title="${top?escAttr(top.c.name):''}">${top ? 'Maior · '+escapeHtml(top.c.name||'Sem nome') : 'Maior categoria'}</div><div class="value mono">${top ? fmt(top.t) : '—'}</div></div>
      ${third}
    </div>`;
}
function gxRefreshSummary(){
  const card = document.querySelector('.month-summary-card');
  const month = gxSelMonth();
  if(card && month) card.innerHTML = gxSummaryHTML(month);
}

/* ---------- modal genérico ---------- */
function gxModal(html){
  const ov = document.createElement('div');
  ov.className = 'modal-overlay open gx-overlay';
  ov.innerHTML = `<div class="modal-card gx-modal" role="dialog" aria-modal="true">${html}</div>`;
  document.body.appendChild(ov);
  const onKey = e=>{ if(e.key==='Escape') close(); };
  const close = ()=>{
    document.removeEventListener('keydown', onKey);
    ov.classList.add('closing');
    setTimeout(()=>ov.remove(), 160);
  };
  ov.addEventListener('mousedown', e=>{ if(e.target===ov) close(); });
  document.addEventListener('keydown', onKey);
  ov.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click', close));
  return {el:ov.firstElementChild, close};
}
function gxSetErr(m, msg){ const e = m.el.querySelector('.gx-err'); if(e) e.textContent = msg||''; }
function gxBindMoney(input){
  input.addEventListener('blur', ()=>{ if(input.value.trim()) input.value = moneyDisplay(parseMoney(input.value)); });
}


/* ---------- clique no anel: gráfico ampliado com % por categoria ---------- */
function gxShowRingModal(){
  const month = gxSelMonth();
  if(!month) return;
  const total = monthTotal(month);
  const list = (month.categories||[]).map((c,i)=>({name:c.name||'Sem nome', val:categoryTotal(c), color:catColor(c,i)}))
    .filter(x=>x.val>0).sort((a,b)=>b.val-a.val);
  if(!total || !list.length){
    const m = gxModal(`<h3>Despesas por categoria</h3><p class="settings-desc">Ainda não há despesas lançadas neste mês.</p><div class="gx-modal-actions"><button class="btn secondary" data-close>Fechar</button></div>`);
    return m;
  }
  const r=50, cx=60, cy=60, C=2*Math.PI*r, sw=18;
  let cursor=0;
  const arcs = list.map(x=>{
    const frac=x.val/total, sweep=frac*360, start=cursor; cursor+=sweep;
    const gap = list.length>1 ? 2 : 0;
    const segLen=Math.max((sweep-gap)/360*C,0);
    x.frac=frac;
    return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${x.color}" stroke-width="${sw}" stroke-dasharray="${segLen.toFixed(2)} ${(C-segLen).toFixed(2)}" transform="rotate(${(start-90).toFixed(2)} ${cx} ${cy})"/>`;
  });
  const labels = list.map((x,i)=>{
    const before = list.slice(0,i).reduce((s,y)=>s+y.frac,0);
    const mid=((before+x.frac/2)*360-90)*Math.PI/180;
    const px=cx+r*Math.cos(mid), py=cy+r*Math.sin(mid)+3;
    return x.frac>=0.06 ? `<text class="rb-pct" x="${px.toFixed(2)}" y="${py.toFixed(2)}" text-anchor="middle">${Math.round(x.frac*100)}%</text>` : '';
  }).join('');
  const svg = `<svg viewBox="0 0 120 120" class="ring-big" role="img" aria-label="Porcentagem das despesas por categoria">${arcs.join('')}${labels}<text class="rb-total" x="60" y="59" text-anchor="middle">${escapeHtml(fmt(total))}</text><text class="rb-sub" x="60" y="67" text-anchor="middle">total gasto</text></svg>`;
  const legend = list.map(x=>{
    const p = x.frac*100;
    const pt = (p>0 && p<1) ? '<1%' : Math.round(p)+'%';
    return `<div class="ring-leg-row"><span class="ring-leg-dot" style="background:${x.color}"></span><span class="ring-leg-name" title="${escAttr(x.name)}">${escapeHtml(x.name)}</span><span class="ring-leg-val">${escapeHtml(fmt(x.val))}</span><span class="ring-leg-pct">${pt}</span></div>`;
  }).join('');
  return gxModal(`<h3>Despesas por categoria</h3><p class="settings-desc">${escapeHtml(month.label||'')} · quanto cada categoria pesa no total</p>${svg}<div class="ring-legend">${legend}</div><div class="gx-modal-actions"><button class="btn secondary" data-close>Fechar</button></div>`);
}
document.addEventListener('click', (e)=>{
  const ring = e.target.closest && e.target.closest('.summary-ring');
  if(ring) gxShowRingModal();
});
document.addEventListener('keydown', (e)=>{
  if((e.key==='Enter' || e.key===' ') && e.target.classList && e.target.classList.contains('summary-ring')){ e.preventDefault(); gxShowRingModal(); }
});

/* ---------- menu de três pontos ---------- */
let gxMenuEl = null;
function gxCloseMenu(){
  if(gxMenuEl){ gxMenuEl.remove(); gxMenuEl = null; }
  document.removeEventListener('mousedown', gxMenuOutside, true);
  document.removeEventListener('keydown', gxMenuKey, true);
  window.removeEventListener('scroll', gxCloseMenu, true);
  window.removeEventListener('resize', gxCloseMenu);
}
function gxMenuOutside(e){ if(gxMenuEl && !gxMenuEl.contains(e.target)) gxCloseMenu(); }
function gxMenuKey(e){ if(e.key==='Escape') gxCloseMenu(); }
function gxOpenMenu(anchor, key){
  gxCloseMenu();
  const e = gxUniverse().get(key); if(!e) return;
  const hasBudget = (Number(gxMeta(key).budget)||0)>0;
  const items = [
    ['open','Ver transações','eye'], ['add','Adicionar despesa aqui','plus'],
    ['budget', hasBudget?'Editar orçamento':'Definir orçamento','pencil'], '-',
    ['desc','Editar descrição','text'], ['icon','Alterar ícone','shapes'], ['color','Alterar cor','palette'], ['rename','Renomear categoria','pencil'], '-',
    ['remove','Remover categoria','trash','danger']
  ];
  const m = document.createElement('div');
  m.className = 'gx-menu'; m.setAttribute('role','menu');
  m.innerHTML = items.map(it=> it==='-' ? '<hr>' : `<button type="button" role="menuitem" data-act="${it[0]}" class="${it[3]||''}">${gxUi(it[2])}<span>${it[1]}</span></button>`).join('');
  document.body.appendChild(m);
  gxMenuEl = m;
  const r = anchor.getBoundingClientRect();
  const w = m.offsetWidth, h = m.offsetHeight;
  let left = Math.min(Math.max(8, r.right - w), window.innerWidth - w - 8);
  let top = r.bottom + 6;
  if(top + h > window.innerHeight - 8) top = Math.max(8, r.top - h - 6);
  m.style.left = left+'px'; m.style.top = top+'px';
  m.addEventListener('click', ev=>{
    const b = ev.target.closest('[data-act]'); if(!b) return;
    const act = b.dataset.act;
    gxCloseMenu();
    if(act==='open') gxOpenCategory(key);
    else if(act==='add'){ GX.addOpen = true; GX.focusAdd = true; gxOpenCategory(key); }
    else if(act==='budget') gxOpenBudget(key);
    else if(act==='desc') gxOpenDesc(key);
    else if(act==='icon') gxOpenIcons(key);
    else if(act==='color') gxPickColor(key, anchor);
    else if(act==='rename') gxRenameCategory(key);
    else if(act==='remove') gxRemoveCategory(key);
  });
  setTimeout(()=>{
    document.addEventListener('mousedown', gxMenuOutside, true);
    document.addEventListener('keydown', gxMenuKey, true);
    window.addEventListener('scroll', gxCloseMenu, true);
    window.addEventListener('resize', gxCloseMenu);
  }, 0);
}

