/* =========================================================
   RENDER: INÍCIO (com seletor de mês)
========================================================= */
let chartRef = null;
function renderDashboard(){
  const months = state.months;
  if(!state.dashboardMonth || !months.find(m=>m.id===state.dashboardMonth)){
    state.dashboardMonth = months.length ? pickDefaultMonthId() : null;
  }
  const month = months.find(m=>m.id===state.dashboardMonth);
  const sal = month ? state.salaries.find(s=>s.monthId===month.id) : null;
  const gastos = month ? monthTotal(month) : 0;
  const receitas = sal ? salaryTotal(sal) : 0;
  const saldo = receitas - gastos;
  const pendente = receivablesPendingTotal();
  const investTotalBaixa = investmentsTotal('investimentos', false);
  refreshWalletBalances();
  const carteiraTotal = (getWallet().items||[]).reduce((sum,it)=>sum+(Number(it.saldo)||0),0);

  // "tem dados de verdade" = pelo menos um mês com gasto OU salário lançado (não só meses vazios)
  const hasRealData = months.some(m=>monthTotal(m) > 0) || state.salaries.some(s=>salaryTotal(s) > 0);

  const el = document.createElement('div');
  el.innerHTML = `
    <div class="page-header">
      <div>
        <h2>Início</h2>
        <div class="desc">Escolha o mês para comparar receita e gastos daquele período. Tudo recalculado sozinho.</div>
      </div>
      <div class="stamp"><span class="dot"></span><div class="txt"><b>Atualizado</b> · <span class="js-stamp-date">${fmtStampDate(state.lastUpdated)}</span></div></div>
    </div>

    <div class="toolbar">
      <select class="tag-select" id="dashMonthSelect"></select>
    </div>

    <div class="grid-3">
      <div class="stat pos"><div class="label">Receita ${month?'· '+escAttr(month.label):''}${eyeToggleBtn()}</div><div class="value mono">${fmtPriv(receitas)}</div></div>
      <div class="stat neg"><div class="label">Gastos ${month?'· '+escAttr(month.label):''}</div><div class="value mono">${fmt(gastos)}</div></div>
      <div class="stat ${saldo<0?'neg':''}"><div class="label">Sobra do mês</div><div class="value mono">${fmtPriv(saldo)}</div></div>
    </div>

    <div class="grid-2" style="margin-top:22px;">
      <div class="card" id="chartCard">
        <div style="display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:wrap;">
          <h3>Receita × Gastos por mês</h3>
          ${months.length ? `
            <div class="chart-color-controls">
              <button type="button" class="chart-color-swatch" id="btnColorReceita" style="--sw:${ensureChartColors().receita}" title="Cor de Receita no gráfico" aria-label="Cor de Receita no gráfico"><i></i>Receita</button>
              <button type="button" class="chart-color-swatch" id="btnColorGastos" style="--sw:${ensureChartColors().gastos}" title="Cor de Gastos no gráfico" aria-label="Cor de Gastos no gráfico"><i></i>Gastos</button>
            </div>
          ` : ''}
        </div>
        <div id="chartCardBody">
          ${!months.length ? `
            <div class="empty-state">Assim que você cadastrar um mês em "Despesas", esse gráfico aparece aqui sozinho.<br><br><button class="btn secondary small" id="btnGoToGastos">Ir para Despesas</button></div>
          ` : !hasRealData ? `
            <div class="empty-state">Seus meses ainda estão sem gastos ou salário lançado. Preencha algum valor para o gráfico ganhar vida.<br><br><button class="btn secondary small" id="btnGoToGastos">Ir para Despesas</button></div>
          ` : `
            <div class="chart-wrap" id="chartWrap">
              <div class="chart-skeleton" id="chartSkeleton">
                <div class="skel-bars"><span></span><span></span><span></span><span></span><span></span></div>
                <div class="skel-label">carregando gráfico…</div>
              </div>
              <canvas id="chartMain" style="display:none;"></canvas>
            </div>
          `}
        </div>
      </div>
      <div class="card">
        <h3>Resumo geral</h3>
        <div class="table-wrap"><table>
          <tr><td>A receber (pendente)</td><td class="num mono">${fmt(pendente)}</td></tr>
          <tr><td>Carteira de Investimentos ${eyeToggleBtn('float:right;')}</td><td class="num mono">${fmtPriv(carteiraTotal)}</td></tr>
          <tr><td>Gastos fixos mensais</td><td class="num mono">${fmt(state.fixedExpenses.reduce((s,f)=>s+(Number(f.value)||0),0))}</td></tr>
          <tr><td>Empréstimos em aberto</td><td class="num mono">${fmt(state.loans.reduce((s,l)=>s+loanRemaining(l),0))}</td></tr>
        </table></div>
        <div class="small-note">Esses números seguem os dados das outras abas — edite lá e eles mudam aqui sozinhos.</div>
      </div>
    </div>

    <div class="card">
      <h3>Todos os meses <span class="hint">clique em "Despesas" para editar cada um</span></h3>
      <div class="table-wrap"><table class="responsive-table">
        <thead><tr><th>Mês</th><th class="num">Gastos</th><th class="num">Receita</th><th class="num">Sobra</th></tr></thead>
        <tbody>
          ${months.map(m=>{
            const s2 = state.salaries.find(s=>s.monthId===m.id);
            const g = monthTotal(m); const r = s2? salaryTotal(s2):0; const sd = r-g;
            return `<tr><td class="cell-plain">${escapeHtml(m.label)}</td><td class="num mono" data-label="Gastos">${fmt(g)}</td><td class="num mono" data-label="Receita">${fmtPriv(r)}</td><td class="num mono" data-label="Sobra" style="color:${sd<0?'var(--rust)':'var(--forest)'}">${fmtPriv(sd)}</td></tr>`;
          }).join('') || `<tr><td colspan="4"><div class="empty-state">Nenhum mês cadastrado ainda.</div></td></tr>`}
        </tbody>
      </table></div>
    </div>
  `;
  const sel = el.querySelector('#dashMonthSelect');
  sel.innerHTML = months.length ? months.map(m=>`<option value="${m.id}" ${m.id===state.dashboardMonth?'selected':''}>${escapeHtml(m.label)}</option>`).join('') : `<option>Nenhum mês cadastrado</option>`;
  sel.addEventListener('change', ()=>{ state.dashboardMonth = sel.value; renderSection(); });
  el.querySelectorAll('#btnGoToGastos').forEach(btn=>{
    btn.addEventListener('click', ()=>{ activeSection='gastos'; renderNav(); renderSection(); });
  });
  const btnColorReceita = el.querySelector('#btnColorReceita');
  const btnColorGastos = el.querySelector('#btnColorGastos');
  if(btnColorReceita){
    btnColorReceita.addEventListener('click', ()=>{
      const colors = ensureChartColors();
      openColorPopover(btnColorReceita, {color: colors.receita}, color=>{
        colors.receita = color;
        btnColorReceita.style.setProperty('--sw', color);
        scheduleSave();
        drawChart();
      });
    });
  }
  if(btnColorGastos){
    btnColorGastos.addEventListener('click', ()=>{
      const colors = ensureChartColors();
      openColorPopover(btnColorGastos, {color: colors.gastos}, color=>{
        colors.gastos = color;
        btnColorGastos.style.setProperty('--sw', color);
        scheduleSave();
        drawChart();
      });
    });
  }
  bindEyeToggles(el);
  return el;
}

function drawChart(){
  const canvas = document.getElementById('chartMain');
  const skeleton = document.getElementById('chartSkeleton');
  if(!canvas) return; // sem dados: já mostramos o empty state, nada a desenhar
  if(privacyMode){ // modo privado: não desenhar o gráfico (barras/eixos revelam os valores)
    if(chartRef){ chartRef.destroy(); chartRef = null; }
    canvas.style.display = 'none';
    if(skeleton){ skeleton.style.display = 'flex'; skeleton.innerHTML = `<div class="empty-state" style="padding:44px 16px;">🔒 Valores ocultos — toque no olhinho para mostrar o gráfico.</div>`; }
    return;
  }

  try{
    if(typeof Chart === 'undefined'){
      throw new Error('Biblioteca de gráficos não carregou (Chart.js indisponível).');
    }
    const months = state.months;
    // valida e normaliza os dados para número antes de entregar ao Chart.js
    const labels = months.map(m => String(m.label).split(' / ')[0]);
    const gastosData = months.map(m => Number(monthTotal(m)) || 0);
    const salData = months.map(m => {
      const s = state.salaries.find(x => x.monthId === m.id);
      return Number(s ? salaryTotal(s) : 0) || 0;
    });

    if(chartRef){ chartRef.destroy(); chartRef = null; }

    const chartColors = ensureChartColors();
    chartRef = new Chart(canvas.getContext('2d'), {
      type:'bar',
      data:{ labels, datasets:[
        {label:'Receita', data:salData, backgroundColor:chartColors.receita, hoverBackgroundColor:shadeHex(chartColors.receita,-25), borderRadius:6},
        {label:'Gastos', data:gastosData, backgroundColor:chartColors.gastos, hoverBackgroundColor:shadeHex(chartColors.gastos,-25), borderRadius:6},
      ]},
      options:{
        responsive:true, maintainAspectRatio:false,
        plugins:{legend:{labels:{font:{family:'JetBrains Mono', size:11}}}},
        scales:{
          y:{ticks:{font:{family:'JetBrains Mono', size:10}}, grid:{color:'#E2E8F0'}, beginAtZero:true},
          x:{ticks:{font:{family:'JetBrains Mono', size:11}}, grid:{display:false}}
        }
      }
    });

    // sucesso: troca o esqueleto pelo gráfico de verdade
    if(skeleton) skeleton.style.display = 'none';
    canvas.style.display = 'block';
  }catch(err){
    console.error('Erro ao renderizar gráfico Receita × Gastos:', err);
    const body = document.getElementById('chartCardBody');
    if(body){
      body.innerHTML = `<div class="empty-state">Não foi possível carregar o gráfico agora.<br>Recarregue a página — se persistir, verifique sua conexão.</div>`;
    }
  }
}

