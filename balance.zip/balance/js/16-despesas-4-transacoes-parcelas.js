/* ---------- transações: editar / excluir / adicionar ---------- */
function gxCategoryNames(month){
  const names = [], seen = new Set();
  (month.categories||[]).forEach(c=>{ const k = gxKey(c.name); if(!seen.has(k)){ seen.add(k); names.push(c.name); } });
  gxUniverse().forEach(e=>{ if(!seen.has(e.key)){ seen.add(e.key); names.push(e.name); } });
  if(!seen.has('sem categoria')) names.push('Sem categoria');
  return names;
}
function gxOpenTxEditor(tx){
  const names = gxCategoryNames(tx.month);
  const opts = names.map(n=>`<option value="${escAttr(n)}" ${gxKey(n)===tx.key?'selected':''}>${escapeHtml(n||'Sem nome')}</option>`).join('');
  const m = gxModal(`
    <h3>Editar despesa</h3>
    <p class="settings-desc">${escapeHtml(tx.month.label)}</p>
    <div class="qa-field"><label for="gxEdDesc">Descrição</label><input type="text" id="gxEdDesc" autocomplete="off"></div>
    <div class="qa-row">
      <div class="qa-field"><label for="gxEdVal">Valor</label><input type="text" id="gxEdVal" class="money" inputmode="decimal" autocomplete="off"></div>
      <div class="qa-field"><label for="gxEdDate">Data</label><input type="date" id="gxEdDate"></div>
    </div>
    <div class="qa-field"><label for="gxEdCat">Categoria</label><select id="gxEdCat">${opts}</select></div>
    <div class="qa-field"><label for="gxEdBanco">Banco</label><input type="text" id="gxEdBanco" list="gxBancosDL" placeholder="ex: Nubank" maxlength="30" autocomplete="off"></div>
    <div class="gx-err"></div>
    <div class="gx-modal-actions">
      <button type="button" class="btn secondary small gx-danger" id="gxEdDel">Excluir</button>
      <span class="grow"></span>
      <button type="button" class="btn secondary small" data-close>Cancelar</button>
      <button type="button" class="btn small" id="gxEdOk">Salvar</button>
    </div>`);
  const dI = m.el.querySelector('#gxEdDesc'), vI = m.el.querySelector('#gxEdVal'), tI = m.el.querySelector('#gxEdDate'), cS = m.el.querySelector('#gxEdCat');
  gxEnsureBankList();
  const bI = m.el.querySelector('#gxEdBanco'); bI.value = String(tx.item.banco||'');
  dI.value = String(tx.item.desc||''); vI.value = moneyDisplay(tx.item.value); tI.value = tx.item.date||'';
  gxBindMoney(vI);
  setTimeout(()=>dI.focus(), 40);
  const save = ()=>{
    const desc = dI.value.trim(), valor = parseMoney(vI.value);
    if(!desc){ gxSetErr(m, 'Informe a descrição do gasto.'); return; }
    if(!valor){ gxSetErr(m, 'Informe um valor válido (use sinal de menos para estorno).'); return; }
    tx.item.desc = desc; tx.item.value = valor; tx.item.date = tI.value || '';
    const bn = bI.value.trim(); if(bn) tx.item.banco = bn; else delete tx.item.banco;
    const nk = gxKey(cS.value);
    if(nk!==tx.key){
      let target = tx.month.categories.find(c=>gxKey(c.name)===nk);
      if(!target){ target = {name:cS.value, items:[]}; tx.month.categories.push(target); }
      const i = tx.cat.items.indexOf(tx.item); if(i>-1) tx.cat.items.splice(i,1);
      target.items.push(tx.item);
    }
    scheduleSave(); m.close(); renderSection(); showToast('✓ despesa atualizada', false);
  };
  m.el.querySelector('#gxEdOk').addEventListener('click', save);
  [dI, vI, bI].forEach(i=>i.addEventListener('keydown', ev=>{ if(ev.key==='Enter'){ ev.preventDefault(); save(); } }));
  m.el.querySelector('#gxEdDel').addEventListener('click', ()=>{ m.close(); gxDeleteTx(tx); });
}
function gxDeleteTx(tx){
  const i = tx.cat.items.indexOf(tx.item);
  if(i>-1) tx.cat.items.splice(i,1);
  scheduleSave(); renderSection(); showToast('despesa excluída (use “desfazer” se precisar)', false);
}
function gxAddPanelHTML(month){
  const names = gxCategoryNames(month);
  let pre = '';
  if(GX.view==='detail'){ const e = gxUniverse().get(GX.catKey); pre = e ? e.name : ''; }
  else if(GX.lastAdd.cat){ pre = names.find(n=>gxKey(n)===gxKey(GX.lastAdd.cat)) || ''; }
  const preKey = gxKey(pre);
  const opts = names.map((n,i)=>`<option value="${escAttr(n)}" ${(pre ? gxKey(n)===preKey : i===0)?'selected':''}>${escapeHtml(n||'Sem nome')}</option>`).join('');
  return `
    <div class="gx-add-wrap ${GX.addOpen?'open':''}" id="gxAddWrap"><div class="gx-add-inner">
      <div class="card quick-add-card gx-add-card">
        <div class="gx-add-title">Nova despesa em <b>${escapeHtml(month.label)}</b></div>
        <div class="qa-grid">
          <div class="qa-field"><label>Descrição</label><input type="text" id="qaDesc" placeholder="ex: mercado" autocomplete="off"></div>
          <div class="qa-field"><label>Valor</label><input type="text" inputmode="decimal" class="money" id="qaValor" placeholder="0,00" autocomplete="off"></div>
          <div class="qa-field"><label>Data</label><input type="date" id="qaData"></div>
          <div class="qa-field"><label>Tipo</label><select id="qaTipo"><option value="gasto">Gasto</option><option value="parcelas">Parcelas</option></select></div>
        </div>
        <div class="qa-row2">
          <div class="qa-field" id="qaParcWrap" style="display:none;max-width:130px;"><label>Nº de parcelas</label><input type="number" id="qaParcelas" min="2" max="48" step="1" value="3" inputmode="numeric"></div>
          <div class="qa-field"><label>Categoria</label><select id="qaCategoria">${opts}</select></div>
          <div class="qa-field"><label>Banco</label><input type="text" id="qaBanco" list="gxBancosDL" placeholder="ex: Nubank" maxlength="30" autocomplete="off" value="${escAttr(GX.lastAdd.banco||'')}"></div>
          <button class="btn" id="btnQaAdd" type="button">Adicionar</button>
        </div>
        <div class="settings-desc" id="qaParcHint" style="display:none;margin-top:10px;"></div>
        <div class="gx-err" id="gxAddErr"></div>
      </div>
    </div></div>`;
}
/* ---------- banco de cada despesa (campo livre, com sugestões dos já usados) ---------- */
const GX_BANCOS_PADRAO = ['Nubank','Itaú','Bradesco','Santander','Banco do Brasil','Caixa','Inter','C6 Bank','PicPay','Mercado Pago','Dinheiro'];
function gxBankNames(){
  const names = [], seen = new Set();
  const add = n=>{ n = String(n||'').trim(); const k = gxKey(n); if(n && !seen.has(k)){ seen.add(k); names.push(n); } };
  (state.months||[]).forEach(mo=>(mo.categories||[]).forEach(c=>(c.items||[]).forEach(it=>add(it.banco))));
  names.sort((a,b)=>a.localeCompare(b,'pt-BR'));
  GX_BANCOS_PADRAO.forEach(add);
  return names;
}
function gxEnsureBankList(){
  let dl = document.getElementById('gxBancosDL');
  if(!dl){ dl = document.createElement('datalist'); dl.id = 'gxBancosDL'; document.body.appendChild(dl); }
  dl.innerHTML = gxBankNames().map(n=>`<option value="${escAttr(n)}"></option>`).join('');
}
/* ---------- parcelas: lança a mesma despesa nos meses seguintes ---------- */
function gxMonthLabelFromRank(rank){
  return PT_MONTH_NAMES[rank%12] + ' / ' + Math.floor(rank/12);
}
// Acha o mês cadastrado com esse "rank" (ano*12+mês); se não existir, cria já na posição cronológica.
function gxFindOrCreateMonth(rank, created){
  let m = state.months.find(x=>monthLabelRank(x.label)===rank);
  if(m) return m;
  m = {id:uid(), label:gxMonthLabelFromRank(rank), categories:[]};
  const idx = state.months.findIndex(x=>{ const r = monthLabelRank(x.label); return r!==null && r>rank; });
  if(idx===-1) state.months.push(m); else state.months.splice(idx,0,m);
  created.push(m.label);
  return m;
}
// Data da parcela k: mesmo dia da data escolhida, no mês alvo (ajusta p/ o último dia se o mês for mais curto).
function gxInstallmentDate(baseISO, rank){
  const day = Number((baseISO||'').slice(8,10)) || 1;
  const y = Math.floor(rank/12), mi = rank%12;
  const last = new Date(y, mi+1, 0).getDate();
  return y+'-'+String(mi+1).padStart(2,'0')+'-'+String(Math.min(day,last)).padStart(2,'0');
}
function gxAddInstallments(month, catName, desc, valor, data, total, banco){
  const baseRank = monthLabelRank(month.label);
  if(baseRank===null) return {error:'Não consegui identificar o mês "'+month.label+'". Use um nome como "Novembro / 2026" para lançar parcelas.'};
  const groupId = uid(), created = [];
  let first = null;
  for(let n=1; n<=total; n++){
    const target = n===1 ? month : gxFindOrCreateMonth(baseRank+n-1, created);
    let cat = target.categories.find(c=>gxKey(c.name)===gxKey(catName));
    if(!cat){ cat = {name:catName, items:[]}; target.categories.push(cat); }
    const item = {desc: desc+' ('+n+'/'+total+')', value:valor, date: n===1 ? data : gxInstallmentDate(data, baseRank+n-1), parcela:{id:groupId, n, total}};
    if(banco) item.banco = banco;
    cat.items.push(item);
    if(n===1) first = item;
  }
  return {first, created, lastLabel: gxMonthLabelFromRank(baseRank+total-1)};
}
function gxWireAddPanel(wrap, month){
  const btn = wrap.querySelector('#gxBtnAdd');
  const panel = wrap.querySelector('#gxAddWrap');
  if(!panel) return;
  const dI = panel.querySelector('#qaDesc'), vI = panel.querySelector('#qaValor'), tI = panel.querySelector('#qaData'), cS = panel.querySelector('#qaCategoria'), err = panel.querySelector('#gxAddErr');
  gxEnsureBankList();
  const bI = panel.querySelector('#qaBanco');
  const tipoS = panel.querySelector('#qaTipo'), pW = panel.querySelector('#qaParcWrap'), pI = panel.querySelector('#qaParcelas'), pH = panel.querySelector('#qaParcHint');
  const updParc = ()=>{
    const isP = tipoS.value==='parcelas';
    pW.style.display = isP ? '' : 'none';
    const n = parseInt(pI.value,10), v = parseMoney(vI.value);
    if(isP && n>=2 && v>0){ pH.style.display = ''; pH.textContent = n+'x de '+fmt(v)+' = '+fmt(v*n)+' · lança nos '+(n-1)+' meses seguintes também'; }
    else if(isP){ pH.style.display = ''; pH.textContent = 'O valor informado é o de cada parcela. Ela será lançada nos meses seguintes automaticamente.'; }
    else pH.style.display = 'none';
  };
  [tipoS, pI, vI].forEach(i=>{ i.addEventListener('input', updParc); i.addEventListener('change', updParc); });
  tI.value = GX.lastAdd.date || new Date().toISOString().slice(0,10);
  gxBindMoney(vI);
  const submit = ()=>{
    const desc = dI.value.trim(), valor = parseMoney(vI.value);
    const data = tI.value || new Date().toISOString().slice(0,10);
    const catName = cS.value || 'Sem categoria';
    if(!desc){ err.textContent = 'Informe a descrição do gasto.'; dI.focus(); return; }
    if(!valor){ err.textContent = 'Informe um valor válido (use sinal de menos para estorno).'; vI.focus(); return; }
    const banco = bI.value.trim();
    const isParc = tipoS.value==='parcelas';
    const total = parseInt(pI.value,10);
    if(isParc && !(total>=2 && total<=48)){ err.textContent = 'Informe entre 2 e 48 parcelas.'; pI.focus(); return; }
    let item, msg = '✓ despesa adicionada';
    if(isParc){
      const r = gxAddInstallments(month, catName, desc, valor, data, total, banco);
      if(r.error){ err.textContent = r.error; return; }
      item = r.first;
      msg = '✓ '+total+' parcelas lançadas até '+r.lastLabel + (r.created.length ? ' ('+r.created.length+(r.created.length>1?' meses criados)':' mês criado)') : '');
    } else {
      let cat = month.categories.find(c=>gxKey(c.name)===gxKey(catName));
      if(!cat){ cat = {name:catName, items:[]}; month.categories.push(cat); }
      item = {desc, value:valor, date:data};
      if(banco) item.banco = banco;
      cat.items.push(item);
    }
    gastosCollapsedCats.delete((month.categories.find(c=>gxKey(c.name)===gxKey(catName))||{}).name);
    GX.flash = item; GX.lastAdd = {date:data, cat:catName, banco}; GX.focusAdd = true; GX.addOpen = true;
    scheduleSave();
    renderSection();
    setTimeout(()=>{
      const shown = document.querySelector('.gx-tx.is-new');
      showToast(isParc ? msg : (shown ? msg : msg+' (fora dos filtros atuais)'), false);
      GX.flash = null;
    }, 30);
  };
  panel.querySelector('#btnQaAdd').addEventListener('click', submit);
  [dI, vI, bI].forEach(i=>i.addEventListener('keydown', e=>{ if(e.key==='Enter'){ e.preventDefault(); submit(); } }));
  [dI, vI, cS, tI, pI, tipoS, bI].forEach(i=>i.addEventListener('input', ()=>{ err.textContent = ''; }));
  if(btn) btn.addEventListener('click', ()=>{
    GX.addOpen = !GX.addOpen;
    panel.classList.toggle('open', GX.addOpen);
    if(GX.addOpen) setTimeout(()=>dI.focus(), 260);
  });
}

