/* =========================================================
   INVESTIMENTO REAL — simulador sequencial mês a mês
   Modelo: valor inicial + lista de meses (aporte, taxa, tipo de taxa).
   O saldo final de um mês vira o saldo inicial do mês seguinte.
========================================================= */
const PT_MONTH_NAMES = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

// Compara textos de mês ignorando maiúsculas/acentos/espaços — ex: "Novembro / 2026" ~ "novembro2026".
function normalizeMonthLabel(str){
  return String(str||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,'');
}
// Ao entrar no app, se existir um mês cadastrado (em "Gastos Mensais") cujo nome corresponda ao mês/ano
// atuais (ex: "Novembro / 2026"), seleciona ele automaticamente — isso já reflete em "Gastos Mensais" e
// em "Salários", que usam o mesmo mês selecionado. "Gastos Fixos" não depende de mês (é um modelo único).
// Lê o rótulo de um mês cadastrado ("Setembro / 2026", "set/26"...) e devolve um número
// comparável (ano*12 + mês). Retorna null quando não consegue identificar.
function monthLabelRank(label){
  const norm = normalizeMonthLabel(label);
  let mi = -1;
  PT_MONTH_NAMES.forEach((name, i)=>{
    const n = normalizeMonthLabel(name);
    if(mi === -1 && (norm.includes(n) || norm.includes(n.slice(0,3)))) mi = i;
  });
  if(mi === -1) return null;
  const ym = norm.match(/(20\d{2})/) || norm.match(/(\d{2})(?!\d)/);
  let year;
  if(ym){ year = Number(ym[1]); if(year < 100) year += 2000; }
  else { year = new Date().getFullYear(); }
  return year * 12 + mi;
}
function currentMonthRank(){
  const now = new Date();
  return now.getFullYear() * 12 + now.getMonth();
}
// Escolhe o mês que deve aparecer ao abrir o app: o mês atual do calendário; se não estiver
// cadastrado, o mês cadastrado mais recente que já passou; se todos forem futuros, o mais próximo.
function pickDefaultMonthId(){
  const months = state.months || [];
  if(!months.length) return null;
  const cur = currentMonthRank();
  const ranked = months.map(m=>({ id:m.id, rank: monthLabelRank(m.label) })).filter(x=>x.rank !== null);
  if(!ranked.length) return months[months.length-1].id;
  const exact = ranked.find(x=>x.rank === cur);
  if(exact) return exact.id;
  const past = ranked.filter(x=>x.rank < cur).sort((a,b)=>b.rank-a.rank);
  if(past.length) return past[0].id;
  const future = ranked.filter(x=>x.rank > cur).sort((a,b)=>a.rank-b.rank);
  return future.length ? future[0].id : months[months.length-1].id;
}
function selectCurrentMonthIfFound(){
  if(!Array.isArray(state.months) || !state.months.length) return;
  const id = pickDefaultMonthId();
  if(id){ state.selectedMonth = id; state.dashboardMonth = id; }
}

function riMonthKeyNow(){
  const d = new Date();
  return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0');
}
function riNextMonthKey(key){
  const [y,m] = key.split('-').map(Number);
  const d = new Date(y, m, 1); // m já é (mês-1)+1 = próximo mês
  return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0');
}
function riFormatMonthLabel(key){
  if(!key) return '—';
  const [y,m] = key.split('-').map(Number);
  const name = PT_MONTH_NAMES[(m||1)-1] || '';
  return `${name}/${y}`;
}
// taxa anual -> equivalente mensal, matematicamente correta: (1+i_a)^(1/12) - 1
function riMonthlyRateFrom(taxa, tipoTaxa){
  const r = Number(taxa)||0;
  if(tipoTaxa==='mensal') return r/100;
  return Math.pow(1 + r/100, 1/12) - 1;
}

function ensureRealInvestShape(){
  const ri = state.realInvestments;
  const looksNew = ri && typeof ri.initialValue !== 'undefined' && Array.isArray(ri.months);
  if(!looksNew){
    // formato antigo (categorias/aportes) ou inexistente: recomeça limpo, sem inventar dados do usuário
    state.realInvestments = { initialValue: 0, months: [] };
  }
}

// Retorna os dados de "Investimento Real" da seção informada. 'realInvest' é a aba original (compatível com
// dados já salvos); qualquer outro id é uma seção duplicada, guardada à parte em state.realInvestSections.
function getRIData(sectionId){
  if(sectionId==='realInvest'){
    ensureRealInvestShape();
    return state.realInvestments;
  }
  if(!state.realInvestSections) state.realInvestSections = {};
  const cur = state.realInvestSections[sectionId];
  const looksNew = cur && typeof cur.initialValue !== 'undefined' && Array.isArray(cur.months);
  if(!looksNew) state.realInvestSections[sectionId] = { initialValue: 0, months: [] };
  return state.realInvestSections[sectionId];
}

// Roda a simulação inteira em sequência: saldo inicial do mês N = montante do mês N-1.
function computeRealInvestSchedule(sectionId){
  const ri = getRIData(sectionId);
  const initial = Number(ri.initialValue) || 0;
  let saldo = initial;
  const rows = [];
  (ri.months||[]).forEach(m=>{
    const saldoInicial = saldo;
    const aporte = Number(m.aporte) || 0;
    const taxaMensal = riMonthlyRateFrom(m.taxa, m.tipoTaxa);
    const rendimento = saldoInicial * taxaMensal;
    const montante = saldoInicial + aporte + rendimento;
    rows.push({ id:m.id, monthKey:m.monthKey, aporte, taxa:m.taxa, tipoTaxa:m.tipoTaxa, saldoInicial, rendimento, montante });
    saldo = montante;
  });
  const totalAportado = (ri.months||[]).reduce((s,m)=>s+(Number(m.aporte)||0), 0);
  const montanteAtual = rows.length ? rows[rows.length-1].montante : initial;
  const rendimentoTotal = montanteAtual - initial - totalAportado;
  return { rows, initial, totalAportado, montanteAtual, rendimentoTotal };
}

function fmtStampDate(iso){
  if(!iso) return '—';
  const d = new Date(iso);
  const dd = String(d.getDate()).padStart(2,'0'), mm = String(d.getMonth()+1).padStart(2,'0');
  const hh = String(d.getHours()).padStart(2,'0'), mi = String(d.getMinutes()).padStart(2,'0');
  return `${dd}/${mm} · ${hh}:${mi}`;
}
function renderStampAll(){
  document.querySelectorAll('.js-stamp-date').forEach(el=>{ el.textContent = fmtStampDate(state.lastUpdated); });
}

