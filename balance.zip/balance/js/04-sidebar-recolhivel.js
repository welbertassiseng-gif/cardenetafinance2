/* =========================================================
   BARRA LATERAL RECOLHÍVEL (desktop)
========================================================= */
let sidebarCollapsed = false;
try{ sidebarCollapsed = localStorage.getItem('balanceSidebarCollapsed') === '1'; }catch(e){}
function applySidebarCollapsed(){
  const sb = document.querySelector('.sidebar');
  if(sb) sb.classList.toggle('collapsed', sidebarCollapsed);
  const btn = document.getElementById('btnSidebarCollapse');
  if(btn){
    btn.setAttribute('aria-expanded', String(!sidebarCollapsed));
    btn.title = sidebarCollapsed ? 'Expandir menu' : 'Recolher menu';
  }
}
function toggleSidebarCollapsed(){
  sidebarCollapsed = !sidebarCollapsed;
  try{ localStorage.setItem('balanceSidebarCollapsed', sidebarCollapsed ? '1' : '0'); }catch(e){}
  applySidebarCollapsed();
}

