/* ---------- ações de categoria ---------- */
function gxOpenCategory(key){
  GX.view = 'detail'; GX.catKey = key; GX.filters.cats = [key];
  GX.filters.search = ''; GX.filters.min = null; GX.filters.max = null;
  GX.limit = 60; GX.filtersOpen = false;
  renderSection();
  window.scrollTo({top:0, behavior:'smooth'});
}
function gxLeaveDetail(to){
  GX.view = to; GX.catKey = null; GX.filters.cats = []; GX.limit = 60;
  renderSection();
  window.scrollTo({top:0, behavior:'smooth'});
}
function gxOpenBudget(key){
  const e = gxUniverse().get(key); if(!e) return;
  const cur = Number(gxMeta(key).budget)||0;
  const m = gxModal(`
    <h3>Orçamento · ${escapeHtml(e.name)}</h3>
    <p class="settings-desc">Valor mensal planejado para esta categoria. Ele é comparado com o que foi gasto no período escolhido.</p>
    <div class="qa-field"><label for="gxBudVal">Orçamento mensal</label><input type="text" id="gxBudVal" class="modal-money" inputmode="decimal" placeholder="0,00" autocomplete="off"></div>
    <div class="gx-err"></div>
    <div class="gx-modal-actions">
      ${cur>0 ? '<button type="button" class="btn secondary small gx-danger" id="gxBudDel">Remover</button>' : ''}
      <span class="grow"></span>
      <button type="button" class="btn secondary small" data-close>Cancelar</button>
      <button type="button" class="btn small" id="gxBudOk">Salvar</button>
    </div>`);
  const inp = m.el.querySelector('#gxBudVal');
  if(cur>0) inp.value = moneyDisplay(cur);
  gxBindMoney(inp);
  setTimeout(()=>inp.focus(), 40);
  const save = ()=>{
    const v = parseMoney(inp.value);
    if(!(v>0)){ gxSetErr(m, 'Informe um valor maior que zero.'); return; }
    gxMeta(key, true).budget = v;
    scheduleSave(); m.close(); renderSection(); showToast('✓ orçamento salvo', false);
  };
  m.el.querySelector('#gxBudOk').addEventListener('click', save);
  inp.addEventListener('keydown', ev=>{ if(ev.key==='Enter'){ ev.preventDefault(); save(); } });
  const del = m.el.querySelector('#gxBudDel');
  if(del) del.addEventListener('click', ()=>{ delete gxMeta(key, true).budget; scheduleSave(); m.close(); renderSection(); showToast('orçamento removido', false); });
}
function gxOpenDesc(key){
  const e = gxUniverse().get(key); if(!e) return;
  const meta = gxMeta(key);
  const m = gxModal(`
    <h3>Descrição · ${escapeHtml(e.name)}</h3>
    <p class="settings-desc">Um texto curto que aparece no cartão da categoria.</p>
    <div class="qa-field"><label for="gxDescIn">Descrição</label><input type="text" id="gxDescIn" maxlength="90" autocomplete="off"></div>
    <div class="gx-modal-actions">
      ${meta.desc ? '<button type="button" class="btn secondary small" id="gxDescReset">Usar padrão</button>' : ''}
      <span class="grow"></span>
      <button type="button" class="btn secondary small" data-close>Cancelar</button>
      <button type="button" class="btn small" id="gxDescOk">Salvar</button>
    </div>`);
  const inp = m.el.querySelector('#gxDescIn');
  inp.value = meta.desc || gxDescFor(key, e.name, gxIconKey(key, e.name), []);
  setTimeout(()=>{ inp.focus(); inp.select(); }, 40);
  const save = ()=>{
    const v = inp.value.trim();
    if(v) gxMeta(key, true).desc = v; else delete gxMeta(key, true).desc;
    scheduleSave(); m.close(); renderSection();
  };
  m.el.querySelector('#gxDescOk').addEventListener('click', save);
  inp.addEventListener('keydown', ev=>{ if(ev.key==='Enter'){ ev.preventDefault(); save(); } });
  const rs = m.el.querySelector('#gxDescReset');
  if(rs) rs.addEventListener('click', ()=>{ delete gxMeta(key, true).desc; scheduleSave(); m.close(); renderSection(); });
}
function gxOpenIcons(key){
  const e = gxUniverse().get(key); if(!e) return;
  const meta = gxMeta(key);
  const curEmoji = meta.emoji || '';
  const cur = gxIconKey(key, e.name);
  const iconOpts = Object.keys(GX_ICON_PATHS).map(k=>`<button type="button" class="gx-icon-opt ${!curEmoji && k===cur?'on':''}" data-ico="${k}" aria-label="${k}">${gxSvg(GX_ICON_PATHS[k])}</button>`).join('');
  const emojiCats = GX_EMOJI_CATEGORIES.map(([label, list])=>`
    <div class="gx-emoji-cat-label">${escapeHtml(label)}</div>
    <div class="gx-emoji-grid">${list.map(em=>`<button type="button" class="gx-emoji-opt ${em===curEmoji?'on':''}" data-emoji="${em}" aria-label="${em}">${em}</button>`).join('')}</div>
  `).join('');
  const m = gxModal(`
    <h3>Ícone · ${escapeHtml(e.name)}</h3>
    <p class="settings-desc">Escolha um ícone ou um emoji para representar esta categoria.</p>
    <div class="gx-icon-tabs" role="tablist">
      <button type="button" class="gx-icon-tab ${!curEmoji?'active':''}" data-tab="icons" role="tab">Ícones</button>
      <button type="button" class="gx-icon-tab ${curEmoji?'active':''}" data-tab="emoji" role="tab">Emoji</button>
    </div>
    <div class="gx-icon-tab-panel" data-panel="icons" style="display:${curEmoji?'none':'block'}">
      <div class="gx-icon-grid">${iconOpts}</div>
    </div>
    <div class="gx-icon-tab-panel" data-panel="emoji" style="display:${curEmoji?'block':'none'}">
      <div class="qa-field">
        <label for="gxEmojiIn">Digite ou cole qualquer emoji</label>
        <div style="display:flex; gap:8px;">
          <input type="text" id="gxEmojiIn" maxlength="8" autocomplete="off" placeholder="😀" value="${escAttr(curEmoji)}" style="flex:1;">
          <button type="button" class="btn small" id="gxEmojiOk">Usar</button>
        </div>
      </div>
      <div class="gx-emoji-cats">${emojiCats}</div>
    </div>
    <div class="gx-modal-actions">
      <button type="button" class="btn secondary small" id="gxIcoAuto">Automático</button>
      <span class="grow"></span>
      <button type="button" class="btn secondary small" data-close>Cancelar</button>
    </div>`);
  m.el.querySelectorAll('.gx-icon-tab').forEach(tab=>tab.addEventListener('click', ()=>{
    m.el.querySelectorAll('.gx-icon-tab').forEach(t=>t.classList.toggle('active', t===tab));
    m.el.querySelectorAll('.gx-icon-tab-panel').forEach(p=>{ p.style.display = p.dataset.panel===tab.dataset.tab ? 'block' : 'none'; });
  }));
  m.el.querySelectorAll('[data-ico]').forEach(b=>b.addEventListener('click', ()=>{
    const mm = gxMeta(key, true); mm.icon = b.dataset.ico; delete mm.emoji;
    scheduleSave(); m.close(); renderSection();
  }));
  m.el.querySelectorAll('[data-emoji]').forEach(b=>b.addEventListener('click', ()=>{
    const mm = gxMeta(key, true); mm.emoji = b.dataset.emoji;
    scheduleSave(); m.close(); renderSection();
  }));
  const emojiIn = m.el.querySelector('#gxEmojiIn');
  const applyEmojiInput = ()=>{
    const v = emojiIn.value.trim();
    const mm = gxMeta(key, true);
    if(v) mm.emoji = v; else delete mm.emoji;
    scheduleSave(); m.close(); renderSection();
  };
  emojiIn.addEventListener('keydown', ev=>{ if(ev.key==='Enter'){ ev.preventDefault(); applyEmojiInput(); } });
  m.el.querySelector('#gxEmojiOk').addEventListener('click', applyEmojiInput);
  m.el.querySelector('#gxIcoAuto').addEventListener('click', ()=>{
    const mm = gxMeta(key, true); delete mm.icon; delete mm.emoji;
    scheduleSave(); m.close(); renderSection();
  });
}
function gxPickColor(key, anchor){
  const e = gxUniverse().get(key); if(!e) return;
  const fake = {color: gxColorFor(key)};
  openColorPopover(anchor, fake, color=>{
    e.entries.forEach(x=>{ x.cat.color = color; });
    scheduleSave();
    document.querySelectorAll('.gx-card').forEach(card=>{
      if(card.dataset.cat===key){
        card.querySelector('.gx-ico').style.cssText = `background:${gxTint(color,'22')}; color:${color};`;
        card.style.setProperty('--cc', color);
      }
    });
    gxRefreshSummary();
  });
}
function gxRenameCategory(key){
  const e = gxUniverse().get(key); if(!e) return;
  const m = gxModal(`
    <h3>Renomear categoria</h3>
    <p class="settings-desc">O novo nome vale para essa categoria em todos os meses.</p>
    <div class="qa-field"><label for="gxRenIn">Nome</label><input type="text" id="gxRenIn" maxlength="40" autocomplete="off"></div>
    <div class="gx-err"></div>
    <div class="gx-modal-actions"><span class="grow"></span><button type="button" class="btn secondary small" data-close>Cancelar</button><button type="button" class="btn small" id="gxRenOk">Salvar</button></div>`);
  const inp = m.el.querySelector('#gxRenIn');
  inp.value = e.name;
  setTimeout(()=>{ inp.focus(); inp.select(); }, 40);
  const save = ()=>{
    const nn = inp.value.trim();
    if(!nn){ gxSetErr(m, 'Informe um nome.'); return; }
    const nk = gxKey(nn);
    if(nk!==key && gxUniverse().has(nk)){ gxSetErr(m, 'Já existe uma categoria com esse nome.'); return; }
    e.entries.forEach(x=>{ x.cat.name = nn; });
    if(nk!==key){
      if(state.categoryMeta && state.categoryMeta[key]){ state.categoryMeta[nk] = state.categoryMeta[key]; delete state.categoryMeta[key]; }
      if(GX.catKey===key) GX.catKey = nk;
      GX.filters.cats = GX.filters.cats.map(k=>k===key?nk:k);
    }
    scheduleSave(); m.close(); renderSection(); showToast('✓ categoria renomeada', false);
  };
  m.el.querySelector('#gxRenOk').addEventListener('click', save);
  inp.addEventListener('keydown', ev=>{ if(ev.key==='Enter'){ ev.preventDefault(); save(); } });
}
function gxNewCategory(){
  const month = gxSelMonth(); if(!month) return;
  const m = gxModal(`
    <h3>Nova categoria</h3>
    <p class="settings-desc">Ela aparece na hora em Categorias e já pode receber despesas.</p>
    <div class="qa-field"><label for="gxNewIn">Nome</label><input type="text" id="gxNewIn" maxlength="40" placeholder="ex: Academia" autocomplete="off"></div>
    <div class="gx-err"></div>
    <div class="gx-modal-actions"><span class="grow"></span><button type="button" class="btn secondary small" data-close>Cancelar</button><button type="button" class="btn small" id="gxNewOk">Criar</button></div>`);
  const inp = m.el.querySelector('#gxNewIn');
  setTimeout(()=>inp.focus(), 40);
  const save = ()=>{
    const nn = inp.value.trim();
    if(!nn){ gxSetErr(m, 'Informe um nome.'); return; }
    if(gxUniverse().has(gxKey(nn))){ gxSetErr(m, 'Já existe uma categoria com esse nome.'); return; }
    month.categories.push({name:nn, items:[]});
    scheduleSave(); m.close(); renderSection(); showToast('✓ categoria criada', false);
  };
  m.el.querySelector('#gxNewOk').addEventListener('click', save);
  inp.addEventListener('keydown', ev=>{ if(ev.key==='Enter'){ ev.preventDefault(); save(); } });
}
function gxRemoveCategory(key){
  const e = gxUniverse().get(key); if(!e) return;
  const sel = gxSelMonth();
  const inSel = e.entries.filter(x=>x.month===sel);
  const others = e.entries.filter(x=>x.month!==sel);
  const count = list=>list.reduce((s,x)=>s+(x.cat.items||[]).filter(i=>(Number(i.value)||0)!==0 || String(i.desc||'').trim()).length, 0);
  const both = inSel.length && others.length;
  const m = gxModal(`
    <h3>Remover “${escapeHtml(e.name)}”?</h3>
    <p class="settings-desc">${both
      ? `Em ${escapeHtml(sel.label)} há ${gxPlural(count(inSel),'lançamento','lançamentos')}; nos outros meses, ${count(others)}. Os lançamentos removidos saem dos totais.`
      : `${gxPlural(count(e.entries),'lançamento será excluído','lançamentos serão excluídos')} junto com a categoria.`}</p>
    <div class="gx-modal-actions">
      <button type="button" class="btn secondary small" data-close>Cancelar</button>
      ${both ? `<button type="button" class="btn secondary small gx-danger" id="gxRmSel">Só em ${escapeHtml(sel.label)}</button>` : ''}
      <button type="button" class="btn small" id="gxRmAll" style="background:var(--rust); box-shadow:none;">${both?'Em todos os meses':'Remover'}</button>
    </div>`);
  const remove = list=>{
    list.forEach(x=>{ const i = x.month.categories.indexOf(x.cat); if(i>-1) x.month.categories.splice(i,1); });
    if(!gxUniverse().has(key)){
      if(state.categoryMeta) delete state.categoryMeta[key];
      if(GX.catKey===key){ GX.view = 'cats'; GX.catKey = null; }
      GX.filters.cats = GX.filters.cats.filter(k=>k!==key);
    }
    scheduleSave(); m.close(); renderSection(); showToast('categoria removida', false);
  };
  m.el.querySelector('#gxRmAll').addEventListener('click', ()=>remove(e.entries));
  const rs = m.el.querySelector('#gxRmSel');
  if(rs) rs.addEventListener('click', ()=>remove(inSel));
}

