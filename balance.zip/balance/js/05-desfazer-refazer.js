/* =========================================================
   DESFAZER / REFAZER
   Guarda um histórico de "fotos" do estado. Antes de qualquer clique,
   digitação ou mudança na tela, tiramos uma foto do estado como ele
   estava até aquele momento. Assim dá para corrigir um erro (item
   apagado, categoria removida, valor trocado etc.) sem sair do app.
========================================================= */
let undoStack = [];
let redoStack = [];
const UNDO_LIMIT = 50;
let lastUndoSnapTime = 0;

function snapshotStateJSON(){
  try{ return JSON.stringify(state); }catch(e){ return null; }
}

function captureUndoPoint(){
  if(!state) return;
  const now = Date.now();
  if(now - lastUndoSnapTime < 600) return; // agrupa alterações rápidas (ex: digitação) num só passo
  const snap = snapshotStateJSON();
  if(!snap) return;
  if(undoStack.length && undoStack[undoStack.length-1] === snap) return;
  lastUndoSnapTime = now;
  undoStack.push(snap);
  if(undoStack.length > UNDO_LIMIT) undoStack.shift();
  redoStack = []; // uma nova alteração invalida o "refazer"
  updateUndoRedoButtons();
}

function performUndo(){
  if(!undoStack.length) return;
  const current = snapshotStateJSON();
  const prev = undoStack.pop();
  if(current) redoStack.push(current);
  try{ state = JSON.parse(prev); }catch(e){ return; }
  dirty = true;
  ensureNavConfig();
  renderNav();
  renderSection();
  renderStampAll();
  updateSaveIndicators();
  updateUndoRedoButtons();
  showToast('alteração desfeita', false);
}

function performRedo(){
  if(!redoStack.length) return;
  const current = snapshotStateJSON();
  const next = redoStack.pop();
  if(current) undoStack.push(current);
  try{ state = JSON.parse(next); }catch(e){ return; }
  dirty = true;
  ensureNavConfig();
  renderNav();
  renderSection();
  renderStampAll();
  updateSaveIndicators();
  updateUndoRedoButtons();
  showToast('alteração refeita', false);
}

function updateUndoRedoButtons(){
  // só mostra desfazer/refazer se há alteração pendente (não salva); depois de salvar somem até a próxima alteração
  const showUndo = dirty && undoStack.length>0;
  const showRedo = dirty && (undoStack.length>0 || redoStack.length>0); // refazer acompanha o desfazer (apagado até haver o que refazer)
  document.querySelectorAll('.js-undo-btn').forEach(b=>{
    b.classList.toggle('is-hidden', !showUndo);
    b.disabled = !showUndo;
  });
  document.querySelectorAll('.js-redo-btn').forEach(b=>{
    b.classList.toggle('is-hidden', !showRedo);
    b.disabled = redoStack.length===0;
  });
  // esconde a linha inteira (sidebar/drawer) quando não há nem desfazer nem refazer
  document.querySelectorAll('.quick-actions').forEach(row=>{
    const btns = row.querySelectorAll('.js-undo-btn, .js-redo-btn');
    if(btns.length) row.classList.toggle('is-hidden', !showUndo && !showRedo);
  });
}

// captura o estado ANTES de qualquer clique/digitação/mudança mexer nele
// (fase de captura roda antes dos handlers dos próprios botões/campos)
const undoSkip = (e)=> !!(e.target && e.target.closest && e.target.closest('[data-no-undo]')); // filtros/abas/navegação não alteram dados
document.addEventListener('click', (e)=>{
  if(e.target.closest && e.target.closest('.js-undo-btn, .js-redo-btn')) return;
  if(undoSkip(e)) return;
  captureUndoPoint();
}, true);
document.addEventListener('input', (e)=>{ if(undoSkip(e)) return; captureUndoPoint(); }, true);
document.addEventListener('change', (e)=>{ if(undoSkip(e)) return; captureUndoPoint(); }, true);

