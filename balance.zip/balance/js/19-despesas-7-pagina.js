/* ---------- página ---------- */
function renderGastos(){
  gxCloseMenu();
  const el = document.createElement('div');
  if(!state.months.find(m=>m.id===state.selectedMonth) && state.months.length){
    state.selectedMonth = pickDefaultMonthId();
  }
  const month = state.months.find(m=>m.id===state.selectedMonth);
  const idx = month ? state.months.findIndex(m=>m.id===month.id) : -1;
  if(GX.view==='detail' && !gxUniverse().has(GX.catKey)){ GX.view = 'cats'; GX.catKey = null; GX.filters.cats = []; }
  const detail = GX.view==='detail';

  el.innerHTML = `
    <div class="page-header">
      <div><h2>Despesas</h2><div class="desc">Veja o mês inteiro, explore por categoria e lance novas despesas. Totais, médias e gráficos somam sozinhos.</div></div>
    </div>
    <div class="month-nav" data-no-undo>
      <button class="month-nav-arrow" id="btnPrevMonth" title="mês anterior" ${idx<=0?'disabled':''}>‹</button>
      <div class="month-nav-label">${month ? escapeHtml(month.label) : '—'}</div>
      <button class="month-nav-arrow" id="btnNextMonth" title="próximo mês" ${(idx<0||idx>=state.months.length-1)?'disabled':''}>›</button>
    </div>
    <div class="toolbar" style="margin-top:12px;">
      <select class="tag-select" id="monthSelect"></select>
      ${detail ? '' : `
      <button class="btn secondary small" id="btnNewMonth">+ novo mês</button>
      <button class="btn secondary small" id="btnDupMonth">duplicar mês atual</button>
      <button class="btn gold small" id="btnApplyFixed">aplicar gastos fixos</button>
      ${month ? `<button class="btn secondary small" id="btnDelMonth" style="border-color:var(--rust); color:var(--rust);">excluir mês</button>` : ''}`}
    </div>
    <div id="gxContent"></div>
  `;

  const sel = el.querySelector('#monthSelect');
  sel.innerHTML = state.months.map(m=>`<option value="${m.id}" ${m.id===state.selectedMonth?'selected':''}>${escapeHtml(m.label)}</option>`).join('');
  sel.addEventListener('change', ()=>{ state.selectedMonth = sel.value; renderSection(); });

  const prevBtn = el.querySelector('#btnPrevMonth');
  const nextBtn = el.querySelector('#btnNextMonth');
  if(prevBtn) prevBtn.addEventListener('click', ()=>{
    if(idx>0){ state.selectedMonth = state.months[idx-1].id; renderSection(); }
  });
  if(nextBtn) nextBtn.addEventListener('click', ()=>{
    if(idx>=0 && idx<state.months.length-1){ state.selectedMonth = state.months[idx+1].id; renderSection(); }
  });

  const on = (id, fn)=>{ const b = el.querySelector(id); if(b) b.addEventListener('click', fn); };
  on('#btnNewMonth', ()=>{
    const label = prompt('Nome do novo mês (ex: Novembro / 2026):');
    if(!label) return;
    const id = uid();
    state.months.push({id, label, categories:[]});
    state.selectedMonth = id;
    scheduleSave(); renderSection();
  });
  on('#btnDupMonth', ()=>{
    if(!month) return;
    const label = prompt('Nome do novo mês (cópia de ' + month.label + '):', '');
    if(!label) return;
    const clone = JSON.parse(JSON.stringify(month));
    clone.id = uid(); clone.label = label;
    state.months.push(clone);
    state.selectedMonth = clone.id;
    scheduleSave(); renderSection();
  });
  on('#btnApplyFixed', ()=>{
    if(!month) return;
    let cat = month.categories.find(c=>c.name==='Gastos Fixos');
    if(!cat){ cat = {name:'Gastos Fixos', items:[]}; month.categories.unshift(cat); }
    state.fixedExpenses.forEach(f=>{
      if(!cat.items.find(i=>i.desc===f.name)) cat.items.push({desc:f.name, value:f.value});
    });
    scheduleSave(); renderSection();
  });
  on('#btnDelMonth', ()=>{
    if(!confirm(`Excluir "${month.label}" e todos os gastos dele?`)) return;
    state.months = state.months.filter(m=>m.id!==month.id);
    const salIdx = state.salaries.findIndex(s=>s.monthId===month.id);
    if(salIdx>=0) state.salaries.splice(salIdx,1);
    state.selectedMonth = state.months[0] ? state.months[0].id : null;
    scheduleSave(); renderSection();
  });

  const content = el.querySelector('#gxContent');
  if(!month){
    content.innerHTML = `<div class="card"><div class="empty-state">Nenhum mês cadastrado ainda. Clique em "+ novo mês" para começar.</div></div>`;
    return el;
  }
  if(!detail){
    const summary = document.createElement('div');
    summary.className = 'card month-summary-card';
    summary.innerHTML = gxSummaryHTML(month);
    content.appendChild(summary);
    content.appendChild(gxTabsEl());
  }
  const body = document.createElement('div');
  body.id = 'gxBody';
  content.appendChild(body);
  if(detail) gxBuildDetail(body, month);
  else if(GX.view==='cats') gxBuildCats(body, month);
  else gxBuildAll(body, month);

  if(GX.addOpen && GX.focusAdd){
    GX.focusAdd = false;
    setTimeout(()=>{ const d = document.getElementById('qaDesc'); if(d) d.focus({preventScroll:true}); }, 60);
  }
  return el;
}
function recalcGastos(month, ci){
  const catCell = document.getElementById('cat-total-'+ci);
  if(catCell) catCell.textContent = fmt(categoryTotal(month.categories[ci]));
  const totalCell = document.querySelector('.summary-total-value');
  if(totalCell) totalCell.textContent = fmt(monthTotal(month));
  // o anel de proporção por categoria só recalcula num novo render (evita SVG piscando a cada tecla)
}

