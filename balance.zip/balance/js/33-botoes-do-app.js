function wireAppButtons(){
  const importFile = document.getElementById('importFile');

  const doExport = ()=>{
    const blob = new Blob([JSON.stringify(state,null,2)], {type:'application/json'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `balance-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
  };
  const doImportClick = ()=>{ importFile.click(); };
  const doLogout = async ()=>{
    if(dirty){
      const ok = confirm('Você tem alterações não salvas. Sair mesmo assim e perder essas alterações?');
      if(!ok) return;
    }
    stopRealtimeSync();
    stopNotificationWatcher();
    await sb.auth.signOut();
    currentSession = null;
    state = null;
    lastSyncedAt = null;
    undoStack = []; redoStack = [];
    updateUndoRedoButtons();
    closeDrawer();
    document.getElementById('app').style.display = 'none';
    document.getElementById('loginForm').reset();
    setAuthForm('login');
    document.getElementById('landingScreen').style.display = 'flex';
  };

  document.getElementById('btnExportSettings').onclick = doExport;
  document.getElementById('btnImportSettings').onclick = doImportClick;
  document.getElementById('btnLogout').onclick = doLogout;
  document.getElementById('btnLogoutDrawer').onclick = doLogout;

  document.getElementById('btnSaveDesktop').onclick = manualSave;
  document.getElementById('btnSaveMobile').onclick = manualSave;
  document.getElementById('btnSaveDrawer').onclick = manualSave;
  document.getElementById('btnSettingsDesktop').onclick = ()=>{ openSettings(); };
  document.getElementById('btnSettingsDrawer').onclick = ()=>{ closeDrawer(); openSettings(); };
  updateSaveIndicators();

  document.getElementById('btnUndoDesktop').onclick = performUndo;
  document.getElementById('btnUndoDrawer').onclick = performUndo;
  document.getElementById('btnUndoMobile').onclick = performUndo;
  document.getElementById('btnRedoDesktop').onclick = performRedo;
  document.getElementById('btnRedoDrawer').onclick = performRedo;
  updateUndoRedoButtons();

  const btnSidebarCollapse = document.getElementById('btnSidebarCollapse');
  if(btnSidebarCollapse){ btnSidebarCollapse.onclick = toggleSidebarCollapsed; }
  applySidebarCollapsed();

  importFile.onchange = async (e)=>{
    const file = e.target.files[0];
    if(!file) return;
    try{
      const text = await file.text();
      const parsed = JSON.parse(text);
      if(!parsed.months || !parsed.investments) throw new Error('formato inválido');
      state = Object.assign(emptyState(), parsed);
      ensureNavConfig();
      await persistState();
      renderNav();
      renderSection();
      alert('Backup importado com sucesso!');
    }catch(err){
      alert('Não foi possível importar esse arquivo. Verifique se é um backup válido do Balance.');
    }
    e.target.value = '';
  };

  const burger = document.getElementById('btnOpenDrawer');
  if(burger) burger.onclick = openDrawer;
  const overlay = document.getElementById('drawerOverlay');
  if(overlay) overlay.onclick = closeDrawer;

  const bellDesktop = document.getElementById('btnBellDesktop');
  const bellMobile = document.getElementById('btnBellMobile');
  const closeNotif = document.getElementById('btnCloseNotif');
  if(bellDesktop) bellDesktop.onclick = (e)=>{ e.stopPropagation(); toggleNotifPanel(); };
  if(bellMobile) bellMobile.onclick = (e)=>{ e.stopPropagation(); toggleNotifPanel(); };
  if(closeNotif) closeNotif.onclick = closeNotifPanel;
  document.addEventListener('click', (e)=>{
    const panel = document.getElementById('notifPanel');
    if(panel && panel.classList.contains('open') && !panel.contains(e.target) && e.target.id!=='btnBellDesktop' && e.target.id!=='btnBellMobile'){
      closeNotifPanel();
    }
  });
  const btnPush = document.getElementById('btnEnablePush');
  if(btnPush) btnPush.onclick = (e)=>{ e.stopPropagation(); togglePush(); };
  renderNotifications();
  startNotificationWatcher();
}

/* ---------- Vigilância em tempo real dos avisos ----------
   Os alertas passam a chegar sozinhos, sem precisar entrar ou recarregar:
   - a cada 60s o app confere no servidor se há dados novos e reavalia os avisos
     (funciona também com a aba em segundo plano);
   - qualquer alteração vinda de outro aparelho (realtime) reavalia na hora;
   - a virada do dia também reavalia (avisos que dependem de data). */
