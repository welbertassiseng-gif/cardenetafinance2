/* =========================================================
   ROTEADOR DE SEÇÕES
========================================================= */
function renderSection(){
  const container = document.getElementById('sections');
  container.innerHTML = '';
  if(!activeSection){ container.innerHTML = `<div class="empty-state">Nenhuma seção visível. Restaure uma no menu lateral.</div>`; return; }
  const cfg = state.navConfig.find(n=>n.id===activeSection);
  const kind = cfg ? (cfg.kind || activeSection) : activeSection;
  let node;
  if(kind==='dashboard') node = renderDashboard();
  else if(kind==='gastos') node = renderGastos();
  else if(kind==='fixos') node = renderFixos();
  else if(kind==='salarios') node = renderSalarios();
  else if(kind==='receber') node = renderReceber();
  else if(kind==='investimentos') node = renderInvestimentos(activeSection);
  else if(kind==='realInvest') node = renderRealInvest(activeSection);
  else if(kind==='carteira') node = renderCarteira();
  else if(kind==='notas') node = renderNotas();
  else node = renderCustomSection(activeSection);
  container.appendChild(node);
  syncSectionTitle(node, cfg, kind);
  if(kind==='dashboard') requestAnimationFrame(()=>requestAnimationFrame(drawChart));
  if(kind==='realInvest'){ const sid = activeSection; requestAnimationFrame(()=>requestAnimationFrame(()=>drawRealInvestChart(sid))); }
  if(kind==='carteira') requestAnimationFrame(()=>requestAnimationFrame(()=>{ drawWalletChart(); drawWalletSimChart(); }));
}

// mantém o título exibido no topo da seção igual ao rótulo do menu,
// pra que renomear "Início" para "Visão geral" atualize a interface na hora.
function syncSectionTitle(node, cfg, kind){
  if(!cfg || !cfg.label) return;
  if(kind==='carteira' && carteiraDetailId) return; // detalhe da carteira mostra o nome do item
  const h2 = node.querySelector('.page-header h2') || node.querySelector('h2');
  if(!h2) return;
  const textNode = Array.from(h2.childNodes).find(n=>n.nodeType===3 && n.textContent.trim());
  if(textNode) textNode.textContent = cfg.label + ' ';
  else h2.insertBefore(document.createTextNode(cfg.label + ' '), h2.firstChild);
}

