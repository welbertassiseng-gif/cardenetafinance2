/* ---------- barra de busca / período / filtros ---------- */
function gxFilterBarHTML(mode){
  const f = GX.filters;
  const n = gxActiveFilterCount();
  let picks = '';
  if(mode==='all'){
    picks = `<div><h5>Categoria</h5><div class="gx-picks">${
      Array.from(gxUniverse().values()).map(e=>`<button type="button" class="gx-pick ${f.cats.includes(e.key)?'on':''}" data-pick="${escAttr(e.key)}">${escapeHtml(e.name||'Sem nome')}</button>`).join('') || '<span class="gx-count-txt">Nenhuma categoria ainda.</span>'
    }</div></div>`;
  }
  return `
    <div class="gx-fbar" data-no-undo>
      <label class="gx-search">${gxUi('search')}<input type="search" id="gxSearch" placeholder="Buscar transação" autocomplete="off" value="${escAttr(f.search)}" aria-label="Buscar transação"></label>
      <select class="gx-select" id="gxPeriod" aria-label="Período">${gxPeriodOptions()}</select>
      <button type="button" class="gx-fbtn ${GX.filtersOpen||n?'on':''}" id="gxFBtn" aria-expanded="${GX.filtersOpen}">${gxUi('filter')}<span>Filtros</span><span class="gx-badge ${n?'show':''}" id="gxBadge">${n}</span></button>
    </div>
    <div class="gx-panel ${GX.filtersOpen?'open':''}" id="gxPanel" data-no-undo><div class="gx-panel-inner"><div class="gx-panel-body">
      ${picks}
      <div><h5>Faixa de valor</h5>
        <div class="gx-range">
          <div><label for="gxMin">Mínimo</label><input type="text" id="gxMin" inputmode="decimal" placeholder="0,00" value="${f.min!==null?escAttr(moneyDisplay(f.min)):''}" autocomplete="off"></div>
          <div><label for="gxMax">Máximo</label><input type="text" id="gxMax" inputmode="decimal" placeholder="sem limite" value="${f.max!==null?escAttr(moneyDisplay(f.max)):''}" autocomplete="off"></div>
        </div>
      </div>
      <div><button type="button" class="btn secondary small" data-clear-all>Limpar filtros</button></div>
    </div></div></div>`;
}
function gxChipsHTML(){
  const f = GX.filters, uni = gxUniverse(), chips = [];
  if(f.period!=='month') chips.push(['period', 'Período: '+gxPeriodLabel(f.period)]);
  f.cats.forEach(k=>{ const e = uni.get(k); chips.push(['cat:'+k, 'Categoria: '+(e?e.name:k)]); });
  if(f.search.trim()) chips.push(['search', 'Busca: '+f.search.trim()]);
  if(f.min!==null || f.max!==null){
    const a = f.min!==null ? 'de '+fmt(f.min) : '', b = f.max!==null ? 'até '+fmt(f.max) : '';
    chips.push(['value', 'Valor: '+[a,b].filter(Boolean).join(' ')]);
  }
  if(!chips.length) return '';
  return chips.map(c=>`<span class="gx-chip"><span>${escapeHtml(c[1])}</span><button type="button" data-chip="${escAttr(c[0])}" aria-label="Remover filtro">×</button></span>`).join('')
    + `<button type="button" class="gx-chip-clear" data-clear-all>Limpar todos</button>`;
}
function gxSyncControls(root){
  const f = GX.filters;
  const s = root.querySelector('#gxSearch'); if(s && s.value!==f.search) s.value = f.search;
  const p = root.querySelector('#gxPeriod'); if(p) p.value = f.period;
  const a = root.querySelector('#gxMin'); if(a) a.value = f.min!==null ? moneyDisplay(f.min) : '';
  const b = root.querySelector('#gxMax'); if(b) b.value = f.max!==null ? moneyDisplay(f.max) : '';
  root.querySelectorAll('[data-pick]').forEach(x=>x.classList.toggle('on', f.cats.includes(x.dataset.pick)));
}
function gxClearAll(){
  GX.filters.search = ''; GX.filters.min = null; GX.filters.max = null; GX.filters.period = 'month';
  GX.limit = 60;
  if(GX.view==='detail'){ GX.filters.cats = []; GX.view = 'all'; GX.catKey = null; renderSection(); showToast('filtros limpos', false); return; }
  GX.filters.cats = [];
  showToast('filtros limpos', false);
  renderSection();
}

/* atualiza chips, contagem e lista sem recriar a página (a busca não perde o foco) */
function gxRefresh(root, animate){
  root = root || document;
  const box = root.querySelector('#gxResults'); if(!box) return;
  const list = gxCurrentList();
  GX._rows = list.rows;
  const chips = root.querySelector('#gxChips'); if(chips) chips.innerHTML = gxChipsHTML();
  const n = gxActiveFilterCount();
  const badge = root.querySelector('#gxBadge'); if(badge){ badge.textContent = n; badge.classList.toggle('show', n>0); }
  const fb = root.querySelector('#gxFBtn'); if(fb) fb.classList.toggle('on', GX.filtersOpen || n>0);
  const cnt = root.querySelector('#gxCount');
  if(cnt) cnt.innerHTML = `Exibindo <b>${gxPlural(list.rows.length,'transação','transações')}</b>${list.rows.length ? ` · <span class="mono">${gxMoneySigned(list.total)}</span>` : ''}`;
  const detail = GX.view==='detail';
  const multi = list.months.length>1;
  const uni = gxUniverse();
  if(!list.rows.length){
    const filtered = n>0 && !(n===1 && detail);
    box.innerHTML = `<div class="gx-list"><div class="gx-empty">
      <div class="gx-empty-ico">${gxUi(filtered?'search':'receipt')}</div>
      <h4>${filtered ? 'Nenhuma transação encontrada' : 'Nenhuma despesa por aqui'}</h4>
      <p>${filtered ? 'Nenhum lançamento combina com a busca e os filtros atuais.' : `Ainda não há despesas em ${escapeHtml(gxPeriodLabel(GX.filters.period))}${detail?' nesta categoria':''}.`}</p>
      ${filtered ? '<button type="button" class="btn secondary small" data-clear-all>Limpar filtros</button>' : '<button type="button" class="btn small" data-open-add>+ Adicionar despesa</button>'}
    </div></div>`;
  } else {
    const shown = list.rows.slice(0, GX.limit);
    const rows = shown.map((t,i)=>{
      const color = gxColorFor(t.key);
      const ik = gxIconKey(t.key, t.catName);
      const showCat = !detail;
      return `<div class="gx-tx ${GX.flash===t.item?'is-new':''}" role="button" tabindex="0" data-i="${i}">
        ${showCat ? `<span class="gx-tx-ico" style="background:${gxTint(color,'22')}; color:${color};">${gxIconMarkup(t.key, t.catName)}</span>` : ''}
        <div class="gx-tx-main">
          <div class="gx-tx-desc">${escapeHtml(t.desc)}</div>
          <div class="gx-tx-meta"><span>${escapeHtml(gxFmtDate(t))}</span>${showCat ? `<span class="gx-tx-cat">${escapeHtml(t.catName)}</span>` : ''}${t.item.banco ? `<span class="gx-tx-bank" title="banco">${escapeHtml(t.item.banco)}</span>` : ''}${(multi && t.date) ? `<span>· ${escapeHtml(t.month.label)}</span>` : ''}</div>
        </div>
        <div class="gx-tx-amt mono ${t.value<0?'pos':''}">${gxMoneySigned(t.value)}</div>
        <button type="button" class="gx-tx-del" data-del="${i}" aria-label="Excluir despesa" title="Excluir">${gxUi('trash')}</button>
      </div>`;
    }).join('');
    const more = list.rows.length>shown.length ? `<button type="button" class="gx-more-btn" data-more>Mostrar mais (${list.rows.length-shown.length} restantes)</button>` : '';
    box.innerHTML = `<div class="gx-list">${rows}${more}</div>`;
  }
  if(animate){ box.classList.remove('gx-results-in'); void box.offsetWidth; box.classList.add('gx-results-in'); }
}
function gxWireList(wrap){
  const box = wrap.querySelector('#gxResults');
  wrap.addEventListener('click', e=>{
    const chip = e.target.closest('[data-chip]');
    if(chip){
      const t = chip.dataset.chip, f = GX.filters;
      if(t==='period') f.period = 'month';
      else if(t==='search') f.search = '';
      else if(t==='value'){ f.min = null; f.max = null; }
      else if(t.startsWith('cat:')){
        const k = t.slice(4);
        if(GX.view==='detail'){ f.cats = []; gxLeaveDetail('all'); return; }
        f.cats = f.cats.filter(x=>x!==k);
      }
      GX.limit = 60; gxSyncControls(wrap); gxRefresh(wrap, true); showToast('filtro removido', false);
      return;
    }
    if(e.target.closest('[data-clear-all]')){ gxClearAll(); return; }
    if(e.target.closest('[data-open-add]')){
      GX.addOpen = true;
      const p = wrap.querySelector('#gxAddWrap'); if(p) p.classList.add('open');
      const d = wrap.querySelector('#qaDesc'); if(d) setTimeout(()=>d.focus(), 260);
      return;
    }
    if(e.target.closest('[data-more]')){ GX.limit += 60; gxRefresh(wrap, false); return; }
    const pick = e.target.closest('[data-pick]');
    if(pick){
      const k = pick.dataset.pick, f = GX.filters;
      f.cats = f.cats.includes(k) ? f.cats.filter(x=>x!==k) : f.cats.concat([k]);
      pick.classList.toggle('on', f.cats.includes(k));
      GX.limit = 60; gxRefresh(wrap, true);
      return;
    }
    const del = e.target.closest('[data-del]');
    if(del){ e.stopPropagation(); const t = GX._rows[Number(del.dataset.del)]; if(t) gxDeleteTx(t); return; }
    const row = e.target.closest('.gx-tx');
    if(row){ const t = GX._rows[Number(row.dataset.i)]; if(t) gxOpenTxEditor(t); }
  });
  wrap.addEventListener('keydown', e=>{
    if((e.key==='Enter' || e.key===' ') && e.target.classList && e.target.classList.contains('gx-tx')){
      e.preventDefault(); const t = GX._rows[Number(e.target.dataset.i)]; if(t) gxOpenTxEditor(t);
    }
  });
  const s = wrap.querySelector('#gxSearch');
  if(s) s.addEventListener('input', ()=>{ GX.filters.search = s.value; GX.limit = 60; gxRefresh(wrap, false); });
  const p = wrap.querySelector('#gxPeriod');
  if(p) p.addEventListener('change', ()=>{ GX.filters.period = p.value; GX.limit = 60; gxRefresh(wrap, true); });
  const fb = wrap.querySelector('#gxFBtn');
  if(fb) fb.addEventListener('click', ()=>{
    GX.filtersOpen = !GX.filtersOpen;
    wrap.querySelector('#gxPanel').classList.toggle('open', GX.filtersOpen);
    fb.setAttribute('aria-expanded', GX.filtersOpen);
    gxRefresh(wrap, false);
  });
  const rng = (id, prop)=>{
    const i = wrap.querySelector(id); if(!i) return;
    i.addEventListener('input', ()=>{ GX.filters[prop] = i.value.trim()==='' ? null : parseMoney(i.value); GX.limit = 60; gxRefresh(wrap, false); });
    gxBindMoney(i);
  };
  rng('#gxMin','min'); rng('#gxMax','max');
  const sortSel = wrap.querySelector('#gxSort');
  if(sortSel) sortSel.addEventListener('change', ()=>{ GX.sort = sortSel.value; gxRefresh(wrap, true); });
  gxRefresh(wrap, false);
}
function gxListHeadHTML(){
  return `<div class="gx-list-head" data-no-undo>
    <div class="gx-count-txt" id="gxCount"></div>
    <label class="gx-sort">Ordenado por
      <select class="gx-select" id="gxSort" aria-label="Ordenar">
        <option value="recent" ${GX.sort==='recent'?'selected':''}>Mais recentes</option>
        <option value="oldest" ${GX.sort==='oldest'?'selected':''}>Mais antigas</option>
        <option value="high" ${GX.sort==='high'?'selected':''}>Maior valor</option>
        <option value="low" ${GX.sort==='low'?'selected':''}>Menor valor</option>
        <option value="az" ${GX.sort==='az'?'selected':''}>Descrição (A–Z)</option>
        <option value="banco" ${GX.sort==='banco'?'selected':''}>Banco (A–Z)</option>
      </select></label>
  </div>`;
}

