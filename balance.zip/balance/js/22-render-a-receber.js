/* =========================================================
   RENDER: DINHEIRO A RECEBER
========================================================= */
function renderReceber(){
  const el = document.createElement('div');
  const totalPend = receivablesPendingTotal();
  const totalReceb = state.receivables.filter(r=>r.status==='recebido').reduce((s,r)=>s+(Number(r.valor)||0),0);
  const loansTotal = state.loans.reduce((s,l)=>s+loanRemaining(l),0);

  el.innerHTML = `
    <div class="page-header">
      <div><h2>Dinheiro a Receber</h2><div class="desc">Valores que outras pessoas te devem, e empréstimos parcelados que você fez. Marque como recebido/pago e os totais se ajustam sozinhos.</div></div>
    </div>
    <div class="grid-3">
      <div class="stat pos"><div class="label">Pendente</div><div class="value mono" id="stat-pendente">${fmt(totalPend)}</div></div>
      <div class="stat"><div class="label">Já recebido</div><div class="value mono" id="stat-recebido">${fmt(totalReceb)}</div></div>
      <div class="stat neg"><div class="label">Empréstimos em aberto</div><div class="value mono" id="stat-loans">${fmt(loansTotal)}</div></div>
    </div>

    <div class="card" style="margin-top:22px;">
      <h3>A receber de terceiros</h3>
      <div class="table-wrap"><table class="responsive-table">
        <thead><tr><th style="width:120px">Data</th><th>Devedor</th><th>Descrição</th><th class="num" style="width:110px">Valor</th><th style="width:110px">Status</th><th style="width:50px"></th></tr></thead>
        <tbody id="recvBody"></tbody>
      </table></div>
      <button class="btn secondary small" id="btnAddRecv" style="margin-top:14px;">+ novo registro</button>
    </div>

    <div class="card">
      <h3>Empréstimos parcelados (que você concedeu)</h3>
      <div class="table-wrap"><table class="responsive-table">
        <thead><tr><th>Nome</th><th class="num">Valor total</th><th class="num">Parcelas</th><th class="num">Valor/parcela</th><th class="num">Pagas</th><th class="num">Restante</th><th style="width:50px"></th></tr></thead>
        <tbody id="loanBody"></tbody>
      </table></div>
      <button class="btn secondary small" id="btnAddLoan" style="margin-top:14px;">+ novo empréstimo</button>
    </div>
  `;

  const recvBody = el.querySelector('#recvBody');
  if(state.receivables.length===0){
    recvBody.innerHTML = `<tr><td colspan="6"><div class="empty-state">Nenhum registro ainda. Clique em "+ novo registro" para adicionar.</div></td></tr>`;
  }
  state.receivables.forEach((r,i)=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td data-label="Data"><input type="date" value="${r.data||''}" data-role="data"></td>
      <td class="cell-plain"><input type="text" value="${escAttr(r.devedor)}" data-role="devedor" placeholder="Devedor"></td>
      <td data-label="Descrição"><input type="text" value="${escAttr(r.descricao)}" data-role="descricao"></td>
      <td class="num" data-label="Valor"><input type="text" inputmode="decimal" class="money" data-role="valor"></td>
      <td data-label="Status">
        <select data-role="status">
          <option value="pendente" ${r.status==='pendente'?'selected':''}>Pendente</option>
          <option value="recebido" ${r.status==='recebido'?'selected':''}>Recebido</option>
        </select>
      </td>
      <td><button class="icon-btn" data-role="del">✕</button></td>
    `;
    tr.querySelector('[data-role=data]').addEventListener('input', e=>{ r.data=e.target.value; scheduleSave(); });
    tr.querySelector('[data-role=devedor]').addEventListener('input', e=>{ r.devedor=e.target.value; scheduleSave(); });
    tr.querySelector('[data-role=descricao]').addEventListener('input', e=>{ r.descricao=e.target.value; scheduleSave(); });
    bindMoneyInput(tr.querySelector('[data-role=valor]'), ()=>r.valor, v=>r.valor=v, recalcReceber);
    tr.querySelector('[data-role=status]').addEventListener('change', e=>{ r.status=e.target.value; scheduleSave(); recalcReceber(); });
    tr.querySelector('[data-role=del]').addEventListener('click', ()=>{ state.receivables.splice(i,1); scheduleSave(); renderSection(); });
    recvBody.appendChild(tr);
  });
  el.querySelector('#btnAddRecv').addEventListener('click', ()=>{
    state.receivables.push({id:uid(), data:'', devedor:'', descricao:'', valor:0, status:'pendente'});
    scheduleSave(); renderSection();
  });

  const loanBody = el.querySelector('#loanBody');
  if(state.loans.length===0){
    loanBody.innerHTML = `<tr><td colspan="7"><div class="empty-state">Nenhum empréstimo cadastrado ainda.</div></td></tr>`;
  }
  state.loans.forEach((l,i)=>{
    const restante = loanRemaining(l);
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="cell-plain"><input type="text" value="${escAttr(l.nome)}" data-role="nome"></td>
      <td class="num" data-label="Valor total"><input type="text" inputmode="decimal" class="money" data-role="valorTotal"></td>
      <td class="num" data-label="Parcelas"><input type="text" inputmode="decimal" class="money" data-role="parcelas"></td>
      <td class="num" data-label="Valor/parcela"><input type="text" inputmode="decimal" class="money" data-role="valorParcela"></td>
      <td class="num" data-label="Pagas"><input type="text" inputmode="decimal" class="money" data-role="parcelasPagas"></td>
      <td class="num mono" data-label="Restante" id="loan-restante-${i}" style="font-weight:600;">${fmt(restante)}</td>
      <td><button class="icon-btn" data-role="del">✕</button></td>
    `;
    tr.querySelector('[data-role=nome]').addEventListener('input', e=>{ l.nome=e.target.value; scheduleSave(); });
    bindMoneyInput(tr.querySelector('[data-role=valorTotal]'), ()=>l.valorTotal, v=>l.valorTotal=v);
    bindMoneyInput(tr.querySelector('[data-role=parcelas]'), ()=>l.parcelas, v=>l.parcelas=Math.round(v), recalcLoans);
    bindMoneyInput(tr.querySelector('[data-role=valorParcela]'), ()=>l.valorParcela, v=>l.valorParcela=v, recalcLoans);
    bindMoneyInput(tr.querySelector('[data-role=parcelasPagas]'), ()=>l.parcelasPagas, v=>l.parcelasPagas=Math.round(v), recalcLoans);
    tr.querySelector('[data-role=del]').addEventListener('click', ()=>{ state.loans.splice(i,1); scheduleSave(); renderSection(); });
    loanBody.appendChild(tr);
  });
  el.querySelector('#btnAddLoan').addEventListener('click', ()=>{
    state.loans.push({id:uid(), nome:'', valorTotal:0, parcelas:1, valorParcela:0, parcelasPagas:0});
    scheduleSave(); renderSection();
  });

  return el;
}
function recalcReceber(){
  const pend = document.getElementById('stat-pendente');
  if(pend) pend.textContent = fmt(receivablesPendingTotal());
  const rec = document.getElementById('stat-recebido');
  if(rec) rec.textContent = fmt(state.receivables.filter(r=>r.status==='recebido').reduce((s,r)=>s+(Number(r.valor)||0),0));
  const loansEl = document.getElementById('stat-loans');
  if(loansEl) loansEl.textContent = fmt(state.loans.reduce((s,l)=>s+loanRemaining(l),0));
}
function recalcLoans(){
  state.loans.forEach((l,i)=>{
    const cell = document.getElementById('loan-restante-'+i);
    if(cell) cell.textContent = fmt(loanRemaining(l));
  });
  recalcReceber();
}

