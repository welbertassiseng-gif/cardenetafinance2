/* =========================================================
   TEMA (claro / escuro)
========================================================= */
function applySavedTheme(){
  const saved = localStorage.getItem('balance_theme') || 'light';
  setTheme(saved, false);
}
function setTheme(mode, persist){
  document.body.classList.toggle('theme-dark', mode === 'dark');
  if(persist !== false) localStorage.setItem('balance_theme', mode);
  const lightBtn = document.getElementById('themeLightBtn');
  const darkBtn = document.getElementById('themeDarkBtn');
  if(lightBtn && darkBtn){
    lightBtn.classList.toggle('active', mode !== 'dark');
    darkBtn.classList.toggle('active', mode === 'dark');
  }
}

