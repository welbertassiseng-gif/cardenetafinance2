/* ---------- visão: TODAS ---------- */
function gxBuildAll(body, month){
  const wrap = document.createElement('div');
  wrap.className = 'gx-view';
  wrap.innerHTML = `
    ${gxFilterBarHTML('all')}
    <div class="gx-chips" id="gxChips" data-no-undo></div>
    <div class="gx-actions-row">
      <button type="button" class="btn" id="gxBtnAdd">+ Adicionar</button>
    </div>
    ${gxAddPanelHTML(month)}
    ${gxListHeadHTML()}<div id="gxResults"></div>`;
  body.appendChild(wrap);
  gxWireAddPanel(wrap, month);
  gxWireList(wrap);
}

function gxMigrateMetaKey(oldKey, newKey){
  if(oldKey===newKey || !state.categoryMeta || !state.categoryMeta[oldKey] || state.categoryMeta[newKey]) return;
  if(gxUniverse().has(oldKey)) return; // outro mês ainda usa o nome antigo
  state.categoryMeta[newKey] = state.categoryMeta[oldKey];
  delete state.categoryMeta[oldKey];
}
/* ---------- visão: CATEGORIAS (cartões) ---------- */
function gxCardHTML(s, nMonths, idx){
  const color = gxColorFor(s.key);
  const ik = gxIconKey(s.key, s.name);
  const desc = gxDescFor(s.key, s.name, ik, s.examples);
  let trend = '';
  if(s.total>0 && s.prevTotal>0){
    const pct = (s.total-s.prevTotal)/s.prevTotal*100;
    if(Math.abs(pct)>=1) trend = `<span class="gx-trend ${pct>0?'up':'down'}" title="${pct>0?'+':''}${Math.round(pct)}% vs. período anterior">${pct>0?'↑':'↓'}</span>`;
  }
  const b = gxBudgetInfo(s.key, s.total, nMonths);
  const foot = b
    ? `<div class="gx-bud-row"><span>Orçamento${nMonths>1?' ('+nMonths+' meses)':''}</span><b>${fmt(b.limit)}</b><button type="button" class="gx-bud-edit" data-budget="${escAttr(s.key)}" aria-label="Editar orçamento">${gxUi('pencil')}</button></div>
       <div class="gx-progress ${b.cls}"><i style="width:${Math.min(100,Math.max(0,b.pct)).toFixed(1)}%"></i></div>
       <div class="gx-bud-note ${b.cls==='over'?'over':''}">${b.left>=0 ? 'Restam '+fmt(b.left)+' · '+Math.round(b.pct)+'% usado' : 'Excedido em '+fmt(-b.left)}</div>`
    : `<button type="button" class="gx-bud-cta" data-budget="${escAttr(s.key)}">Definir orçamento ${gxUi('pencil')}</button>`;
  return `<article class="gx-card" role="button" tabindex="0" data-cat="${escAttr(s.key)}" style="--cc:${color}; animation-delay:${Math.min(idx,12)*30}ms" data-no-undo>
    <div class="gx-card-top">
      <span class="gx-ico" style="background:${gxTint(color,'22')}; color:${color};">${gxIconMarkup(s.key, s.name)}</span>
      <button type="button" class="gx-more" data-menu="${escAttr(s.key)}" aria-label="Ações da categoria" aria-haspopup="menu">${gxUi('dots')}</button>
    </div>
    <div class="gx-card-name"><span class="n">${escapeHtml(s.name||'Sem nome')}</span>${trend}</div>
    <div class="gx-card-desc">${escapeHtml(desc)}</div>
    <div class="gx-card-val ${s.total===0?'zero':(s.total<0?'pos':'')}">${s.total===0?fmt(0):gxMoneySigned(s.total)}</div>
    <div class="gx-card-count">${gxPlural(s.count,'transação','transações')}</div>
    <div class="gx-card-foot">${foot}</div>
  </article>`;
}
function gxBuildCats(body, month){
  const wrap = document.createElement('div');
  wrap.className = 'gx-view';
  const period = GX.filters.period;
  const stats = gxCategoryStats(period);
  const nMonths = Math.max(1, gxMonthsOf(period).length);
  const neg = stats.filter(s=>s.total!==0).sort((a,b)=>Math.abs(b.total)-Math.abs(a.total));
  const zero = stats.filter(s=>s.total===0).sort((a,b)=>String(a.name).localeCompare(String(b.name),'pt-BR'));
  const negSum = neg.reduce((s,x)=>s+x.total,0);
  let i = 0;
  const group = (title, list, meta, extra)=> `<section class="gx-group">
      <div class="gx-group-head"><span class="gx-group-title">${title}</span><span class="gx-group-meta">${meta}</span></div>
      <div class="gx-cat-grid">${list.map(s=>gxCardHTML(s, nMonths, i++)).join('')}${extra||''}</div></section>`;
  const newBtn = `<button type="button" class="gx-newcat" data-newcat>${gxUi('plus',18)} Nova categoria</button>`;
  let html = `<div class="gx-cats-head" data-no-undo>
      <select class="gx-select" id="gxPeriod" aria-label="Período">${gxPeriodOptions()}</select>
      <button type="button" class="btn secondary small" data-newcat>+ Nova categoria</button>
    </div>`;
  if(!stats.length){
    html += `<div class="card"><div class="gx-empty"><div class="gx-empty-ico">${gxUi('shapes')}</div><h4>Nenhuma categoria ainda</h4><p>Crie a primeira categoria ou adicione uma despesa para ela aparecer aqui.</p><button type="button" class="btn small" data-newcat>+ Nova categoria</button></div></div>`;
  } else {
    html += neg.length ? group('Negativas', neg, `${neg.length} · ${gxMoneySigned(negSum)}`, zero.length?'':newBtn)
      : `<div class="card"><div class="gx-empty" style="padding:26px 20px;"><h4>Nada gasto em ${escapeHtml(gxPeriodLabel(period))}</h4><p>Nenhuma categoria teve movimentação neste período.</p></div></div>`;
    if(zero.length) html += group('Zeradas', zero, gxPlural(zero.length,'categoria','categorias'), newBtn);
  }
  wrap.innerHTML = html;
  body.appendChild(wrap);
  const p = wrap.querySelector('#gxPeriod');
  if(p) p.addEventListener('change', ()=>{ GX.filters.period = p.value; renderSection(); });
  wrap.addEventListener('click', e=>{
    if(e.target.closest('[data-newcat]')){ gxNewCategory(); return; }
    const more = e.target.closest('[data-menu]');
    if(more){ e.stopPropagation(); gxOpenMenu(more, more.dataset.menu); return; }
    const bud = e.target.closest('[data-budget]');
    if(bud){ e.stopPropagation(); gxOpenBudget(bud.dataset.budget); return; }
    const card = e.target.closest('.gx-card');
    if(card) gxOpenCategory(card.dataset.cat);
  });
  wrap.addEventListener('keydown', e=>{
    if((e.key==='Enter' || e.key===' ') && e.target.classList && e.target.classList.contains('gx-card')){ e.preventDefault(); gxOpenCategory(e.target.dataset.cat); }
  });
}

/* ---------- visão: DETALHE DA CATEGORIA ---------- */
// Média mensal "real": considera TODOS os meses cadastrados da categoria, do primeiro mês com
// gasto até o mês atual do calendário (nunca entra mês futuro, mesmo que a pessoa já tenha
// editado valores nele) — meses com R$ 0 na categoria não contam para a média.
function gxCatAverage(key){
  const months = state.months||[];
  const cur = currentMonthRank();
  const totalOf = m=>{ let t=0; (m.categories||[]).forEach(c=>{ if(gxKey(c.name)===key) t += categoryTotal(c); }); return t; };
  const eligible = months
    .map(m=>({ rank: monthLabelRank(m.label), total: totalOf(m) }))
    .filter(x=>x.rank!==null && x.rank<=cur);
  const closed = eligible.filter(x=>x.rank!==cur && x.total>0);
  const base = closed.length ? closed : eligible.filter(x=>x.total>0);
  const avg = base.length ? base.reduce((s,x)=>s+x.total,0)/base.length : 0;
  const note = base.length ? `média de ${gxPlural(base.length,'mês com gasto','meses com gasto')}` : 'sem gastos registrados';
  return {avg, note};
}
// Últimos 6 meses terminando no mês selecionado — valores reais somados por mês cadastrado
function gxCatSeries(key){
  const months = state.months||[];
  const selIdx = months.findIndex(m=>m.id===state.selectedMonth);
  const sel = months[selIdx];
  const out = [];
  const totalOf = ms=>{ let t = 0; ms.forEach(m=>(m.categories||[]).forEach(c=>{ if(gxKey(c.name)===key) t += categoryTotal(c); })); return t; };
  const selRank = sel ? monthLabelRank(sel.label) : null;
  const cur = currentMonthRank();
  if(selRank!==null){
    for(let r=selRank-5; r<=selRank; r++){
      const ms = months.filter(m=>monthLabelRank(m.label)===r);
      out.push({label:GX_MONTH_SHORT[((r%12)+12)%12]+'/'+String(Math.floor(r/12)).slice(2), registered:ms.length>0, total:totalOf(ms), partial:r===cur, sel:r===selRank});
    }
  } else if(sel){
    months.slice(Math.max(0,selIdx-5), selIdx+1).forEach(m=>{
      out.push({label:String(m.label).split(' / ')[0].slice(0,7), registered:true, total:totalOf([m]), partial:false, sel:m===sel});
    });
  }
  return out;
}
function gxChartHTML(key, color){
  const series = gxCatSeries(key);
  const {avg, note} = gxCatAverage(key);
  const hasPartial = series.some(s=>s.partial);
  const max = Math.max(1, ...series.map(s=>s.total));
  const anyData = series.some(s=>s.total>0);
  let chart;
  if(!anyData){
    chart = `<div class="gx-chart-empty">Ainda não há gastos nesta categoria nos últimos 6 meses.</div>`;
  } else {
    const cols = series.map((s,i)=>{
      const p = s.registered ? s.total/max : 0;
      const label = !s.registered ? '—' : gxShortNum(s.total);
      return `<div class="gx-col" title="${escAttr(s.label+': '+(s.registered ? fmt(s.total)+(s.partial?' (mês parcial)':'') : 'mês não cadastrado'))}" style="--p:${p.toFixed(4)}; --i:${i};">
        <div class="gx-bar ${s.partial?'partial':''} ${(!s.registered || s.total<=0)?'none':''}"></div>
        <div class="gx-val ${(!s.registered||s.total<=0)?'muted':''}">${label}</div></div>`;
    }).join('');
    const xl = series.map(s=>`<div class="${s.sel?'sel':''}">${escapeHtml(s.label)}${s.partial?'<small>parcial</small>':''}</div>`).join('');
    chart = `<div class="gx-chart" style="--n:${series.length}; --cc:${color};" role="img" aria-label="Despesas da categoria nos últimos ${series.length} meses">
      <div class="gx-plot"><div class="gx-base"></div>
        ${avg>0 ? `<div class="gx-avgline" style="--p:${Math.min(1,avg/max).toFixed(4)};"><span>média</span></div>` : ''}
        <div class="gx-cols">${cols}</div></div>
      <div class="gx-xl">${xl}</div></div>`;
  }
  return {chart, avg, note, hasPartial};
}
function gxBuildDetail(body, month){
  const e = gxUniverse().get(GX.catKey);
  const key = GX.catKey;
  const color = gxColorFor(key);
  const ik = gxIconKey(key, e.name);
  const c = gxChartHTML(key, color);
  const list = gxCurrentList();
  const nMonths = Math.max(1, list.months.length);
  const catAll = list.all.filter(t=>t.key===key);
  const spent = catAll.reduce((s,t)=>s+t.value,0);
  const b = gxBudgetInfo(key, spent, nMonths);
  const budgetCell = b
    ? `<div class="l">Orçamento · ${Math.round(b.pct)}%</div><div class="v">${fmt(b.limit)}</div><div class="gx-progress ${b.cls}"><i style="width:${Math.min(100,Math.max(0,b.pct)).toFixed(1)}%"></i></div>`
    : `<div class="l">Orçamento</div><button type="button" class="gx-bud-cta" data-budget="${escAttr(key)}">Definir orçamento ${gxUi('pencil')}</button>`;
  const wrap = document.createElement('div');
  wrap.className = 'gx-view';
  wrap.innerHTML = `
    <nav class="gx-crumbs" aria-label="Navegação" data-no-undo>
      <button type="button" class="month-nav-arrow" data-go="cats" title="Voltar para Categorias" aria-label="Voltar para Categorias">‹</button>
      <button type="button" class="gx-crumb" data-go="all">Despesas</button><span class="gx-sep">›</span>
      <button type="button" class="gx-crumb" data-go="cats">Categorias</button><span class="gx-sep">›</span>
      <span class="gx-crumb current" aria-current="page">${escapeHtml(e.name||'Sem nome')}</span>
    </nav>
    ${gxFilterBarHTML('detail')}
    <div class="gx-chips" id="gxChips" data-no-undo></div>
    <section class="card gx-chart-card">
      <div class="gx-detail-head">
        <div class="gx-detail-title">
          <span class="gx-ico" style="background:${gxTint(color,'22')}; color:${color};">${gxIconMarkup(key, e.name)}</span>
          <div><h3>Gastos em ${escapeHtml(e.name||'Sem nome')}</h3>
          <div class="gx-eyebrow">Últimos 6 meses${c.hasPartial?' · mês atual parcial':''}</div></div>
        </div>
        <div class="gx-avg"><div class="gx-eyebrow" style="margin:0 0 4px;">Total · ${escapeHtml(gxPeriodLabel(GX.filters.period))}</div><div class="v">${gxMoneySigned(spent)}</div></div>
      </div>
      ${c.chart}
      <div class="gx-detail-stats">
        <div class="gx-mini"><div class="l">Média mensal</div><div class="v">${fmt(c.avg)}</div><div class="s">${escapeHtml(c.note)}</div></div>
        <div class="gx-mini"><div class="l">Transações</div><div class="v">${catAll.length}</div></div>
        <div class="gx-mini">${budgetCell}</div>
      </div>
    </section>
    <div class="gx-actions-row"><button type="button" class="btn" id="gxBtnAdd">+ Adicionar</button></div>
    ${gxAddPanelHTML(month)}
    ${gxListHeadHTML()}
    <div id="gxResults"></div>`;
  body.appendChild(wrap);
  wrap.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click', ()=>gxLeaveDetail(b.dataset.go)));
  const bud = wrap.querySelector('[data-budget]');
  if(bud) bud.addEventListener('click', ()=>gxOpenBudget(key));
  gxWireAddPanel(wrap, month);
  gxWireList(wrap);
}

/* ---------- abas Todas / Categorias ---------- */
function gxTabsEl(){
  const period = GX.filters.period;
  const txs = gxTx(gxMonthsOf(period));
  const sums = new Map();
  txs.forEach(t=>sums.set(t.key,(sums.get(t.key)||0)+t.value));
  const catCount = Array.from(sums.values()).filter(v=>v!==0).length;
  const el = document.createElement('div');
  el.className = 'gx-tabs'; el.setAttribute('role','tablist'); el.setAttribute('data-no-undo','');
  el.innerHTML = `
    <button type="button" class="gx-tab ${GX.view==='all'?'active':''}" role="tab" aria-selected="${GX.view==='all'}" data-gx-view="all">Todas <span class="gx-count">${txs.length}</span></button>
    <button type="button" class="gx-tab ${GX.view==='cats'?'active':''}" role="tab" aria-selected="${GX.view==='cats'}" data-gx-view="cats">Categorias <span class="gx-count">${catCount}</span></button>`;
  el.querySelectorAll('[data-gx-view]').forEach(b=>b.addEventListener('click', ()=>{
    if(GX.view===b.dataset.gxView) return;
    GX.view = b.dataset.gxView; GX.limit = 60;
    renderSection();
  }));
  return el;
}

