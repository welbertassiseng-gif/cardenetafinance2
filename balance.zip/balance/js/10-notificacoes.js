/* =========================================================
   NOTIFICAÇÕES — alertas reais calculados a partir dos dados
========================================================= */
const MESES_PT = ['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];
function normalizeMonthLabel(s){
  return String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim();
}
// Acha, dentre os meses cadastrados, o que corresponde ao mês/ano atual do calendário real
// (evita notificar sobre gastos de meses futuros já cadastrados com antecedência)
function getCurrentCalendarMonth(){
  const months = state.months || [];
  if(!months.length) return null;
  const now = new Date();
  const mesAtual = normalizeMonthLabel(MESES_PT[now.getMonth()]);
  const anoAtual = String(now.getFullYear());
  return months.find(m=>{
    const l = normalizeMonthLabel(m.label);
    return l.includes(mesAtual) && l.includes(anoAtual);
  }) || null;
}

function computeNotifications(){
  const list = [];
  if(!state) return list;
  const push = (id, type, title, text)=>list.push({id, type, title, text});
  const months = state.months || [];
  const lastMonth = getCurrentCalendarMonth(); // só notifica sobre o mês atual, nunca sobre meses seguintes já cadastrados
  const receitasDe = (m)=>{ const s = state.salaries.find(x=>x.monthId===m.id); return s ? salaryTotal(s) : 0; };

  if(lastMonth){
    const sal = state.salaries.find(s=>s.monthId===lastMonth.id);
    const gastos = monthTotal(lastMonth);
    const receitas = sal ? salaryTotal(sal) : 0;

    // 1) média dos meses anteriores com gasto lançado
    const anteriores = months.slice(0,-1).map(monthTotal).filter(v=>v>0);
    if(anteriores.length >= 2 && gastos > 0){
      const media = anteriores.reduce((a,b)=>a+b,0)/anteriores.length;
      const diff = (gastos - media) / media;
      if(diff >= 0.15){
        push('gasto-acima', 'warn', 'Fique de olho nos gastos',
          `Seus gastos em ${lastMonth.label} estão ${Math.round(diff*100)}% acima do normal (${fmt(gastos)} contra uma média de ${fmt(media)}).`);
      } else if(diff <= -0.15){
        push('gasto-abaixo', 'info', 'Mês redondo',
          `Você gastou ${Math.round(Math.abs(diff)*100)}% menos que a sua média em ${lastMonth.label}. Bom momento pra reforçar a carteira.`);
      }
    }

    // 2) proporção gasto/receita
    if(receitas > 0 && gastos > 0){
      const pct = gastos / receitas;
      if(pct >= 1){
        push('saldo-neg', 'warn', 'Saldo negativo',
          `Em ${lastMonth.label} você já gastou mais do que recebeu: ${fmtPriv(receitas-gastos)} no vermelho.`);
      } else if(pct >= 0.8){
        push('gasto-80', 'warn', 'Já foram 80% da renda',
          `Os gastos de ${lastMonth.label} consumiram ${Math.round(pct*100)}% da sua receita. Sobra hoje: ${fmtPriv(receitas-gastos)}.`);
      } else if(pct <= 0.6){
        push('sobra-boa', 'info', 'Boa sobra no mês',
          `Você fechou ${lastMonth.label} usando só ${Math.round(pct*100)}% da renda — sobraram ${fmtPriv(receitas-gastos)}.`);
      }
    }

    // 3) categoria que mais pesou
    if(gastos > 0 && Array.isArray(lastMonth.categories)){
      const cats = lastMonth.categories.map(c=>({
        name: c.label || c.name || 'categoria',
        total: (c.items||[]).reduce((s,i)=>s+(Number(i.value)||0),0)
      })).sort((a,b)=>b.total-a.total);
      const top = cats[0];
      if(top && top.total / gastos >= 0.4){
        push('cat-top', 'warn', 'Uma categoria puxou o mês',
          `"${top.name}" sozinha representa ${Math.round(top.total/gastos*100)}% dos gastos de ${lastMonth.label} (${fmt(top.total)}).`);
      }
    }

    if(!sal){
      push('sem-salario', 'info', 'Falta lançar o salário',
        `Ainda não há salário lançado para ${lastMonth.label}. Sem isso o resumo fica incompleto.`);
    }
    if(gastos === 0){
      push('sem-gasto', 'info', 'Nenhum gasto lançado',
        `${lastMonth.label} ainda está sem gastos registrados. Que tal atualizar agora?`);
    }
  }

  // 4) gastos fixos pesando na renda
  const fixos = (state.fixedExpenses||[]).reduce((s,f)=>s+(Number(f.value)||0),0);
  const receitaRef = lastMonth ? receitasDe(lastMonth) : 0;
  if(fixos > 0 && receitaRef > 0 && fixos/receitaRef >= 0.5){
    push('fixos-altos', 'warn', 'Gastos fixos pesados',
      `Seus gastos fixos (${fmt(fixos)}) já comprometem ${Math.round(fixos/receitaRef*100)}% da sua renda antes de qualquer despesa nova.`);
  }

  // 5) a receber
  const pend = (state.receivables||[]).filter(r=>r.status!=='recebido');
  if(pend.length>0){
    push('a-receber', 'info', 'Dinheiro a receber',
      `Você tem ${pend.length} valor${pend.length>1?'es':''} pendente${pend.length>1?'s':''} a receber, somando ${fmt(receivablesPendingTotal())}.`);
  }

  // 6) empréstimos
  const loansOpen = (state.loans||[]).filter(l=>loanRemaining(l)>0);
  if(loansOpen.length>0){
    push('emprestimos', 'info', 'Empréstimos em aberto',
      `${loansOpen.length} empréstimo${loansOpen.length>1?'s':''} ainda em aberto, total de ${fmt(loansOpen.reduce((s,l)=>s+loanRemaining(l),0))}.`);
  }

  // 7) carteira de investimentos — meta de aporte do mês
  try{
    const w = getWallet();
    const mk = walletMonthKey();
    const aportado = walletAportadoNoMes(mk);
    const meta = Number(w.monthlyGoal)||0;
    const totalCarteira = (w.items||[]).reduce((s,i)=>s+(Number(i.saldo)||0),0);
    if(meta > 0 && aportado <= 0){
      push('aporte-zero', 'warn', 'Aporte do mês parado',
        `Sua meta é aportar ${fmt(meta)} por mês e este mês ainda está zerado.`);
    } else if(meta > 0 && aportado < meta){
      push('aporte-parcial', 'info', 'Quase lá no aporte',
        `Você já aportou ${fmt(aportado)} dos ${fmt(meta)} da meta deste mês. Faltam ${fmt(meta-aportado)}.`);
    } else if(meta > 0 && aportado >= meta){
      push('aporte-ok', 'info', 'Meta de aporte batida',
        `Meta do mês concluída: ${fmt(aportado)} aportados. Carteira em ${fmt(totalCarteira)}.`);
    }
    if(!meta && totalCarteira === 0 && (state.months||[]).length){
      push('carteira-vazia', 'info', 'Sua carteira está vazia',
        `Cadastre seus investimentos na Carteira de Investimentos pra acompanhar o patrimônio real.`);
    }
  }catch(e){ /* carteira ainda não inicializada */ }

  // 8) dados desatualizados
  if(state.lastUpdated){
    const dias = Math.floor((Date.now() - new Date(state.lastUpdated).getTime())/86400000);
    if(dias >= 10){
      push('desatualizado', 'info', 'Faz tempo que você não atualiza',
        `Seus dados não são atualizados há ${dias} dias. Uma passadinha rápida mantém tudo confiável.`);
    }
  }

  return list;
}

function renderNotifications(){
  const notifs = computeNotifications();
  const dots = [document.getElementById('bellDotDesktop'), document.getElementById('bellDotMobile')];
  dots.forEach(d=>{ if(d) d.classList.toggle('show', notifs.length>0); });
  const list = document.getElementById('notifList');
  if(list){
    list.innerHTML = notifs.length ? notifs.map(n=>`
      <div class="notif-item ${n.type}"><span class="ni-dot"></span><span><b>${escapeHtml(n.title||'')}</b><br>${escapeHtml(n.text)}</span></div>
    `).join('') : `<div class="notif-empty">Sem novidades por aqui. Tudo em dia.</div>`;
  }
  maybePushNotifications(notifs);
  refreshPushBar();
}

/* ---------- Avisos no celular (notificações locais do navegador) ---------- */
const PUSH_SEEN_KEY = 'balance_push_seen_v1';
function pushSupported(){ return typeof window !== 'undefined' && 'Notification' in window; }
function pushEnabled(){ return pushSupported() && Notification.permission === 'granted' && localStorage.getItem('balance_push_on') === '1'; }

function refreshPushBar(){
  const bar = document.getElementById('notifPushBar');
  const txt = document.getElementById('notifPushTxt');
  const btn = document.getElementById('btnEnablePush');
  if(!bar || !txt || !btn) return;
  bar.classList.remove('is-on','hide-btn');
  if(!pushSupported()){
    txt.textContent = 'Este navegador não suporta avisos no aparelho.';
    bar.classList.add('hide-btn');
  } else if(pushEnabled()){
    txt.textContent = '✓ Avisos ativados neste aparelho.';
    bar.classList.add('is-on');
    btn.textContent = 'desativar';
  } else if(Notification.permission === 'denied'){
    txt.textContent = 'Avisos bloqueados. Libere as notificações nas configurações do site.';
    bar.classList.add('hide-btn');
  } else {
    txt.textContent = 'Receba esses alertas direto no celular.';
    btn.textContent = 'ativar avisos';
  }
}

async function togglePush(){
  if(!pushSupported()){ showToast('Seu navegador não suporta notificações.', true); return; }
  if(pushEnabled()){
    localStorage.setItem('balance_push_on','0');
    refreshPushBar();
    showToast('avisos desativados');
    return;
  }
  if(window.top !== window.self && Notification.permission !== 'granted'){
    showToast('Abra o app em uma aba própria (ou pela tela de início) para ativar os avisos.', true);
    return;
  }
  let perm = Notification.permission;
  if(perm !== 'granted') perm = await Notification.requestPermission();
  if(perm !== 'granted'){ showToast('Permissão negada para notificações.', true); refreshPushBar(); return; }
  localStorage.setItem('balance_push_on','1');
  localStorage.removeItem(PUSH_SEEN_KEY);
  await ensureServiceWorker();
  refreshPushBar();
  showNativeNotification('Balance', 'Pronto! Vou te avisar por aqui quando algo precisar da sua atenção.');
  renderNotifications();
}

let swRegistration = null;
async function ensureServiceWorker(){
  if(!('serviceWorker' in navigator)) return null;
  if(swRegistration) return swRegistration;
  try{
    swRegistration = await navigator.serviceWorker.register('./sw.js');
    await navigator.serviceWorker.ready;
  }catch(e){ console.warn('service worker indisponível', e); swRegistration = null; }
  return swRegistration;
}

function showNativeNotification(title, body){
  const opts = {
    body,
    icon: document.querySelector('link[rel="apple-touch-icon"]')?.href || undefined,
    badge: document.querySelector('link[rel="apple-touch-icon"]')?.href || undefined,
    tag: 'balance-'+title,
    renotify: true,
    data: { url: location.href },
  };
  // o Service Worker consegue exibir o aviso mesmo com a aba em segundo plano
  // (e é o único caminho que funciona no Android/Chrome instalado).
  if(swRegistration && swRegistration.showNotification){
    swRegistration.showNotification(title, opts).catch(e=>console.warn('notificação falhou', e));
    return;
  }
  try{
    new Notification(title, opts);
  }catch(e){ console.warn('notificação falhou', e); }
}

// dispara no máximo 2 alertas novos por dia, sem repetir o mesmo aviso
function maybePushNotifications(notifs){
  if(!pushEnabled()) return;
  const hoje = new Date().toISOString().slice(0,10);
  let seen = {};
  try{ seen = JSON.parse(localStorage.getItem(PUSH_SEEN_KEY) || '{}'); }catch(e){ seen = {}; }
  if(seen.__day !== hoje) seen = { __day: hoje };
  let enviados = 0;
  notifs.filter(n=>n.type==='warn').concat(notifs.filter(n=>n.type!=='warn')).forEach(n=>{
    if(enviados >= 2) return;
    if(seen[n.id]) return;
    seen[n.id] = true;
    enviados++;
    showNativeNotification(n.title || 'Balance', n.text);
  });
  localStorage.setItem(PUSH_SEEN_KEY, JSON.stringify(seen));
}

function toggleNotifPanel(){
  const panel = document.getElementById('notifPanel');
  const opening = !panel.classList.contains('open');
  if(opening) renderNotifications();
  panel.classList.toggle('open', opening);
}
function closeNotifPanel(){ document.getElementById('notifPanel').classList.remove('open'); }

