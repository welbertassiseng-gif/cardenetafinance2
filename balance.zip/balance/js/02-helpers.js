/* =========================================================
   HELPERS GERAIS
========================================================= */
const fmt = (n) => (Number(n)||0).toLocaleString('pt-BR', {style:'currency', currency:'BRL'});
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2,9));

/* ---- Modo privado (olhinho de banco): oculta valores de Receita e Investimentos ---- */
const PRIV_MASK = '••••••';
let privacyMode = false;
try{ privacyMode = localStorage.getItem('privacy_mode') === '1'; }catch(e){}
function fmtPriv(n){ return privacyMode ? ('R$ '+PRIV_MASK) : fmt(n); }
function setPrivacyMode(v){
  privacyMode = v;
  try{ localStorage.setItem('privacy_mode', v ? '1' : '0'); }catch(e){}
  renderSection();
}
function togglePrivacyMode(){ setPrivacyMode(!privacyMode); }
function eyeIconSVG(open){
  return open
    ? `<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`
    : `<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a21.6 21.6 0 0 1 5.06-6.06M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a21.6 21.6 0 0 1-3.22 4.44M14.12 14.12a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`;
}
// Retorna o HTML de um botão de olhinho; liga-se sozinho via bindEyeToggles(container) após inserir no DOM.
function eyeToggleBtn(extraStyle){
  return `<button type="button" class="eye-toggle-btn" data-eye-toggle style="${extraStyle||''}" title="${privacyMode?'mostrar valores':'ocultar valores'}">${eyeIconSVG(!privacyMode)}</button>`;
}
function bindEyeToggles(container){
  (container||document).querySelectorAll('[data-eye-toggle]').forEach(btn=>{
    btn.addEventListener('click', togglePrivacyMode);
  });
}
// Envolve bindMoneyInput normal adicionando mascaramento: enquanto o campo não está em foco e o
// modo privado está ligado, mostra pontinhos; ao focar, revela o valor real para edição.
function bindMoneyInputPriv(inputEl, getVal, setVal, onChange){
  bindMoneyInput(inputEl, getVal, setVal, onChange);
  if(privacyMode) inputEl.value = PRIV_MASK;
  inputEl.addEventListener('focus', ()=>{ if(privacyMode) inputEl.value = moneyDisplay(getVal()); });
  inputEl.addEventListener('blur', ()=>{ if(privacyMode) inputEl.value = PRIV_MASK; });
}

function parseMoney(v){
  if(v===null||v===undefined) return 0;
  let s = String(v).trim();
  if(s==='') return 0;
  s = s.replace(/[^\d,.\-]/g,'');
  if(s.includes(',') && s.includes('.')){ s = s.replace(/\./g,'').replace(',', '.'); }
  else if(s.includes(',')){ s = s.replace(',', '.'); }
  const n = parseFloat(s);
  return isNaN(n) ? 0 : n;
}
function moneyDisplay(v){
  if(v===null||v===undefined||v==='') return '';
  const n = Number(v);
  if(isNaN(n)) return String(v).replace('.', ',');
  // formata com separador de milhar "." e 2 casas decimais, ex: 20000 -> 20.000,00
  return n.toLocaleString('pt-BR', {minimumFractionDigits:2, maximumFractionDigits:2});
}
function bindMoneyInput(inputEl, getVal, setVal, onChange){
  inputEl.value = moneyDisplay(getVal());
  inputEl.addEventListener('input', e=>{
    setVal(parseMoney(e.target.value));
    scheduleSave();
    if(onChange) onChange();
  });
  inputEl.addEventListener('blur', e=>{ e.target.value = moneyDisplay(getVal()); });
}
function escapeHtml(str){
  return String(str??'').replace(/[&<>"']/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}
function escAttr(str){ return escapeHtml(str); }

