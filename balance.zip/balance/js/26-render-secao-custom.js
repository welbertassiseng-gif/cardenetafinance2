/* =========================================================
   RENDER: SEÇÃO PERSONALIZADA (criada pelo usuário no menu)
========================================================= */
function renderCustomSection(sectionId){
  const cs = state.customSections.find(c=>c.id===sectionId);
  const el = document.createElement('div');
  if(!cs){
    el.innerHTML = `<div class="card"><div class="empty-state">Seção não encontrada.</div></div>`;
    return el;
  }
  const total = cs.items.reduce((s,i)=>s+(Number(i.value)||0),0);
  el.innerHTML = `
    <div class="page-header"><div><h2>${escapeHtml(cs.label)}</h2><div class="desc">Seção personalizada — adicione o que quiser controlar aqui.</div></div></div>
    <div class="card">
      <h3>Itens</h3>
      <div class="table-wrap"><table class="responsive-table">
        <thead><tr><th>Descrição</th><th class="num" style="width:130px">Valor</th><th style="width:60px"></th></tr></thead>
        <tbody id="csBody"></tbody>
        <tfoot><tr class="total-row"><td>TOTAL</td><td class="num" data-label="Total" id="cs-total-cell">${fmt(total)}</td><td></td></tr></tfoot>
      </table></div>
      <button class="btn secondary small" id="btnAddCs" style="margin-top:14px;">+ novo item</button>
    </div>
  `;
  const body = el.querySelector('#csBody');
  if(cs.items.length===0){
    body.innerHTML = `<tr><td colspan="3"><div class="empty-state">Nenhum item ainda.</div></td></tr>`;
  }
  cs.items.forEach((it,i)=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td data-label="Descrição"><input type="text" value="${escAttr(it.desc)}" data-role="desc"></td>
      <td class="num" data-label="Valor"><input type="text" inputmode="decimal" class="money" data-role="value"></td>
      <td><button class="icon-btn" data-role="del">✕</button></td>
    `;
    tr.querySelector('[data-role=desc]').addEventListener('input', e=>{ it.desc=e.target.value; scheduleSave(); });
    bindMoneyInput(tr.querySelector('[data-role=value]'), ()=>it.value, v=>it.value=v, ()=>{
      const cell = document.getElementById('cs-total-cell');
      if(cell) cell.textContent = fmt(cs.items.reduce((s,x)=>s+(Number(x.value)||0),0));
    });
    tr.querySelector('[data-role=del]').addEventListener('click', ()=>{ cs.items.splice(i,1); scheduleSave(); renderSection(); });
    body.appendChild(tr);
  });
  el.querySelector('#btnAddCs').addEventListener('click', ()=>{
    cs.items.push({desc:'', value:0}); scheduleSave(); renderSection();
  });
  return el;
}

