async function boot(){
  applySavedTheme();
  wirePasswordToggles();
  wireSettingsModal();
  document.getElementById('loadingScreen').style.display = 'none';

  if(!supabaseReady){
    const warnEl = document.getElementById('configWarning');
    if(supabaseLoadError){
      warnEl.innerHTML = 'Não foi possível conectar ao servidor agora. Verifique sua internet e tente novamente.<br><button type="button" class="btn secondary small" id="btnReloadPage" style="margin-top:10px;">Recarregar página</button>';
      const btnReload = document.getElementById('btnReloadPage');
      if(btnReload) btnReload.addEventListener('click', ()=>location.reload());
    } else {
      warnEl.textContent = 'Este site ainda não foi conectado a um banco de dados. Configure SUPABASE_URL e SUPABASE_ANON_KEY no início do arquivo antes de publicar.';
    }
    warnEl.style.display = 'block';
    document.getElementById('authScreen').style.display = 'flex';
    wireAuthForm();
    return;
  }

  wireAuthForm();

  // link do e-mail: volta com #type=recovery (esqueci a senha), #type=invite (convite) ou #error=... (link expirado/já usado)
  const authUrl = readAuthUrl();

  if(authUrl.errCode){
    cleanAuthUrl();
    document.getElementById('authScreen').style.display = 'flex';
    setAuthForm('forgot');
    showAuthError(recoveryLinkErrorMsg(authUrl));
    return;
  }

  sb.auth.onAuthStateChange((event, session)=>{
    if(event === 'PASSWORD_RECOVERY'){
      document.getElementById('landingScreen').style.display = 'none';
      document.getElementById('authScreen').style.display = 'flex';
      openResetForm('recovery');
    }
  });

  const { data: { session } } = await sb.auth.getSession();

  // link de recuperação OU de convite: com sessão válida abre a tela de definir senha
  if(authUrl.isRecovery || authUrl.isInvite){
    cleanAuthUrl();
    document.getElementById('landingScreen').style.display = 'none';
    document.getElementById('authScreen').style.display = 'flex';
    if(session){ openResetForm(authUrl.isInvite ? 'invite' : 'recovery'); }
    else { setAuthForm('forgot'); showAuthError(recoveryLinkErrorMsg(authUrl)); }
    return;
  }

  if(session){
    await enterApp(session);
  } else {
    document.getElementById('landingScreen').style.display = 'flex';
  }
}

async function enterApp(session){
  currentSession = session;
  undoStack = []; redoStack = [];
  await loadStateFromServer();
  ensureNavConfig();
  selectCurrentMonthIfFound();
  renderNav();
  renderSection();
  renderStampAll();
  const name = (session.user.user_metadata && session.user.user_metadata.full_name) || session.user.email;
  document.getElementById('currentUserLabel').textContent = name;
  document.getElementById('currentUserLabelDrawer').textContent = name;
  document.getElementById('authScreen').style.display = 'none';
  document.getElementById('app').style.display = 'flex';
  wireAppButtons();
  startRealtimeSync();
}

