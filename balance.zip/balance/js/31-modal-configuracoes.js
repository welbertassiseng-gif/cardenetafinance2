/* =========================================================
   MODAL DE CONFIGURAÇÕES
========================================================= */
function openSettings(){
  if(currentSession){
    const u = currentSession.user;
    document.getElementById('settingsEmail').value = u.email || '';
    document.getElementById('settingsName').value = (u.user_metadata && u.user_metadata.full_name) || '';
  }
  document.getElementById('profileMsg').textContent = '';
  document.getElementById('passMsg').textContent = '';
  document.getElementById('settingsNewPass').value = '';
  document.getElementById('settingsNewPass2').value = '';
  document.getElementById('settingsOverlay').classList.add('open');
  document.getElementById('settingsModal').classList.add('open');
}
function closeSettings(){
  document.getElementById('settingsOverlay').classList.remove('open');
  document.getElementById('settingsModal').classList.remove('open');
}

function wireSettingsModal(){
  document.getElementById('btnCloseSettings').onclick = closeSettings;
  document.getElementById('settingsOverlay').onclick = closeSettings;
  document.getElementById('themeLightBtn').onclick = ()=> setTheme('light');
  document.getElementById('themeDarkBtn').onclick = ()=> setTheme('dark');

  document.getElementById('btnSaveProfile').onclick = async ()=>{
    const msg = document.getElementById('profileMsg');
    const name = document.getElementById('settingsName').value.trim();
    msg.textContent = 'salvando…'; msg.className = 'settings-msg';
    try{
      const { error } = await sb.auth.updateUser({ data:{ full_name: name } });
      if(error) throw error;
      const { data:{ session } } = await sb.auth.getSession();
      currentSession = session;
      const label = name || session.user.email;
      document.getElementById('currentUserLabel').textContent = label;
      document.getElementById('currentUserLabelDrawer').textContent = label;
      msg.textContent = 'Dados salvos.'; msg.className = 'settings-msg ok';
    }catch(e){
      msg.textContent = traduzErro(e); msg.className = 'settings-msg err';
    }
  };

  document.getElementById('btnChangePass').onclick = async ()=>{
    const msg = document.getElementById('passMsg');
    const p1 = document.getElementById('settingsNewPass').value;
    const p2 = document.getElementById('settingsNewPass2').value;
    if(p1.length < 6){ msg.textContent = 'A senha precisa ter pelo menos 6 caracteres.'; msg.className = 'settings-msg err'; return; }
    if(p1 !== p2){ msg.textContent = 'As senhas não conferem.'; msg.className = 'settings-msg err'; return; }
    msg.textContent = 'salvando…'; msg.className = 'settings-msg';
    try{
      const { error } = await sb.auth.updateUser({ password: p1 });
      if(error) throw error;
      document.getElementById('settingsNewPass').value = '';
      document.getElementById('settingsNewPass2').value = '';
      msg.textContent = 'Senha alterada com sucesso.'; msg.className = 'settings-msg ok';
    }catch(e){
      msg.textContent = traduzErro(e); msg.className = 'settings-msg err';
    }
  };
}

