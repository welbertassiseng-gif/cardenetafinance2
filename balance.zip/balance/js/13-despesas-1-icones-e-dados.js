/* =========================================================
   RENDER: GASTOS MENSAIS (Despesas) — Todas · Categorias · Detalhe da categoria
   Tudo é derivado de state.months (categorias e itens que já existem). A única coisa
   nova que se guarda é state.categoryMeta: orçamento, ícone e descrição por categoria.
========================================================= */
const GX_MONTH_SHORT = ['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez'];
const GX = {
  view:'all',            // 'all' | 'cats' | 'detail'
  catKey:null,
  filters:{ search:'', period:'month', cats:[], min:null, max:null },
  sort:'recent',
  addOpen:false, focusAdd:false, filtersOpen:false,
  limit:60, flash:null, lastAdd:{ date:'', cat:'' }, _rows:[]
};

/* ---------- ícones (linha, mesmo estilo do menu) ---------- */
const GX_ICON_PATHS = {
  food:'<path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2"/><path d="M7 2v20"/><path d="M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7"/>',
  cart:'<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/>',
  car:'<path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/>',
  home:'<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/>',
  ticket:'<path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"/><path d="M13 5v2M13 11v2M13 17v2"/>',
  health:'<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/><path d="M3.22 12H9.5l.5-1 2 4.5 2-7 1.5 3.5h5.27"/>',
  book:'<path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/>',
  plane:'<path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z"/>',
  repeat:'<path d="m17 2 4 4-4 4"/><path d="M3 11v-1a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/><path d="M21 13v1a4 4 0 0 1-4 4H3"/>',
  shirt:'<path d="M20.38 3.46 16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.47a2 2 0 0 0-1.34-2.23z"/>',
  barbell:'<path d="M6.5 6.5v11"/><path d="M17.5 6.5v11"/><path d="M3.5 9v6"/><path d="M20.5 9v6"/><path d="M6.5 12h11"/>',
  gift:'<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13"/><path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7"/><path d="M7.5 8a2.5 2.5 0 0 1 0-5C11 3 12 8 12 8s1-5 4.5-5a2.5 2.5 0 0 1 0 5"/>',
  paw:'<circle cx="11" cy="4" r="2"/><circle cx="18" cy="8" r="2"/><circle cx="4" cy="8" r="2"/><path d="M9 10a5 5 0 0 1 5 5v3.5a3.5 3.5 0 0 1-6.84 1.045C6.52 17.48 4.46 16.84 4.46 16.84A3.5 3.5 0 0 1 5.5 10Z"/>',
  phone:'<rect x="5" y="2" width="14" height="20" rx="2"/><path d="M12 18h.01"/>',
  zap:'<path d="M13 2 3 14h9l-1 8 10-12h-9z"/>',
  briefcase:'<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>',
  landmark:'<path d="M3 21h18"/><path d="M5 21V10M9 21V10M15 21V10M19 21V10"/><path d="m3 10 9-6 9 6"/>',
  fixos:NAV_ICON_PATHS.fixos,
  tag:'<path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"/><circle cx="7.5" cy="7.5" r=".6" fill="currentColor"/>',
  wallet:'<rect x="2" y="6" width="20" height="14" rx="2"/><path d="M2 10h20"/><circle cx="17" cy="15" r="1.2" fill="currentColor"/>',
  coffee:'<path d="M3 8h14v6a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4Z"/><path d="M17 9h1a2 2 0 1 1 0 4h-1"/><path d="M7 2c-.5 1 .5 1.5 0 3M11 2c-.5 1 .5 1.5 0 3"/>',
  music:'<circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/><path d="M9 18V6l12-2v12"/>',
  umbrella:'<path d="M12 2a10 10 0 0 1 10 10H2A10 10 0 0 1 12 2Z"/><path d="M12 12v8a2 2 0 0 1-4 0"/><path d="M12 2v2"/>',
  star:'<path d="m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1Z"/>',
  bike:'<circle cx="5.5" cy="17.5" r="3.5"/><circle cx="18.5" cy="17.5" r="3.5"/><circle cx="15" cy="5" r="1"/><path d="M12 17.5V14l-3-3 4-3 2 3h2"/>',
  wrench:'<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L2 19l3 3 7.3-7.3a4 4 0 0 0 5.4-5.4l-2.8 2.8-2-2Z"/>',
  baby:'<circle cx="12" cy="10" r="8"/><path d="M9 12h.01M15 12h.01"/><path d="M10 16c.5.3 1.2.5 2 .5s1.5-.2 2-.5"/>'
};
const GX_ICON_RULES = [
  ['fixos',['gasto fixo','gastos fixos']],
  ['repeat',['assinatura','netflix','spotify']],
  ['health',['saude','medic','farmac','dentist','hospital','terapia','exame']],
  ['food',['aliment','comida','mercado','supermerc','restaur','lanche','padaria','ifood','delivery','refeic','cafe']],
  ['car',['transport','carro','uber','combust','gasolina','onibus','veicul','moto','estacion']],
  ['home',['moradia','casa','aluguel','condomin','imovel','reforma']],
  ['ticket',['lazer','entreten','diversao','cinema','festa','balada','jogo']],
  ['book',['educa','escola','curso','faculdade','estudo','livro']],
  ['plane',['viag','ferias','hotel','passagem','turismo']],
  ['shirt',['roupa','vestuario','moda','calcado']],
  ['barbell',['academia','esporte','fitness','treino']],
  ['gift',['presente','doacao']],
  ['paw',['pet','animal','veterin','racao']],
  ['phone',['celular','telefone','internet','telecom']],
  ['zap',['conta','luz','energia','agua','utilidade']],
  ['briefcase',['trabalho','negocio','empresa','escritorio']],
  ['landmark',['imposto','taxa','tarifa','banco','juros','financ','emprestimo','cartao']],
  ['cart',['compra','shopping','loja','varejo','amazon']]
];
const GX_DEFAULT_DESC = {
  food:'Mercado, restaurantes, delivery, padaria etc.', cart:'Compras em lojas, online e itens pessoais.',
  car:'Combustível, transporte por app, manutenção etc.', home:'Aluguel, condomínio, contas da casa e reformas.',
  ticket:'Passeios, cinema, jogos e diversão.', health:'Consultas, farmácia, exames e plano de saúde.',
  book:'Cursos, mensalidades, livros e materiais.', plane:'Passagens, hospedagem e passeios de viagem.',
  repeat:'Serviços recorrentes e streamings.', shirt:'Roupas, calçados e acessórios.',
  barbell:'Academia, esportes e bem-estar.', gift:'Presentes e doações.', paw:'Ração, veterinário e cuidados com pets.',
  phone:'Celular, internet e telefonia.', zap:'Luz, água, gás e outras contas.',
  briefcase:'Gastos ligados ao trabalho e a negócios.', landmark:'Impostos, taxas e tarifas.',
  fixos:'Gastos que se repetem todo mês.'
};
const GX_ICON_UI = {
  search:'<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  filter:'<path d="M3 5h18M6 12h12M10 19h4"/>',
  dots:'<circle cx="5" cy="12" r="1.6" fill="currentColor"/><circle cx="12" cy="12" r="1.6" fill="currentColor"/><circle cx="19" cy="12" r="1.6" fill="currentColor"/>',
  pencil:'<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
  trash:'<path d="M3 6h18"/><path d="M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>',
  eye:'<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  palette:'<circle cx="13.5" cy="6.5" r="1" fill="currentColor"/><circle cx="17.5" cy="10.5" r="1" fill="currentColor"/><circle cx="8.5" cy="7.5" r="1" fill="currentColor"/><circle cx="6.5" cy="12.5" r="1" fill="currentColor"/><path d="M12 2a10 10 0 0 0 0 20c1.1 0 2-.9 2-2 0-.5-.2-1-.5-1.3-.3-.3-.5-.8-.5-1.3 0-1.1.9-2 2-2H17a5 5 0 0 0 5-5c0-4.4-4.5-8.4-10-8.4Z"/>',
  text:'<path d="M4 7V4h16v3M9 20h6M12 4v16"/>',
  shapes:'<rect x="3" y="3" width="8" height="8" rx="1.5"/><circle cx="17.5" cy="6.5" r="3.5"/><path d="m3 21 4-7 4 7Z"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  receipt:'<path d="M4 2v20l3-2 2 2 3-2 3 2 2-2 3 2V2l-3 2-2-2-3 2-3-2-2 2Z"/><path d="M8 9h8M8 13h6"/>'
};
function gxSvg(path, size){
  const s = size ? ` width="${size}" height="${size}"` : '';
  return `<svg viewBox="0 0 24 24"${s} fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${path}</svg>`;
}
const gxUi = (name, size)=>gxSvg(GX_ICON_UI[name], size);

/* ---------- helpers de dados ---------- */
function gxKey(name){ return String(name||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim(); }
function gxSelMonth(){ return (state.months||[]).find(m=>m.id===state.selectedMonth) || null; }
function gxMeta(key, create){
  if(!state.categoryMeta || typeof state.categoryMeta!=='object'){ if(!create) return {}; state.categoryMeta = {}; }
  let m = state.categoryMeta[key];
  if(!m){ if(!create) return {}; m = state.categoryMeta[key] = {}; }
  return m;
}
function gxIconKey(key, name){
  const meta = gxMeta(key);
  if(meta.icon && GX_ICON_PATHS[meta.icon]) return meta.icon;
  const n = gxKey(name);
  for(const [ik, words] of GX_ICON_RULES){ if(words.some(w=>n.includes(w))) return ik; }
  return 'tag';
}
/* ---------- identidade visual da categoria: emoji (se definido) ou ícone SVG ---------- */
function gxIconMarkup(key, name, size){
  const meta = gxMeta(key);
  if(meta.emoji){
    const fs = size ? size + 3 : 19;
    return `<span class="gx-emoji-ico" style="font-size:${fs}px;">${escapeHtml(meta.emoji)}</span>`;
  }
  return gxSvg(GX_ICON_PATHS[gxIconKey(key, name)], size);
}
/* ---------- emojis categorizados para a identidade visual das categorias de gasto ---------- */
const GX_EMOJI_CATEGORIES = [
  ['Alimentação', ['🍔','🍕','🍟','🌮','🍣','🍜','🍩','🍰','☕','🍺','🍷','🥗','🍎','🧀','🥐','🍦']],
  ['Transporte', ['🚗','🚕','🚌','🚆','🚲','🛵','⛽','🅿️','✈️','🚢','🚦','🛴']],
  ['Casa', ['🏠','🛋️','🛏️','🧹','🧺','🔧','💡','🚿','🪴','🔑']],
  ['Compras', ['🛒','🛍️','👗','👟','💄','📦','🎁','💍']],
  ['Lazer', ['🎬','🎮','🎉','🎵','⚽','🎨','📚','🎲','🏖️','🎤']],
  ['Saúde', ['💊','🏥','🩺','🦷','🧠','💉','🧘','🏋️']],
  ['Trabalho', ['💼','💻','🖨️','📈','🏢','📅']],
  ['Viagem', ['🧳','🗺️','🏨','🛂','🌍']],
  ['Pets', ['🐶','🐱','🐦','🐠','🦴']],
  ['Finanças', ['💰','💳','🏦','📉','📊','💸','🪙']],
  ['Outros', ['⭐','❤️','🔥','✨','📌','🏷️','❓']]
];
function gxTint(color, alpha){ return /^#[0-9a-f]{6}$/i.test(color||'') ? color + alpha : 'var(--forest-pale)'; }
function gxMoneySigned(v){ if(!v) return fmt(0); return v>0 ? '- '+fmt(v) : '+ '+fmt(-v); }
function gxShortNum(v){
  const a = Math.abs(v);
  if(a>=1e6) return (v/1e6).toLocaleString('pt-BR',{maximumFractionDigits:1})+' mi';
  return Math.round(v).toLocaleString('pt-BR');
}
function gxPlural(n, one, many){ return n+' '+(n===1?one:many); }
function gxFmtDate(t){
  if(t.date && /^\d{4}-\d{2}-\d{2}$/.test(t.date)){ const [y,m,d]=t.date.split('-'); return `${d}/${m}/${y}`; }
  return t.month ? String(t.month.label||'') : '';
}

// Todas as categorias existentes (união dos meses), agrupadas pelo nome normalizado
function gxUniverse(){
  const map = new Map();
  (state.months||[]).forEach(month=>{
    (month.categories||[]).forEach(cat=>{
      const k = gxKey(cat.name);
      let e = map.get(k);
      if(!e){ e = {key:k, name:cat.name||'Sem nome', entries:[]}; map.set(k,e); }
      if(cat.name) e.name = cat.name; // fica o nome do mês mais recente
      e.entries.push({cat, month});
    });
  });
  return map;
}
function gxMonthsOf(period, back){
  const months = state.months||[];
  if(period==='all') return back ? [] : months.slice();
  const sel = gxSelMonth();
  if(!sel) return [];
  const r = monthLabelRank(sel.label);
  if(r===null) return back ? [] : [sel];
  if(period==='month' && !back) return [sel];
  let lo, hi;
  if(period==='month'){ lo = hi = r; }
  else if(period==='3m'){ lo = r-2; hi = r; }
  else if(period==='6m'){ lo = r-5; hi = r; }
  else { const y = Math.floor(r/12); lo = y*12; hi = y*12+11; }
  if(back){ const len = hi-lo+1; lo -= len; hi -= len; }
  return months.filter(m=>{ const mr = monthLabelRank(m.label); return mr!==null && mr>=lo && mr<=hi; });
}
function gxPeriodLabel(period){
  const sel = gxSelMonth();
  if(period==='month') return sel ? sel.label : 'Mês';
  if(period==='3m') return 'Últimos 3 meses';
  if(period==='6m') return 'Últimos 6 meses';
  if(period==='all') return 'Todo o histórico';
  const r = sel ? monthLabelRank(sel.label) : null;
  return r===null ? 'Ano' : 'Ano '+Math.floor(r/12);
}
function gxPeriodOptions(){
  return ['month','3m','6m','year','all'].map(p=>`<option value="${p}" ${GX.filters.period===p?'selected':''}>${escapeHtml(gxPeriodLabel(p))}</option>`).join('');
}
// Transações = itens com valor ou descrição (linhas em branco do editor antigo não contam)
function gxTx(months){
  const out = []; let order = 0;
  months.forEach(month=>{
    const mr = monthLabelRank(month.label);
    (month.categories||[]).forEach(cat=>{
      const key = gxKey(cat.name);
      (cat.items||[]).forEach(item=>{
        const v = Number(item.value)||0;
        const d = String(item.desc||'').trim();
        if(v===0 && !d) return;
        out.push({month, cat, item, key, catName:cat.name||'Sem nome', desc:d||'(sem descrição)', value:v, date:item.date||'', rank:mr, order:order++});
      });
    });
  });
  return out;
}
function gxDateKey(t){
  if(t.date) return t.date;
  if(t.rank!==null){ return Math.floor(t.rank/12)+'-'+String(t.rank%12+1).padStart(2,'0')+'-00'; }
  return '0000-00-00';
}
function gxSortTx(arr, mode){
  const a = arr.slice();
  if(mode==='oldest') a.sort((x,y)=> gxDateKey(x)<gxDateKey(y)?-1 : gxDateKey(x)>gxDateKey(y)?1 : x.order-y.order);
  else if(mode==='high') a.sort((x,y)=>y.value-x.value || x.order-y.order);
  else if(mode==='low') a.sort((x,y)=>x.value-y.value || x.order-y.order);
  else if(mode==='banco') a.sort((x,y)=>{
    const bx = String(x.item.banco||'').trim(), by = String(y.item.banco||'').trim();
    if(!bx && by) return 1; if(bx && !by) return -1;
    return bx.localeCompare(by,'pt-BR') || (gxDateKey(x)>gxDateKey(y)?-1 : gxDateKey(x)<gxDateKey(y)?1 : y.order-x.order);
  });
  else if(mode==='az') a.sort((x,y)=>x.desc.localeCompare(y.desc,'pt-BR') || x.order-y.order);
  else a.sort((x,y)=> gxDateKey(x)>gxDateKey(y)?-1 : gxDateKey(x)<gxDateKey(y)?1 : y.order-x.order);
  return a;
}
function gxApplyFilters(txs, f){
  const q = gxKey(f.search);
  return txs.filter(t=>{
    if(f.cats.length && !f.cats.includes(t.key)) return false;
    if(f.min!==null && t.value < f.min) return false;
    if(f.max!==null && t.value > f.max) return false;
    if(q){
      const hay = gxKey(t.desc+' '+t.catName+' '+(t.item.banco||'')+' '+gxFmtDate(t)+' '+t.month.label+' '+moneyDisplay(t.value));
      if(!hay.includes(q)) return false;
    }
    return true;
  });
}
function gxCurrentList(){
  const f = GX.view==='detail' ? Object.assign({}, GX.filters, {cats:[GX.catKey]}) : GX.filters;
  const months = gxMonthsOf(GX.filters.period);
  const all = gxTx(months);
  const rows = gxSortTx(gxApplyFilters(all, f), GX.sort);
  return {rows, total:rows.reduce((s,t)=>s+t.value,0), months, all};
}
function gxCategoryStats(period){
  const uni = gxUniverse();
  const cur = gxTx(gxMonthsOf(period));
  const prev = gxTx(gxMonthsOf(period, true));
  const every = gxTx(state.months||[]);
  const sum = arr=>arr.reduce((s,t)=>s+t.value,0);
  const list = [];
  uni.forEach((e,key)=>{
    const c = cur.filter(t=>t.key===key), p = prev.filter(t=>t.key===key);
    list.push({key, name:e.name, total:sum(c), count:c.length, prevTotal:sum(p), examples:every.filter(t=>t.key===key).map(t=>t.desc)});
  });
  return list;
}
function gxColorFor(key){
  const months = state.months||[];
  const pick = month=>{
    const list = month.categories||[];
    const i = list.findIndex(c=>gxKey(c.name)===key);
    return i>=0 ? catColor(list[i], i) : null;
  };
  const sel = gxSelMonth();
  if(sel){ const c = pick(sel); if(c) return c; }
  for(let i=months.length-1;i>=0;i--){ const c = pick(months[i]); if(c) return c; }
  return CAT_COLORS[0];
}
function gxDescFor(key, name, iconKey, examples){
  const meta = gxMeta(key);
  if(meta.desc) return meta.desc;
  if(GX_DEFAULT_DESC[iconKey]) return GX_DEFAULT_DESC[iconKey];
  const seen = [];
  (examples||[]).forEach(d=>{ if(d && d!=='(sem descrição)' && !seen.includes(d) && seen.length<3) seen.push(d); });
  return seen.length ? 'Ex.: '+seen.join(', ') : 'Gastos em '+name+'.';
}
function gxBudgetInfo(key, spent, nMonths){
  const b = Number(gxMeta(key).budget)||0;
  if(b<=0) return null;
  const n = Math.max(1, nMonths);
  const limit = b*n;
  const pct = spent/limit*100;
  return {monthly:b, limit, pct, left:limit-spent, cls: pct>100?'over': pct>=85?'warn':''};
}
function gxActiveFilterCount(){
  const f = GX.filters;
  return (f.period!=='month'?1:0) + (f.search.trim()?1:0) + f.cats.length + ((f.min!==null||f.max!==null)?1:0);
}

