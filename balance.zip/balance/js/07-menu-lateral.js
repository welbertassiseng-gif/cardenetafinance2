/* =========================================================
   MENU LATERAL — editável, com exclusão e restauração
========================================================= */
const DEFAULT_NAV = [
  {id:'dashboard', label:'Início'},
  {id:'gastos', label:'Despesas'},
  {id:'fixos', label:'Gastos Fixos'},
  {id:'salarios', label:'Salários'},
  {id:'receber', label:'Dinheiro a Receber'},
  {id:'investimentos', label:'Investimentos'},
  {id:'realInvest', label:'Investimento Real'},
  {id:'carteira', label:'Carteira de Investimentos'},
  {id:'notas', label:'Bloco de Notas'},
];
let activeSection = 'dashboard';

// Ícones de linha (estilo Lucide/Feather), um por tipo de seção — usam currentColor pra herdar a cor do menu.
const NAV_ICON_PATHS = {
  dashboard: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v9a1 1 0 0 0 1 1h4v-6h3v6h4a1 1 0 0 0 1-1v-9"/>',
  gastos: '<rect x="3" y="6" width="18" height="14" rx="2"/><path d="M3 10.5h18"/><path d="M7 15h4"/>',
  fixos: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/><path d="M8 15.5l2.2 2.2L16 12.2"/>',
  salarios: '<rect x="2" y="7" width="20" height="12" rx="2"/><circle cx="12" cy="13" r="2.6"/><path d="M6 7v.01M18 7v.01"/>',
  receber: '<path d="M12 3.5v13"/><path d="M6.5 11l5.5 5.5L17.5 11"/><path d="M4 20.5h16"/>',
  investimentos: '<path d="M18.5 6c-.9 0-1.6.5-2 1-3-1.2-8.5-1-10.2 2.3C5.3 11.3 5 13 6 14.5V18a1 1 0 0 0 1 1h1.6a1 1 0 0 0 1-1v-.7h3v.7a1 1 0 0 0 1 1H15a1 1 0 0 0 1-1v-2.3c.9-.8 1.5-1.7 1.7-2.7h.8a1 1 0 0 0 1-1V10a1 1 0 0 0-1-1h-.7c-.3-1-1-2-1.8-2.6Z"/><path d="M14.5 10.2h.01"/><path d="M3.5 9.2v1.2a1.8 1.8 0 0 0 1.8 1.8"/>',
  realInvest: '<path d="M3.5 16.5 9 11l4 4 7.5-7.5"/><path d="M15.5 7h5v5"/>',
  carteira: '<path d="M4 8a2 2 0 0 1 2-2h11a1 1 0 0 1 1 1v2"/><path d="M4 8v9a2 2 0 0 0 2 2h13a1 1 0 0 0 1-1v-7.5a1 1 0 0 0-1-1H9a2 2 0 0 1 0-4h9"/><circle cx="17" cy="14" r="1.3"/>',
  notas: '<path d="M6.5 3h8L19 7.5V20a1 1 0 0 1-1 1H6.5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M14.5 3v4.5H19"/><path d="M8.3 12.5h7.4M8.3 16h5"/>',
  custom: '<circle cx="12" cy="12" r="8.5"/><path d="M12 8v4.3l3 2"/>',
};
function navIcon(kind){
  const p = NAV_ICON_PATHS[kind] || NAV_ICON_PATHS.custom;
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
}

function ensureNavConfig(){
  if(!Array.isArray(state.navConfig)) state.navConfig = [];
  if(!Array.isArray(state.removedCore)) state.removedCore = [];
  DEFAULT_NAV.forEach(def=>{
    if(state.removedCore.includes(def.id)) return;
    if(!state.navConfig.find(n=>n.id===def.id)){
      state.navConfig.push({id:def.id, label:def.label, hidden:false, core:true, kind:def.id});
    }
  });
  // migração: quem já tinha o rótulo antigo "Visão Geral" (não customizado) passa a ver "Início"
  const dash = state.navConfig.find(n=>n.id==='dashboard');
  if(dash && dash.label === 'Visão Geral') dash.label = 'Início';
  if(!Array.isArray(state.customSections)) state.customSections = [];
  state.customSections.forEach(cs=>{
    if(!state.navConfig.find(n=>n.id===cs.id)){
      state.navConfig.push({id:cs.id, label:cs.label, hidden:false, core:false, kind:'custom'});
    }
  });
  // migração: garante o campo "kind" em entradas salvas antes dessa versão (duplicação/roteamento dependem dele)
  state.navConfig.forEach(n=>{
    if(!n.kind){
      const def = DEFAULT_NAV.find(d=>d.id===n.id);
      n.kind = def ? def.id : (n.core ? n.id : 'custom');
    }
  });
}

function renderNav(){
  ensureNavConfig();
  const all = state.navConfig;
  const visible = all.filter(n=>!n.hidden);
  const hidden = all.filter(n=>n.hidden);
  if(!visible.find(v=>v.id===activeSection)){
    activeSection = visible[0] ? visible[0].id : null;
  }

  buildNavInto('navList', visible, hidden, true);
  buildNavInto('navListDrawer', visible, hidden, true);
  renderBottomTabs(visible);
  updateMobileHeaderTitle(visible);
}

function buildNavInto(containerId, visible, hidden, withManage){
  const container = document.getElementById(containerId);
  if(!container) return;
  const itemHtml = (s,i)=>{
    const dupable = s.kind==='custom' || s.kind==='investimentos' || s.kind==='realInvest';
    return `
    <div class="nav-item ${s.id===activeSection?'active':''}" data-nav="${escAttr(s.id)}">
      <span class="nav-ico">${navIcon(s.kind)}</span>
      <span class="nav-label">${escapeHtml(s.label)}</span>
      <span class="nav-actions">
        ${dupable ? `<button class="nav-icon-btn" data-dup="${escAttr(s.id)}" title="duplicar">⧉</button>` : ''}
        <button class="nav-icon-btn" data-edit="${escAttr(s.id)}" title="renomear">✎</button>
        <button class="nav-icon-btn" data-delnav="${escAttr(s.id)}" title="excluir">✕</button>
      </span>
    </div>`;
  };
  const html = visible.map(itemHtml).join('');
  const addBtn = '';
  const hiddenBlock = (withManage && hidden.length) ? `
    <div class="nav-hidden-toggle" data-hiddentoggle="1">seções ocultas (${hidden.length}) ▾</div>
    <div class="nav-hidden-list" data-hiddenlist="1" style="display:none;">
      ${hidden.map(s=>`
        <div class="nav-hidden-item">
          <span class="nhi-label">${escapeHtml(s.label)}</span>
          <span class="nhi-actions">
            <span data-restore="${escAttr(s.id)}">restaurar</span>
            <button class="nhi-trash-btn" data-permadelete="${escAttr(s.id)}" title="excluir permanentemente">🗑</button>
          </span>
        </div>`).join('')}
    </div>` : '';

  container.innerHTML = html + addBtn + hiddenBlock;
  wireNav(container);

  const addBtnEl = container.querySelector('[data-addsection]');
  if(addBtnEl) addBtnEl.addEventListener('click', onAddCustomSection);

  const hiddenToggle = container.querySelector('[data-hiddentoggle]');
  if(hiddenToggle){
    hiddenToggle.addEventListener('click', ()=>{
      const list = container.querySelector('[data-hiddenlist]');
      list.style.display = list.style.display==='none' ? 'block' : 'none';
    });
  }
  container.querySelectorAll('[data-restore]').forEach(el=>{
    el.addEventListener('click', ()=>{
      const item = state.navConfig.find(n=>n.id===el.dataset.restore);
      if(item){ item.hidden = false; scheduleSave(); renderNav(); }
    });
  });
  container.querySelectorAll('[data-permadelete]').forEach(el=>{
    el.addEventListener('click', ()=>{
      onPermanentDeleteNavItem(el.dataset.permadelete);
    });
  });
}

const BOTTOM_TAB_LIMIT = 4;
function renderBottomTabs(visible){
  const bar = document.getElementById('bottomTabbar');
  if(!bar) return;
  // o botão "mais" foi removido: tocar no cabeçalho/☰ já abre o menu lateral com tudo.
  // então usamos essa vaga da barra inferior pra um atalho direto pra Carteira de Investimentos.
  const carteira = visible.find(v=>v.kind==='carteira');
  let primary = visible.slice(0, BOTTOM_TAB_LIMIT);
  if(carteira && !primary.find(p=>p.id===carteira.id)){
    primary = primary.slice(0, BOTTOM_TAB_LIMIT-1).concat([carteira]);
  }
  const tabHtml = (s)=>`
    <button class="bottom-tab ${s.id===activeSection?'active':''}" data-bnav="${escAttr(s.id)}">
      <span class="bt-icon">${navIcon(s.kind)}</span>
      <span class="bt-label">${escapeHtml(shortLabel(s.label))}</span>
    </button>`;
  bar.innerHTML = primary.map(tabHtml).join('');
  bar.querySelectorAll('[data-bnav]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      activeSection = btn.dataset.bnav;
      carteiraDetailId = null;
      renderNav(); renderSection();
    });
  });
}
function shortLabel(label){
  const l = String(label||'');
  return l.length > 9 ? l.slice(0,8)+'…' : l;
}
function updateMobileHeaderTitle(visible){
  const el = document.getElementById('mobileHeaderTitle');
  if(!el) return;
  const cur = visible.find(v=>v.id===activeSection);
  el.textContent = cur ? cur.label : 'Balance';
}

function openDrawer(){
  document.getElementById('drawer').classList.add('open');
  document.getElementById('drawerOverlay').classList.add('open');
}
function closeDrawer(){
  document.getElementById('drawer').classList.remove('open');
  document.getElementById('drawerOverlay').classList.remove('open');
}

function wireNav(container){
  if(!container) return;
  container.querySelectorAll('[data-nav]').forEach(el=>{
    el.addEventListener('click', (e)=>{
      if(e.target.closest('[data-edit]') || e.target.closest('[data-delnav]')) return;
      activeSection = el.dataset.nav;
      carteiraDetailId = null; // clicar na aba sempre volta pra visão geral da carteira
      renderNav();
      renderSection();
      closeDrawer();
    });
  });
  container.querySelectorAll('[data-edit]').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      e.stopPropagation();
      startInlineRename(btn.dataset.edit, btn.closest('.nav-item'));
    });
  });
  container.querySelectorAll('[data-dup]').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      e.stopPropagation();
      onDuplicateSection(btn.dataset.dup);
    });
  });
  container.querySelectorAll('[data-delnav]').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      e.stopPropagation();
      onDeleteNavItem(btn.dataset.delnav);
    });
  });
}

function startInlineRename(id, itemEl){
  const cfg = state.navConfig.find(n=>n.id===id);
  if(!cfg || !itemEl) return;
  const labelEl = itemEl.querySelector('.nav-label');
  const current = cfg.label;
  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'nav-edit-input';
  input.value = current;
  labelEl.replaceWith(input);
  input.focus();
  input.select();
  const commit = ()=>{
    const val = input.value.trim() || current;
    cfg.label = val;
    if(!cfg.core){
      const cs = state.customSections.find(c=>c.id===id);
      if(cs) cs.label = val;
    }
    scheduleSave();
    renderNav();
    renderSection(); // atualiza o título no topo imediatamente
  };
  input.addEventListener('blur', commit);
  input.addEventListener('keydown', e=>{
    if(e.key==='Enter'){ e.preventDefault(); input.blur(); }
    if(e.key==='Escape'){ e.preventDefault(); renderNav(); }
  });
}

function onDeleteNavItem(id){
  const cfg = state.navConfig.find(n=>n.id===id);
  if(!cfg) return;
  const visibleCount = state.navConfig.filter(n=>!n.hidden).length;
  if(visibleCount<=1){ alert('Deixe pelo menos um item no menu.'); return; }
  if(!confirm('Tem certeza que deseja excluir este item?')) return;

  if(cfg.core){
    cfg.hidden = true; // seções do sistema só somem do menu; dados continuam intactos (restaurável)
  } else {
    state.navConfig = state.navConfig.filter(n=>n.id!==id);
    purgeSectionData(cfg);
  }
  if(activeSection===id) activeSection = null;
  scheduleSave();
  renderNav();
  renderSection();
}

// Apaga os dados de uma seção não-core removida do menu (duplicatas e seções personalizadas).
function purgeSectionData(cfg){
  const kind = cfg.kind || cfg.id;
  if(kind==='custom'){
    state.customSections = state.customSections.filter(c=>c.id!==cfg.id);
  } else if(kind==='investimentos'){
    if(state.investmentSections) delete state.investmentSections[cfg.id];
  } else if(kind==='realInvest'){
    if(state.realInvestSections) delete state.realInvestSections[cfg.id];
  }
}

// Apaga os dados de uma seção CORE (permanece no menu, oculta, porém vazia — não é recriada com dados antigos).
function wipeSectionData(cfg){
  switch(cfg.kind){
    case 'gastos':
      state.months = [];
      if(state.dashboardMonth) state.dashboardMonth = null;
      if(state.selectedMonth) state.selectedMonth = null;
      break;
    case 'fixos': state.fixedExpenses = []; break;
    case 'salarios': state.salaries = []; break;
    case 'receber': state.receivables = []; break;
    case 'investimentos':
      if(cfg.id==='investimentos') state.investments = [];
      else if(state.investmentSections) delete state.investmentSections[cfg.id];
      break;
    case 'realInvest':
      if(cfg.id==='realInvest') state.realInvestments = { initialValue:0, months:[] };
      else if(state.realInvestSections) delete state.realInvestSections[cfg.id];
      break;
    case 'custom':
      state.customSections = state.customSections.filter(c=>c.id!==cfg.id);
      break;
    case 'carteira': state.wallet = { monthlyGoal:0, items:[] }; carteiraDetailId = null; break;
    case 'notas': state.notes = ''; state.notesList = []; notesOpenId = null; break;
    default: break; // dashboard: nada para apagar
  }
}

async function onPermanentDeleteNavItem(id){
  const cfg = state.navConfig.find(n=>n.id===id);
  if(!cfg) return;
  if(!confirm(`Excluir "${cfg.label}" PERMANENTEMENTE?\n\nTodos os dados dessa seção serão apagados e não será possível recuperar (diferente de "restaurar").`)) return;

  wipeSectionData(cfg);

  if(cfg.core){
    if(!Array.isArray(state.removedCore)) state.removedCore = [];
    if(!state.removedCore.includes(cfg.id)) state.removedCore.push(cfg.id);
  }
  state.navConfig = state.navConfig.filter(n=>n.id!==id);
  if(activeSection===id) activeSection = null;
  renderNav();
  renderSection();
  // exclusão permanente é destrutiva e irreversível: salva na hora, não espera o botão "Salvar"
  await persistState();
}

function onDuplicateSection(id){
  const cfg = state.navConfig.find(n=>n.id===id);
  if(!cfg) return;
  const kind = cfg.kind;
  if(kind!=='custom' && kind!=='investimentos' && kind!=='realInvest') return; // não duplicável

  const suggested = `Cópia de ${cfg.label}`;
  const name = prompt(`Duplicar "${cfg.label}" — nome da nova seção:`, suggested);
  if(!name) return;
  const newId = 'dup-' + uid();

  if(kind==='custom'){
    const original = state.customSections.find(c=>c.id===id);
    if(!original) return;
    const clonedItems = (original.items||[]).map(it => ({ desc: it.desc, value: it.value }));
    state.customSections.push({ id: newId, label: name.trim(), items: clonedItems });
  } else if(kind==='investimentos'){
    const source = getInvArray(id);
    const cloned = source.map(inv => ({ ...inv, id: uid() }));
    if(!state.investmentSections) state.investmentSections = {};
    state.investmentSections[newId] = cloned;
  } else if(kind==='realInvest'){
    const source = getRIData(id);
    const cloned = {
      initialValue: source.initialValue,
      months: (source.months||[]).map(m => ({ ...m, id: uid() }))
    };
    if(!state.realInvestSections) state.realInvestSections = {};
    state.realInvestSections[newId] = cloned;
  }

  state.navConfig.push({ id: newId, label: name.trim(), hidden:false, core:false, kind });
  activeSection = newId;
  scheduleSave();
  renderNav();
  renderSection();
}

function onAddCustomSection(){
  const customs = state.navConfig.filter(n=>!n.core);
  if(customs.length){
    const list = customs.map((c,i)=>`${i+1}. ${c.label}`).join('\n');
    const choice = prompt(
      `Criar nova seção em branco, ou duplicar uma já existente?\n\nPara duplicar, digite o número da seção abaixo:\n${list}\n\nOu deixe em branco e clique OK para criar uma nova seção do zero.`,
      ''
    );
    if(choice === null) return; // cancelou
    const idx = parseInt(choice, 10);
    if(!isNaN(idx) && idx>=1 && idx<=customs.length){
      onDuplicateSection(customs[idx-1].id);
      return;
    }
  }
  const label = prompt('Nome da nova seção (ex: Contas da Casa):');
  if(!label) return;
  const id = 'custom-' + uid();
  state.customSections.push({id, label: label.trim(), items:[]});
  state.navConfig.push({id, label: label.trim(), hidden:false, core:false});
  activeSection = id;
  scheduleSave();
  renderNav();
  renderSection();
}

