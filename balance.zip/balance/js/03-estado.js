/* =========================================================
   ESTADO
========================================================= */
function emptyState(){
  return {
    months: [], fixedExpenses: [], salaries: [], receivables: [], loans: [], investments: [],
    customSections: [],
    realInvestments: { initialValue: 0, months: [] },
    investmentSections: {}, // seções "Investimentos" duplicadas (id da seção -> lista de investimentos)
    realInvestSections: {}, // seções "Investimento Real" duplicadas (id da seção -> {initialValue, months})
    wallet: { monthlyGoal: 0, items: [] }, // "Carteira de Investimentos"
    notesList: [], // "Bloco de Notas" — lista de notas (estilo iPhone)
    navConfig: null, // preenchido por ensureNavConfig()
    categoryMeta: {}, // Despesas: orçamento, ícone e descrição por categoria (chave = nome normalizado)
    removedCore: [], // seções do sistema excluídas permanentemente (não voltam ao menu)
    chartColors: null, // Início: cores personalizadas do gráfico Receita × Gastos ({receita, gastos})
    lastUpdated: null, selectedMonth: null, dashboardMonth: null,
  };
}
function ensureChartColors(){
  if(!state.chartColors || typeof state.chartColors!=='object') state.chartColors = {};
  if(!state.chartColors.receita) state.chartColors.receita = '#3B82F6';
  if(!state.chartColors.gastos) state.chartColors.gastos = '#F87171';
  return state.chartColors;
}
function shadeHex(hex, amt){
  try{
    let c = String(hex||'').replace('#','');
    if(c.length===3) c = c.split('').map(x=>x+x).join('');
    const num = parseInt(c,16);
    let r = (num>>16)+amt, g = ((num>>8)&0xFF)+amt, b = (num&0xFF)+amt;
    r = Math.min(255,Math.max(0,r)); g = Math.min(255,Math.max(0,g)); b = Math.min(255,Math.max(0,b));
    return '#'+((1<<24)+(r<<16)+(g<<8)+b).toString(16).slice(1);
  }catch(e){ return hex; }
}

let state = null;
let currentSession = null; // sessão do Supabase (user + token)
let saveTimer = null;
let saving = false;
let dirty = false; // true quando há alterações ainda não salvas manualmente

