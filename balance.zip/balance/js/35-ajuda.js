/* =========================================================
   AJUDA — guia "Como usar" + dúvidas frequentes + busca
========================================================= */
(function(){
const TOPICS = [
{id:"roteiro",g:"Primeiros passos",t:"Comece por aqui",d:"Roteiro rápido para deixar o app funcionando em poucos minutos.",
 s:["Entre com o e-mail e a senha que você recebeu no convite.","Abra **Despesas**, toque em **+ novo mês** e digite o mês com ano, por exemplo **Novembro / 2026**.","Toque em **+ Adicionar**, preencha descrição, valor, data e categoria e toque em **Adicionar**. Repita para cada gasto.","Abra **Salários**, escolha o mês e toque em **criar salário deste mês**. Informe seu salário (e extras, se houver).","Se tem contas que se repetem todo mês, cadastre em **Gastos Fixos** e, dentro do mês, toque em **aplicar gastos fixos**.","Veja o resultado em **Início**: receita, gastos e quanto sobrou.","Toque em **salvar** (💾). O app não salva sozinho."],
 n:["O botão salvar pulsa em verde quando há algo por salvar."]},
{id:"conta",g:"Primeiros passos",t:"Conta, login e senha",d:"Entrar, recuperar a senha e sair.",
 s:["Na tela inicial, toque em **Entrar** ou **Acessar minha conta**.","O acesso ao Balance é feito por convite: use o e-mail e a senha que você recebeu de quem te convidou.","Se o app avisar que enviou um link, abra seu e-mail e confirme antes de entrar.","Esqueceu a senha? Toque em **Esqueci minha senha**, informe o e-mail, abra o link recebido e defina a nova senha."],
 n:["Seus dados ficam na sua conta e acompanham você em qualquer navegador ou aparelho.","Para sair, use **Sair** no menu. Se houver alterações sem salvar, o app avisa."]},
{id:"navegacao",g:"Primeiros passos",t:"Menu e navegação",d:"Onde fica cada coisa no computador e no celular.",
 n:["**Computador:** o menu fica à esquerda. A seta ‹ no topo recolhe o menu (o app lembra sua escolha).","**Celular:** a barra de baixo mostra as primeiras abas e um atalho para a Carteira. Toque em ☰ para abrir o menu completo.","No menu ficam também: 🔔 avisos, ↶ desfazer, ↷ refazer, 💾 salvar, ⚙️ ajustes, ❓ ajuda e sair."]},
{id:"inicio",g:"Controle do mês",t:"Início",d:"Painel que compara receita e gastos de um mês.",
 s:["Escolha o mês na lista no topo.","Leia os quadros: **Receita** (total de Salários do mês), **Gastos** (total de Despesas) e **Sobra do mês** (receita − gastos).","Veja o gráfico **Receita × Gastos por mês**. Toque em Receita ou Gastos para trocar a cor das barras.","Confira o **Resumo geral**: a receber pendente, Carteira, gastos fixos e empréstimos em aberto.","A tabela **Todos os meses** lista cada mês."],
 n:["Tudo vem das outras abas: para mudar um número, edite na aba de origem.","O gráfico só aparece quando há gastos ou salário lançados.","“Atualizado” mostra a data do último salvamento."]},
{id:"gastos",g:"Controle do mês",t:"Despesas: os meses",d:"Cada mês tem seu próprio conjunto de despesas.",
 s:["Toque em **+ novo mês** e digite **Mês / Ano** (ex.: Novembro / 2026).","Troque de mês pelas setas ‹ › ou pela lista.","**duplicar mês atual** copia categorias e despesas para um novo mês.","**aplicar gastos fixos** traz os itens da aba Gastos Fixos para a categoria Gastos Fixos do mês, sem repetir os que já estão lá.","**excluir mês** remove o mês, as despesas dele e o salário lançado para ele."],
 n:["Use sempre mês e ano no nome: é por ele que o app ordena, acha o mês atual e lança parcelas.","Crie os meses em ordem cronológica, pois um novo mês entra no fim da lista.","Ao abrir o app, aparece o mês atual do calendário, se estiver cadastrado.","O topo mostra o total gasto, o gráfico por categoria, o nº de transações, a maior categoria e a variação contra o mês anterior."]},
{id:"lancar",g:"Controle do mês",t:"Lançar, editar e excluir despesas",d:"Na aba Todas de Despesas.",
 s:["Toque em **+ Adicionar**.","Preencha **Descrição**, **Valor**, **Data**, **Categoria** e, se quiser, **Banco** (escolha uma sugestão ou digite).","Toque em **Adicionar** ou pressione Enter. O painel continua aberto para o próximo lançamento.","Para corrigir, toque na despesa: edite tudo (inclusive a categoria) e toque em **Salvar**, ou em **Excluir**.","A lixeira no fim da linha também exclui."],
 n:["A lista de categorias mostra só as já existentes. Crie novas em Categorias › + Nova categoria.","Decimais com vírgula (12,50). Um ponto sozinho conta como decimal: 1.500 vira R$ 1,50. Use 1500 ou 1.500,00.","Para registrar um estorno, lance a despesa com o valor em sinal de menos (ex.: -50,00).","Errou? Use ↶ desfazer (antes de salvar)."]},
{id:"parcelas",g:"Controle do mês",t:"Compras parceladas",d:"Lance uma vez e o app preenche os meses seguintes.",
 s:["Em **+ Adicionar**, mude **Tipo** para **Parcelas**.","Digite o valor **de cada parcela** e o **nº de parcelas** (2 a 48).","Confira o aviso, por exemplo “3x de R$ 100,00 = R$ 300,00”.","Toque em **Adicionar**: o app lança “descrição (1/3)”, “(2/3)”… nos meses seguintes, criando os que faltarem."],
 n:["O mês atual precisa ter mês e ano no nome (ex.: Novembro / 2026).","Cada parcela é um lançamento independente: edite ou exclua uma por vez (busque “(1/3)” no período Todo o histórico).","As parcelas seguintes usam o mesmo dia da data escolhida."]},
{id:"buscar",g:"Controle do mês",t:"Buscar, filtrar e ordenar",d:"Encontre qualquer despesa rapidamente.",
 s:["Na aba **Todas**, digite na caixa **Buscar transação**.","Escolha o **período**: mês, últimos 3 ou 6 meses, ano ou todo o histórico.","Toque em **Filtros** para marcar categorias e definir valor mínimo e máximo.","Remova um filtro pelo × do chip ou toque em **Limpar filtros**.","Ordene por data, valor, descrição ou banco em **Ordenado por**."],
 n:["Despesa sumiu? Quase sempre há um filtro ativo (veja os chips).","A lista mostra 60 itens por vez; use **Mostrar mais**."]},
{id:"categorias",g:"Controle do mês",t:"Categorias e orçamento",d:"Organize, personalize e controle o limite de cada categoria.",
 s:["Abra a aba **Categorias** e escolha o período.","Toque em **+ Nova categoria** para criar.","Toque no cartão para ver as despesas, o gráfico dos últimos 6 meses e a média mensal.","Nos três pontos (⋯) você pode definir **orçamento**, editar descrição, alterar ícone ou emoji, alterar cor, renomear ou remover.","Em **Definir orçamento**, informe o valor mensal. A barra mostra quanto foi usado (amarela a partir de 85%, vermelha acima de 100%)."],
 n:["Renomear vale para todos os meses.","Remover pergunta se vale só para o mês atual ou para todos; as despesas da categoria saem junto.","**Negativas** são categorias com gasto no período; **Zeradas** não tiveram gasto."]},
{id:"fixos",g:"Controle do mês",t:"Gastos Fixos",d:"Modelo das contas que se repetem todo mês.",
 s:["Toque em **+ novo gasto fixo**.","Digite a descrição e o valor mensal. O total soma sozinho.","Em **Despesas**, dentro do mês, toque em **aplicar gastos fixos**."],
 n:["Alterar o modelo não muda meses já aplicados.","Remova um item com ✕."]},
{id:"salarios",g:"Controle do mês",t:"Salários e horas extras",d:"A receita do mês vem daqui.",
 s:["Escolha o mês (ele precisa existir em Despesas).","Toque em **criar salário deste mês**.","Para valor normal, digite em **Valor**.","Para hora extra, preencha **Valor h.e.** (valor da hora) e **Horas**: o valor é calculado.","Use **+ novo item** para bônus, 13º, freelas etc."],
 n:["A soma dos itens do mês é a **Receita** do Início.","Excluir um mês em Despesas apaga o salário dele."]},
{id:"receber",g:"Controle do mês",t:"Dinheiro a Receber e empréstimos",d:"O que devem a você e empréstimos parcelados que você fez.",
 s:["Em **A receber de terceiros**, toque em **+ novo registro**: data, devedor, descrição e valor.","Quando receber, mude **Status** para **Recebido**.","Em **Empréstimos parcelados**, toque em **+ novo empréstimo**: nome, valor total, nº de parcelas e valor por parcela.","A cada parcela paga, aumente o campo **Pagas**."],
 n:["Restante = (parcelas − pagas) × valor por parcela. O **Valor total** é só informativo.","Valores recebidos não entram na Receita. Lance também em Salários se quiser contá-los."]},
{id:"investimentos",g:"Investimentos",t:"Investimentos (projeção)",d:"Quanto seu dinheiro pode render no futuro.",
 s:["Toque em **+ novo item**.","Escolha **Rende juros** ou **Valor fixo**.","Em Rende juros, informe valor inicial, aporte mensal, anos e duas taxas anuais (baixa e alta).","Leia o valor projetado nos dois cenários e os totais no topo."],
 n:["A taxa anual vira taxa mensal e o cálculo usa juros compostos.","Duplique a aba (⧉ no menu) para simular outro plano."]},
{id:"realinvest",g:"Investimentos",t:"Investimento Real",d:"Simulação mês a mês com aporte e taxa de cada mês.",
 s:["Informe o **Valor inicial**.","Toque em **+ Adicionar mês** e escolha o mês, o **aporte** e a **taxa** (a.a. ou a.m.).","Repita para cada mês: o saldo inicial vem do mês anterior.","Acompanhe Total aportado, Rendimento total, Montante atual e o gráfico."],
 n:["Editar qualquer mês recalcula os seguintes.","O rendimento do mês incide sobre o saldo inicial; o aporte passa a render no mês seguinte."]},
{id:"carteira",g:"Investimentos",t:"Carteira de Investimentos",d:"Seus saldos reais, aportes, retiradas e meta mensal.",
 s:["Toque em **+ novo item**, dê um nome e escolha investimento ou reserva.","Abra o item e informe a **Taxa mensal (%)** do mês.","Registre **Aporte** ou **Retirada** (valor, data e nota) e toque em **OK**.","Se preferir, use **Atualizar saldo** para informar o saldo atual.","Defina a **Meta de investimento** do mês no ✎ e acompanhe a barra.","Teste ideias em **Simular cenário hipotético** (não altera a carteira)."],
 n:["O saldo soma aportes e rendimento mês a mês; dinheiro novo rende a partir do mês seguinte.","Mês sem taxa usa a última taxa informada.","Apagar uma movimentação do histórico desfaz o efeito no saldo."]},
{id:"notas",g:"Ferramentas",t:"Bloco de Notas",d:"Anotações livres, no estilo do app Notas.",
 s:["Toque em **+ nova nota**.","Digite título (opcional) e texto. Sem título, a primeira linha vira o título.","Volte em **todas as notas** e toque numa nota para reabrir.","A lixeira exclui a nota (pede confirmação e salva na hora)."]},
{id:"menu",g:"Ferramentas",t:"Personalizar o menu",d:"Renomear, ocultar, criar e duplicar seções.",
 s:["Em cada item do menu aparecem ⧉ duplicar, ✎ renomear e ✕ excluir (no computador, ao passar o mouse).","✕ numa aba padrão apenas **oculta**: ela vai para **seções ocultas**, de onde dá para **restaurar**.","Para apagar de vez, use a lixeira 🗑 em seções ocultas (irreversível, salva na hora)."],
 n:["Só Investimentos, Investimento Real e seções suas podem ser duplicadas.","Seções criadas por você são apagadas, com os dados, ao excluir.","Sempre deve sobrar ao menos um item no menu."]},
{id:"salvar",g:"Ferramentas",t:"Salvar, desfazer e refazer",d:"O app só grava quando você manda.",
 s:["Faça suas alterações.","Toque em **salvar** (💾). Ele pulsa em verde quando há algo pendente e mostra **salvo** depois.","Errou? **↶ desfazer** volta até 50 passos e **↷ refazer** reaplica, mas só enquanto você não salvou."],
 n:["O app **não salva sozinho**. Fechar a aba com pendências gera um aviso.","Depois de desfazer, salve para gravar a versão corrigida.","**Depois de salvar, o desfazer zera:** o que já foi salvo não pode mais ser desfeito por ↶."
,"O histórico de desfazer também zera ao recarregar, sair ou quando chegam dados de outro aparelho.","Exclusão permanente, apagar nota e importar backup salvam na hora."]},
{id:"aparelhos",g:"Ferramentas",t:"Usar em mais de um aparelho",d:"Celular e computador com os mesmos dados.",
 n:["Entre com a mesma conta: os dados salvos aparecem em todos os aparelhos.","Quando você salva, os outros aparelhos abertos se atualizam sozinhos.","Se você tem alterações sem salvar, aparece “Há dados novos em outro aparelho”: salve ou recarregue.","Ao salvar tendo dados mais novos em outro lugar, o app pergunta se quer sobrescrever."]},
{id:"privado",g:"Ferramentas",t:"Modo privado (olhinho)",d:"Esconda valores sensíveis quando outras pessoas estiverem olhando.",
 s:["Toque no olho 👁 ao lado de Receita, Salários, Investimentos ou Carteira.","Os valores viram ••••••. Toque de novo para mostrar."],
 n:["Oculta receita e sobra, salários, Investimentos, Carteira e o gráfico do Início.","Gastos, A receber e Investimento Real continuam visíveis.","Vale só neste aparelho e fica lembrado.","Ao tocar num campo, o valor real aparece para você editar."]},
{id:"avisos",g:"Ferramentas",t:"Notificações (sino)",d:"Alertas calculados com os seus dados.",
 s:["Toque no sino 🔔. O ponto indica alertas.","Para receber no aparelho, toque em **ativar avisos** e permita no navegador."],
 n:["Alertas do mês atual: gastos 15% acima ou abaixo da média, 80% ou mais da renda gasta, saldo negativo, categoria com 40%+ dos gastos, fixos acima de 50% da renda, salário ou gastos sem lançar, valores a receber, empréstimos, meta de aporte e dados parados há 10+ dias.","O app precisa estar aberto (pode ficar em segundo plano). São no máximo 2 avisos novos por dia.","Se estiver bloqueado, libere nas configurações do site. Abra o app em aba própria ou pelo ícone na tela de início."]},
{id:"ajustes",g:"Ferramentas",t:"Ajustes e backup",d:"Tema, nome, senha e cópia de segurança.",
 s:["Toque em ⚙️ **ajustes**.","**Aparência:** claro ou escuro.","**Dados pessoais:** altere o nome (o e-mail não muda).","**Segurança:** defina uma nova senha (mínimo 6 caracteres).","**Dados do app:** é aqui que ficam **Exportar backup** (arquivo .json) e **Importar backup**."],
 n:["Nome e senha são salvos na hora.","**Importar substitui todos os seus dados atuais** e salva imediatamente. Exporte um backup antes."]}
];
const FAQ = [
["Salvar e dados","Perdi o que digitei","O app só grava quando você toca em salvar (💾). O que ficou pendente ao fechar sem salvar se perde. O navegador avisa antes de fechar."],
["Salvar e dados","Apaguei algo sem querer","Se ainda não salvou, toque em ↶ desfazer (até 50 passos) e depois salve. Depois de salvar, o desfazer não volta mais. Abas ocultas voltam em seções ocultas › restaurar. Exclusão permanente e backup importado não têm volta."],
["Salvar e dados","O que significa “Os dados foram alterados em outro aparelho”?","Outro aparelho salvou depois da última vez que este sincronizou. OK sobrescreve tudo com o que está nesta tela; Cancelar mantém suas alterações sem salvar, e você recarrega para ver as novas."],
["Salvar e dados","Deu erro ao salvar","Em geral é falta de conexão. Suas alterações continuam na tela: confira a internet e toque em salvar de novo."],
["Salvar e dados","Como faço backup e restauro?","Abra ⚙️ ajustes e, em Dados do app, toque em Exportar backup. Para restaurar, toque em Importar: isso substitui todos os dados atuais e salva na hora, sem pedir confirmação."],
["Gastos e valores","Digitei 1.500 e virou R$ 1,50","Ponto sozinho é decimal. Digite 1500, 1.500,00 ou 1500,00."],
["Gastos e valores","Que nome dar ao mês?","Mês e ano, como Novembro / 2026 (nov/26 também funciona). Sem um mês reconhecível, parcelas, comparações e alertas não funcionam direito."],
["Gastos e valores","A Receita aparece zerada","Falta lançar o salário do mês em Salários (criar salário deste mês) ou o valor está em branco."],
["Gastos e valores","Minha despesa não aparece na lista","Veja os chips de filtro e o período (por padrão só o mês selecionado). Toque em Limpar filtros."],
["Gastos e valores","Excluir um mês apaga o salário?","Sim. Apaga o mês, as despesas dele e o salário daquele mês."],
["Gastos e valores","Como cancelo uma compra parcelada?","Cada parcela é um lançamento. Busque “(1/3)” com o período Todo o histórico e exclua uma a uma."],
["Gastos e valores","O que o duplicar mês copia?","Categorias, despesas e valores, com as datas originais. Ajuste o que precisar."],
["Gastos e valores","Como funciona o orçamento?","É um valor mensal por categoria, comparado ao gasto do período escolhido (em 3 meses, o limite é 3 vezes o orçamento)."],
["Investimentos","Qual a diferença entre Investimentos, Investimento Real e Carteira?","**Investimentos** projeta o futuro (anos e duas taxas). **Investimento Real** simula mês a mês com aporte e taxa de cada mês. **Carteira** guarda seus saldos reais, aportes, retiradas e meta; é ela que aparece no Início."],
["Investimentos","Atualizar saldo ou registrar aporte?","Aporte e retirada somam ou subtraem e ficam no histórico. Atualizar saldo define o novo valor e registra um ajuste."],
["Investimentos","Taxa anual ou mensal?","Investimentos usa taxa anual. Carteira e o simulador usam taxa mensal. No Investimento Real você escolhe a.a. ou a.m. em cada mês."],
["Privacidade e avisos","O olhinho esconde tudo?","Esconde receita, sobra, salários, Investimentos e Carteira. Não esconde gastos, A receber nem Investimento Real."],
["Privacidade e avisos","Não aparece nenhum alerta","Os alertas olham o mês atual do calendário, que precisa estar cadastrado. Comparações pedem 2 ou mais meses anteriores com gastos."],
["Privacidade e avisos","Os avisos no celular não chegam","Toque no sino › ativar avisos e permita. Se bloqueou, libere nas configurações do site. O app precisa estar aberto, ainda que em segundo plano."],
["Conta e acesso","Esqueci minha senha","Na tela de login, toque em Esqueci minha senha, informe o e-mail, abra o link recebido e crie a nova. Se der erro, aguarde cerca de 1 minuto antes de pedir outro link."],
["Conta e acesso","O e-mail de confirmação não chegou","Aguarde alguns minutos e olhe o spam e as promoções. Confira se o e-mail foi digitado certo."],
["Conta e acesso","Posso trocar o e-mail?","Não. O e-mail aparece em ajustes, mas não é editável. Nome e senha podem ser trocados."],
["Conta e acesso","O gráfico não aparece","É preciso ter gastos ou salário lançados, internet para carregar o gráfico e o modo privado desligado."],
["Conta e acesso","No celular não acho ✎ e ✕ do menu","Eles ficam sempre visíveis dentro do menu ☰."]
];
const KIND = {dashboard:"inicio",gastos:"gastos",fixos:"fixos",salarios:"salarios",receber:"receber",investimentos:"investimentos",realInvest:"realinvest",carteira:"carteira",notas:"notas",custom:"menu"};
const ov = document.getElementById("hlpOverlay"), body = document.getElementById("hlpBody"), inp = document.getElementById("hlpSearch");
let tab = "guide", cur = "roteiro";
const nz = s => String(s).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"");
const fx = s => escapeHtml(s).replace(/\*\*(.+?)\*\*/g,"<b>$1</b>");
const plain = s => String(s).replace(/\*\*/g,"");

function guideHTML(){
  const gs = [...new Set(TOPICS.map(x=>x.g))];
  const rail = gs.map(g=>"<b>"+escapeHtml(g)+"</b>"+TOPICS.filter(x=>x.g===g).map(x=>'<button type="button" data-t="'+x.id+'" class="'+(x.id===cur?"on":"")+'">'+escapeHtml(x.t)+"</button>").join("")).join("");
  const sel = '<select class="hlp-sel" id="hlpSel" aria-label="Tópico">'+TOPICS.map(x=>'<option value="'+x.id+'"'+(x.id===cur?" selected":"")+">"+escapeHtml(x.t)+"</option>").join("")+"</select>";
  const t = TOPICS.find(x=>x.id===cur)||TOPICS[0];
  const art = '<div class="hlp-art"><h4>'+escapeHtml(t.t)+'</h4><p class="sum">'+escapeHtml(t.d||"")+"</p>"
    +(t.s?"<ol>"+t.s.map(x=>"<li>"+fx(x)+"</li>").join("")+"</ol>":"")
    +(t.n?'<div class="hlp-note"><b>Bom saber</b><ul>'+t.n.map(x=>"<li>"+fx(x)+"</li>").join("")+"</ul></div>":"")+"</div>";
  return '<div class="hlp-guide"><nav class="hlp-rail">'+rail+"</nav><div>"+sel+art+"</div></div>";
}
function faqHTML(){
  let last = "", h = '<div class="hlp-faq">';
  FAQ.forEach((f,i)=>{
    if(f[0]!==last){ last = f[0]; h += '<div class="hlp-gh">'+escapeHtml(f[0])+"</div>"; }
    h += '<details id="hf-'+i+'"><summary>'+escapeHtml(f[1])+"</summary><div>"+fx(f[2])+"</div></details>";
  });
  return h+"</div>";
}
function searchHTML(q){
  const words = q.split(/\s+/).filter(Boolean);
  const items = TOPICS.map(t=>({k:"t",id:t.id,title:t.t,text:plain([t.d].concat(t.s||[],t.n||[]).join(" "))}))
    .concat(FAQ.map((f,i)=>({k:"f",id:i,title:f[1],text:plain(f[2])})));
  const hits = items.filter(it=>{ const hay = nz(it.title+" "+it.text); return words.every(w=>hay.includes(w)); }).slice(0,15);
  if(!hits.length) return '<div class="hlp-empty">Nada encontrado para essa busca. Tente outra palavra, como “salvar”, “parcela” ou “senha”.</div>';
  return '<div class="hlp-res">'+hits.map(it=>'<button type="button" data-go="'+it.k+":"+it.id+'"><b>'+escapeHtml(it.title)+"</b><small>"+(it.k==="t"?"Como usar":"Dúvida")+" · "+escapeHtml(it.text.slice(0,110))+"…</small></button>").join("")+"</div>";
}
function render(){
  ov.querySelectorAll(".hlp-tabs button").forEach(b=>b.classList.toggle("on", b.dataset.tab===tab));
  const q = nz(inp.value.trim());
  body.innerHTML = q ? searchHTML(q) : (tab==="guide" ? guideHTML() : faqHTML());
  if(!q) body.scrollTop = 0;
}
function curTopic(){
  try{
    if(!state) return "roteiro";
    const c = state.navConfig.find(n=>n.id===activeSection);
    return KIND[(c&&c.kind)||activeSection]||"roteiro";
  }catch(e){ return "roteiro"; }
}
function openHelp(){ cur = curTopic(); tab = "guide"; inp.value = ""; render(); ov.classList.add("open"); }
function closeHelp(){ ov.classList.remove("open"); }

ov.addEventListener("click", e=>{
  if(e.target===ov || e.target.closest("#hlpClose")) return closeHelp();
  const tb = e.target.closest(".hlp-tabs button");
  if(tb){ tab = tb.dataset.tab; inp.value = ""; return render(); }
  const tt = e.target.closest("[data-t]");
  if(tt){ cur = tt.dataset.t; return render(); }
  const go = e.target.closest("[data-go]");
  if(go){
    const p = go.dataset.go.split(":"); inp.value = "";
    if(p[0]==="t"){ tab = "guide"; cur = p[1]; render(); }
    else { tab = "faq"; render(); const d = document.getElementById("hf-"+p[1]); if(d){ d.open = true; d.scrollIntoView({block:"center"}); } }
  }
});
ov.addEventListener("change", e=>{ if(e.target.id==="hlpSel"){ cur = e.target.value; render(); } });
inp.addEventListener("input", render);
document.addEventListener("keydown", e=>{ if(e.key==="Escape" && ov.classList.contains("open")) closeHelp(); });
document.querySelectorAll(".js-help-btn").forEach(b=>b.addEventListener("click", ()=>{ if(typeof closeDrawer==="function") closeDrawer(); openHelp(); }));
})();

document.addEventListener("click",function(e){
  function setMenu(b,o){b.classList.toggle("open",o);b.nextElementSibling.classList.toggle("open",o);b.setAttribute("aria-expanded",o);}
  var b=e.target.closest(".sb-chev");
  if(b){
    var o=!b.classList.contains("open");
    document.querySelectorAll(".sb-chev.open").forEach(function(c){if(c!==b)setMenu(c,false);});
    setMenu(b,o);
    if(o){
      var m=b.nextElementSibling,box=b.closest(".sidebar,.drawer").getBoundingClientRect(),r=b.getBoundingClientRect(),col=b.closest(".sidebar.collapsed");
      m.style.left=(box.left+(col?8:12))+"px";
      m.style.width=col?"190px":(box.width-24)+"px";
      m.style.bottom=(window.innerHeight-r.top+8)+"px";
    }
    return;
  }
  document.querySelectorAll(".sb-chev.open").forEach(function(c){setMenu(c,false);});
});
