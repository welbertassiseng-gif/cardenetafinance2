/* =========================================================
   AUTENTICAÇÃO (Supabase Auth — conta real, e-mail + senha)
========================================================= */
function showAuthError(msg){
  hideAuthSuccess();
  const el = document.getElementById('authError');
  el.textContent = msg; el.classList.add('show');
}
function supabaseUnavailableMsg(){
  return supabaseLoadError
    ? 'Não foi possível conectar ao servidor agora. Verifique sua internet e recarregue a página.'
    : 'O site ainda não foi conectado ao banco de dados.';
}
function clearAuthError(){
  const el = document.getElementById('authError');
  el.classList.remove('show'); el.textContent = '';
}
function showAuthSuccess(msg){
  clearAuthError();
  const el = document.getElementById('authSuccess');
  el.textContent = msg; el.classList.add('show');
}
function hideAuthSuccess(){
  const el = document.getElementById('authSuccess');
  el.classList.remove('show'); el.textContent = '';
}
function setAuthForm(name){
  document.querySelectorAll('.auth-form').forEach(f=>f.classList.remove('active'));
  const form = document.getElementById(name+'Form');
  if(form) form.classList.add('active');
  clearAuthError(); hideAuthSuccess();
  const tabs = document.getElementById('authTabs');
  if(tabs) tabs.style.display = 'none';
  document.querySelectorAll('.auth-tab').forEach(t=>t.classList.toggle('active', t.dataset.tab===name));
}

/* ---------- olhinho: mostrar/ocultar senha em todos os campos de senha ---------- */
function wirePasswordToggles(){
  const EYE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1.5 12S5.5 5 12 5s10.5 7 10.5 7-4 7-10.5 7S1.5 12 1.5 12z"/><circle cx="12" cy="12" r="3"/></svg>';
  const EYE_OFF = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17.9 17.9A10.6 10.6 0 0 1 12 19C5.5 19 1.5 12 1.5 12a18.5 18.5 0 0 1 4.6-5.4M9.9 5.2A9.9 9.9 0 0 1 12 5c6.5 0 10.5 7 10.5 7a18.6 18.6 0 0 1-2.2 3.2M1 1l22 22"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>';
  document.querySelectorAll('input[type=password]').forEach(inp=>{
    if(inp.dataset.pwWired) return;
    inp.dataset.pwWired = '1';
    const wrap = document.createElement('span');
    wrap.className = 'pw-wrap';
    inp.parentNode.insertBefore(wrap, inp);
    wrap.appendChild(inp);
    const btn = document.createElement('button');
    btn.type = 'button'; btn.className = 'pw-eye';
    const set = (show)=>{
      inp.type = show ? 'text' : 'password';
      btn.innerHTML = show ? EYE_OFF : EYE;
      btn.title = btn.ariaLabel = show ? 'Ocultar senha' : 'Mostrar senha';
      btn.setAttribute('aria-pressed', show ? 'true' : 'false');
    };
    set(false);
    btn.addEventListener('mousedown', e=>e.preventDefault()); // não tira o foco do campo
    btn.addEventListener('click', ()=> set(inp.type === 'password'));
    wrap.appendChild(btn);
    if(inp.form) inp.form.addEventListener('reset', ()=> set(false));
  });
}

/* ---------- link de recuperação de senha ---------- */
function readAuthUrl(){
  const hash = new URLSearchParams((window.location.hash||'').replace(/^#/,''));
  const qs = new URLSearchParams(window.location.search);
  const get = k => hash.get(k) || qs.get(k) || '';
  const type = get('type');
  return {
    type,
    isRecovery: qs.get('reset') === '1' || type === 'recovery',
    isInvite: type === 'invite',   // link do convite enviado pelo painel do Supabase
    errCode: get('error_code') || get('error'),
    errDesc: get('error_description')
  };
}
function cleanAuthUrl(){
  try{ history.replaceState(null, '', window.location.pathname); }catch(e){}
}
function recoveryLinkErrorMsg(u){
  if(/expired|otp/i.test(u.errCode + ' ' + u.errDesc))
    return 'Este link expirou ou já foi usado (convites e links de recuperação valem uma vez só). Se você já tem senha, peça um novo link abaixo; se ainda não criou, peça um novo convite.';
  return 'Não foi possível validar o link. Peça um novo link abaixo.';
}

/* Tela "definir senha": serve para o link de recuperação (esqueci a senha)
   e para o link de convite (primeiro acesso, a pessoa ainda não tem senha). */
let resetMode = 'recovery';
const RESET_TEXTS = {
  recovery:{ l1:'Nova senha',   l2:'Confirme a nova senha', btn:'Salvar nova senha',     done:'Senha alterada! Entrando…' },
  invite:  { l1:'Crie sua senha', l2:'Confirme sua senha',    btn:'Salvar senha e entrar', done:'Senha criada! Entrando…' }
};
function openResetForm(mode){
  resetMode = mode === 'invite' ? 'invite' : 'recovery';
  const t = RESET_TEXTS[resetMode];
  setAuthForm('reset');
  const labels = document.querySelectorAll('#resetForm .auth-field label');
  if(labels[0]) labels[0].textContent = t.l1;
  if(labels[1]) labels[1].textContent = t.l2;
  document.getElementById('resetSubmitBtn').textContent = t.btn;
  if(resetMode === 'invite') showAuthSuccess('Convite aceito! Crie uma senha para entrar no Balance.');
}

function wireAuthForm(){
  // Wire landing screen buttons
  const btnLandingLogin = document.getElementById('btnLandingLogin');
  const btnLandingCta = document.getElementById('btnLandingCta');
  const btnBackToLanding = document.getElementById('btnBackToLanding');
  const landingScreenEl = document.getElementById('landingScreen');
  const authScreenEl = document.getElementById('authScreen');

  function openAuthScreen(mode){
    if(landingScreenEl) landingScreenEl.style.display = 'none';
    if(authScreenEl) authScreenEl.style.display = 'flex';
    setAuthForm(mode || 'login');
  }

  function backToLanding(){
    if(authScreenEl) authScreenEl.style.display = 'none';
    if(landingScreenEl) landingScreenEl.style.display = 'flex';
  }

  if(btnLandingLogin) btnLandingLogin.addEventListener('click', function(){ openAuthScreen('login'); });
  if(btnLandingCta) btnLandingCta.addEventListener('click', function(){ openAuthScreen('login'); });
  if(btnBackToLanding) btnBackToLanding.addEventListener('click', backToLanding);

  document.querySelectorAll('.auth-tab').forEach(tab=>{
    tab.addEventListener('click', ()=> setAuthForm(tab.dataset.tab));
  });
  document.getElementById('btnForgotOpen').addEventListener('click', ()=> setAuthForm('forgot'));
  document.getElementById('btnForgotBack').addEventListener('click', ()=> setAuthForm('login'));

  document.getElementById('loginForm').addEventListener('submit', async (e)=>{
    e.preventDefault();
    if(!supabaseReady) return showAuthError(supabaseUnavailableMsg());
    clearAuthError();
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPass').value;
    const btn = document.getElementById('loginSubmitBtn');
    btn.disabled = true; btn.textContent = 'Entrando…';
    const { data, error } = await sb.auth.signInWithPassword({ email, password });
    btn.disabled = false; btn.textContent = 'Entrar';
    if(error){ showAuthError(traduzErro(error)); return; }
    await enterApp(data.session);
  });


  document.getElementById('forgotForm').addEventListener('submit', async (e)=>{
    e.preventDefault();
    if(!supabaseReady) return showAuthError(supabaseUnavailableMsg());
    clearAuthError();
    const email = document.getElementById('forgotEmail').value.trim();
    if(window.location.protocol === 'file:'){ showAuthError('Abra o site pelo endereço publicado (https://…) para recuperar a senha. Em arquivo local o link do e-mail não consegue voltar para cá.'); return; }
    const btn = document.getElementById('forgotSubmitBtn');
    btn.disabled = true; btn.textContent = 'Enviando…';
    // endereço de retorno limpo (sem ?query nem #hash): precisa estar na lista "Redirect URLs" do Supabase
    const { error } = await sb.auth.resetPasswordForEmail(email, {
      redirectTo: getRedirectUrl()
    });
    btn.disabled = false; btn.textContent = 'Enviar link de recuperação';
    if(error){ showAuthError(traduzErro(error)); return; }
    showAuthSuccess('Se esse e-mail tiver uma conta, enviamos um link de recuperação. Verifique sua caixa de entrada.');
  });

  document.getElementById('resetForm').addEventListener('submit', async (e)=>{
    e.preventDefault();
    clearAuthError();
    const p1 = document.getElementById('resetPass').value;
    const p2 = document.getElementById('resetPass2').value;
    if(p1 !== p2){ showAuthError('As senhas não coincidem.'); return; }
    if(p1.length < 6){ showAuthError('Use pelo menos 6 caracteres.'); return; }
    const btn = document.getElementById('resetSubmitBtn');
    const { data:{ session:rs } } = await sb.auth.getSession();
    if(!rs){ setAuthForm('forgot'); showAuthError('A sessão de recuperação expirou. Peça um novo link abaixo.'); return; }
    btn.disabled = true; btn.textContent = 'Salvando…';
    const { error } = await sb.auth.updateUser({ password: p1 });
    btn.disabled = false; btn.textContent = RESET_TEXTS[resetMode].btn;
    if(error){ showAuthError(traduzErro(error)); return; }
    cleanAuthUrl();
    showAuthSuccess(RESET_TEXTS[resetMode].done);
    setTimeout(async ()=>{
      const { data:{ session:ns } } = await sb.auth.getSession();
      if(ns) enterApp(ns); else setAuthForm('login');
    }, 1200);
  });
}

function traduzErro(error){
  const msg = (error && error.message) || '';
  if(/already registered|already exists/i.test(msg)) return 'Já existe uma conta com esse e-mail. Tente entrar.';
  if(/invalid login credentials/i.test(msg)) return 'E-mail ou senha incorretos.';
  if(/email not confirmed/i.test(msg)) return 'Confirme seu e-mail antes de entrar — verifique sua caixa de entrada.';
  if(/only request this after|security purposes/i.test(msg)) return 'Aguarde cerca de um minuto antes de pedir outro link.';
  if(/rate limit/i.test(msg)) return 'Muitas tentativas seguidas. Aguarde um pouco e tente de novo.';
  if(/network/i.test(msg)) return 'Falha de conexão. Verifique sua internet e tente novamente.';
  return msg || 'Não foi possível concluir. Tente novamente.';
}

