let notifWatcherTimer = null;
let notifLastDay = new Date().toDateString();

async function notificationTick(){
  if(!currentSession) return;
  await refreshStateFromServer();          // traz dados novos de outros aparelhos
  const today = new Date().toDateString();
  if(today !== notifLastDay){ notifLastDay = today; }
  if(state) renderNotifications();         // recalcula e dispara os avisos do navegador
}

function startNotificationWatcher(){
  stopNotificationWatcher();
  if(pushEnabled()) ensureServiceWorker();
  notifWatcherTimer = setInterval(notificationTick, 60*1000);
  document.addEventListener('visibilitychange', onNotifVisibility);
  window.addEventListener('online', notificationTick);
  notificationTick();
}

function onNotifVisibility(){ if(!document.hidden) notificationTick(); }

function stopNotificationWatcher(){
  if(notifWatcherTimer){ clearInterval(notifWatcherTimer); notifWatcherTimer = null; }
  document.removeEventListener('visibilitychange', onNotifVisibility);
  window.removeEventListener('online', notificationTick);
}

