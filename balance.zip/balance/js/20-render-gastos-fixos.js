/* =========================================================
   RENDER: GASTOS FIXOS
========================================================= */
function renderFixos(){
  const el = document.createElement('div');
  const total = state.fixedExpenses.reduce((s,f)=>s+(Number(f.value)||0),0);
  el.innerHTML = `
    <div class="page-header">
      <div><h2>Gastos Fixos</h2><div class="desc">O modelo que se repete todo mês. Use o botão "aplicar gastos fixos" dentro de um mês para importar tudo de uma vez.</div></div>
    </div>
    <div class="card">
      <h3>Modelo de gastos fixos</h3>
      <div class="table-wrap"><table class="responsive-table">
        <thead><tr><th>Descrição</th><th class="num" style="width:130px">Valor mensal</th><th style="width:60px"></th></tr></thead>
        <tbody id="fixedBody"></tbody>
        <tfoot><tr class="total-row"><td>TOTAL</td><td class="num" data-label="Total" id="fixed-total-cell">${fmt(total)}</td><td></td></tr></tfoot>
      </table></div>
      <button class="btn secondary small" id="btnAddFixed" style="margin-top:14px;">+ novo gasto fixo</button>
    </div>
  `;
  const body = el.querySelector('#fixedBody');
  if(state.fixedExpenses.length===0){
    body.innerHTML = `<tr><td colspan="3"><div class="empty-state">Nenhum gasto fixo cadastrado ainda. Clique em "+ novo gasto fixo" para começar.</div></td></tr>`;
  }
  state.fixedExpenses.forEach((f, i)=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td data-label="Descrição"><input type="text" value="${escAttr(f.name)}" data-role="name"></td>
      <td class="num" data-label="Valor"><input type="text" inputmode="decimal" class="money" data-role="value"></td>
      <td><button class="icon-btn" data-role="del">✕</button></td>
    `;
    tr.querySelector('[data-role=name]').addEventListener('input', e=>{ f.name=e.target.value; scheduleSave(); });
    bindMoneyInput(tr.querySelector('[data-role=value]'), ()=>f.value, v=>f.value=v, ()=>{
      const cell = document.getElementById('fixed-total-cell');
      if(cell) cell.textContent = fmt(state.fixedExpenses.reduce((s,x)=>s+(Number(x.value)||0),0));
    });
    tr.querySelector('[data-role=del]').addEventListener('click', ()=>{ state.fixedExpenses.splice(i,1); scheduleSave(); renderSection(); });
    body.appendChild(tr);
  });
  el.querySelector('#btnAddFixed').addEventListener('click', ()=>{
    state.fixedExpenses.push({name:'', value:0}); scheduleSave(); renderSection();
  });
  return el;
}

