/* =========================================================
   RENDER: GASTOS MENSAIS
========================================================= */
const CAT_COLORS = ['#E11D48','#F97316','#EAB308','#22C55E','#0EA5E9','#6366F1','#D946EF','#F43F5E','#14B8A6','#A855F7'];
// Paleta enorme e variada pra escolher a cor de cada categoria (evita cores repetidas/confusas no gráfico)
const CAT_COLOR_PALETTE = [
  '#F87171','#EF4444','#DC2626','#E11D48','#BE123C','#F43F5E','#FB7185',
  '#FB923C','#F97316','#EA580C','#C2410C','#FDBA74',
  '#FBBF24','#F59E0B','#D97706','#EAB308','#CA8A04','#FDE047',
  '#A3E635','#84CC16','#65A30D','#4ADE80','#22C55E','#16A34A','#15803D',
  '#34D399','#10B981','#059669','#047857','#2DD4BF','#14B8A6','#0D9488',
  '#22D3EE','#06B6D4','#0891B2','#0EA5E9','#0284C7','#3B82F6','#2563EB',
  '#60A5FA','#6366F1','#4F46E5','#4338CA','#818CF8','#A78BFA','#8B5CF6',
  '#7C3AED','#A855F7','#9333EA','#C084FC','#D946EF','#C026D3','#A21CAF',
  '#E879F9','#F472B6','#EC4899','#DB2777','#BE185D','#FDA4AF','#FCA5A5',
  '#94A3B8','#64748B','#475569','#78716C','#57534E'
];
function catColor(cat, idx){ return (cat && cat.color) ? cat.color : CAT_COLORS[idx % CAT_COLORS.length]; }
let colorPickerOpenFor = null; // referência da categoria com o seletor de cor aberto
function closeColorPopover(){
  const pop = document.getElementById('colorPopover');
  if(pop) pop.remove();
  document.removeEventListener('mousedown', handleColorPopoverOutsideClick, true);
  colorPickerOpenFor = null;
}
function handleColorPopoverOutsideClick(e){
  const pop = document.getElementById('colorPopover');
  if(pop && !pop.contains(e.target)) closeColorPopover();
}
function openColorPopover(anchorEl, cat, onPick){
  closeColorPopover();
  colorPickerOpenFor = cat;
  const pop = document.createElement('div');
  pop.className = 'color-popover';
  pop.id = 'colorPopover';
  const swatches = CAT_COLOR_PALETTE.map(c=>`<button type="button" class="color-swatch" data-color="${c}" style="background:${c};" title="${c}"></button>`).join('');
  pop.innerHTML = `
    <div class="color-popover-grid">${swatches}</div>
    <div class="color-popover-custom">
      <label for="colorCustomInput">personalizada</label>
      <input type="color" id="colorCustomInput" value="${cat.color || '#888888'}">
    </div>
  `;
  document.body.appendChild(pop);
  const rect = anchorEl.getBoundingClientRect();
  const popW = 240;
  let left = rect.left + window.scrollX;
  if(left + popW > window.scrollX + document.documentElement.clientWidth - 8){
    left = window.scrollX + document.documentElement.clientWidth - popW - 8;
  }
  pop.style.left = Math.max(8, left) + 'px';
  pop.style.top = (rect.bottom + window.scrollY + 6) + 'px';
  pop.querySelectorAll('.color-swatch').forEach(btn=>{
    if(cat.color && cat.color.toLowerCase()===btn.dataset.color.toLowerCase()) btn.classList.add('active');
    btn.addEventListener('click', ()=>{
      onPick(btn.dataset.color);
      closeColorPopover();
    });
  });
  pop.querySelector('#colorCustomInput').addEventListener('input', (e)=>{
    onPick(e.target.value);
  });
  setTimeout(()=>document.addEventListener('mousedown', handleColorPopoverOutsideClick, true), 0);
}
let gastosCollapsedCats = new Set(); // nomes de categorias colapsadas (fica só na memória, não salva)

function buildCategoryRing(categories, total){
  const r = 50, cx = 60, cy = 60, circumference = 2*Math.PI*r;
  if(!total || categories.length===0){
    return `<svg viewBox="0 0 120 120" class="summary-ring"><circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="var(--paper-line)" stroke-width="12"/></svg>`;
  }
  const gapDeg = categories.length>1 ? 3 : 0;
  let cursor = 0;
  const arcs = categories.map((cat,i)=>{
    const val = categoryTotal(cat);
    const frac = total>0 ? val/total : 0;
    const sweep = frac*360;
    const startDeg = cursor;
    cursor += sweep;
    const color = catColor(cat, i);
    const segLen = Math.max((sweep-gapDeg)/360*circumference, 0);
    const restLen = circumference-segLen;
    const rotate = (startDeg-90).toFixed(2);
    return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${color}" stroke-width="12" stroke-linecap="round" stroke-dasharray="${segLen.toFixed(2)} ${restLen.toFixed(2)}" transform="rotate(${rotate} ${cx} ${cy})"/>`;
  }).join('');
  return `<svg viewBox="0 0 120 120" class="summary-ring" role="button" tabindex="0" aria-label="Ver porcentagem por categoria">${arcs}</svg>`;
}

