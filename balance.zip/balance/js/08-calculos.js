/* =========================================================
   CÁLCULOS
========================================================= */
function monthTotal(month){ return month.categories.reduce((sum,c)=> sum + c.items.reduce((s,i)=>s+(Number(i.value)||0),0), 0); }
function categoryTotal(cat){ return cat.items.reduce((s,i)=>s+(Number(i.value)||0),0); }
function salaryTotal(sal){ return sal.items.reduce((s,i)=>s+(Number(i.value)||0),0); }
function receivablesPendingTotal(){ return state.receivables.filter(r=>r.status!=='recebido').reduce((s,r)=>s+(Number(r.valor)||0),0); }
function loanRemaining(loan){ const restantes = Math.max(0, loan.parcelas - loan.parcelasPagas); return restantes * (Number(loan.valorParcela)||0); }
function futureValue(P, PMT, anos, taxaAnualPct){
  const ta = taxaAnualPct/100;
  const im = Math.pow(1+ta, 1/12) - 1;
  const n = anos*12;
  const growth = Math.pow(1+im, n);
  const fromP = P*growth;
  const fromPMT = im===0 ? PMT*n : PMT*((growth-1)/im);
  return fromP + fromPMT;
}
function investmentValue(inv, useHigh){
  if(inv.tipo==='fixo') return Number(inv.valorFixo)||0;
  const taxa = useHigh ? inv.taxaAlta : inv.taxaBaixa;
  return futureValue(Number(inv.valorInicial)||0, Number(inv.aporteMensal)||0, Number(inv.anos)||0, Number(taxa)||0);
}
function investmentsTotal(sectionId, useHigh){ return getInvArray(sectionId).reduce((s,inv)=>s+investmentValue(inv,useHigh),0); }

// Retorna a lista de investimentos da seção informada. 'investimentos' é a aba original (compatível com dados
// já salvos); qualquer outro id é uma seção duplicada, guardada à parte em state.investmentSections.
function getInvArray(sectionId){
  if(sectionId==='investimentos'){
    if(!Array.isArray(state.investments)) state.investments = [];
    return state.investments;
  }
  if(!state.investmentSections) state.investmentSections = {};
  if(!Array.isArray(state.investmentSections[sectionId])) state.investmentSections[sectionId] = [];
  return state.investmentSections[sectionId];
}

