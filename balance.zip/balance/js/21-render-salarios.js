/* =========================================================
   RENDER: SALÁRIOS
========================================================= */
function renderSalarios(){
  const el = document.createElement('div');
  if(!state.months.find(m=>m.id===state.selectedMonth) && state.months.length){
    state.selectedMonth = pickDefaultMonthId();
  }
  const month = state.months.find(m=>m.id===state.selectedMonth);
  let sal = state.salaries.find(s=>s.monthId===state.selectedMonth);

  el.innerHTML = `
    <div class="page-header">
      <div><h2>Salários</h2><div class="desc">Horas extras calculam o valor sozinhas (valor da hora × quantidade de horas). O total soma automaticamente.</div></div>
    </div>
    <div class="toolbar">
      <select class="tag-select" id="monthSelect"></select>
      ${!sal && month ? `<button class="btn gold small" id="btnCreateSal">criar salário deste mês</button>` : ''}
    </div>
    <div id="salContent"></div>
  `;
  const sel = el.querySelector('#monthSelect');
  sel.innerHTML = state.months.map(m=>`<option value="${m.id}" ${m.id===state.selectedMonth?'selected':''}>${escapeHtml(m.label)}</option>`).join('');
  sel.addEventListener('change', ()=>{ state.selectedMonth = sel.value; renderSection(); });

  const createBtn = el.querySelector('#btnCreateSal');
  if(createBtn){
    createBtn.addEventListener('click', ()=>{
      state.salaries.push({monthId: month.id, items:[{desc:'Salário', valorHE:null, horas:null, value:0}]});
      scheduleSave(); renderSection();
    });
  }

  const content = el.querySelector('#salContent');
  if(!month){
    content.innerHTML = `<div class="card"><div class="empty-state">Cadastre um mês em "Despesas" primeiro.</div></div>`;
    return el;
  }
  if(!sal){
    content.innerHTML = `<div class="card"><div class="empty-state">Ainda não há salário lançado para ${escapeHtml(month.label)}.</div></div>`;
    return el;
  }

  const total = salaryTotal(sal);
  const card = document.createElement('div');
  card.className = 'card';
  card.innerHTML = `
    <h3>${escapeHtml(month.label)} ${eyeToggleBtn()}</h3>
    <div class="table-wrap"><table class="responsive-table">
      <thead><tr><th>Descrição</th><th class="num" style="width:100px">Valor h.e.</th><th class="num" style="width:90px">Horas</th><th class="num" style="width:120px">Valor</th><th style="width:50px"></th></tr></thead>
      <tbody id="salBody"></tbody>
      <tfoot><tr class="total-row"><td colspan="3">TOTAL</td><td class="num" data-label="Total" id="sal-total-cell">${fmtPriv(total)}</td><td></td></tr></tfoot>
    </table></div>
    <button class="btn secondary small" id="btnAddSalItem" style="margin-top:14px;">+ novo item</button>
  `;
  content.appendChild(card);
  bindEyeToggles(card);
  const body = card.querySelector('#salBody');
  sal.items.forEach((item,i)=>{
    const isHE = item.valorHE !== null && item.valorHE !== undefined;
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="cell-plain"><input type="text" value="${escAttr(item.desc)}" data-role="desc"></td>
      <td class="num" data-label="Valor h.e."><input type="text" inputmode="decimal" class="money" placeholder="—" data-role="valorHE"></td>
      <td class="num" data-label="Horas"><input type="text" inputmode="decimal" class="money" placeholder="—" data-role="horas"></td>
      <td class="num" data-label="Valor"><input type="text" inputmode="decimal" class="money" data-role="value" id="sal-value-${i}" ${isHE?'readonly style="color:var(--ink-soft)"':''}></td>
      <td><button class="icon-btn" data-role="del">✕</button></td>
    `;
    tr.querySelector('[data-role=desc]').addEventListener('input', e=>{ item.desc=e.target.value; scheduleSave(); });
    const heInput = tr.querySelector('[data-role=valorHE]');
    const heDisplay = ()=> item.valorHE===null||item.valorHE===undefined ? '' : moneyDisplay(item.valorHE);
    heInput.value = (privacyMode && heDisplay()!=='') ? PRIV_MASK : heDisplay();
    heInput.addEventListener('focus', ()=>{ if(privacyMode) heInput.value = heDisplay(); });
    heInput.addEventListener('input', e=>{
      item.valorHE = e.target.value===''? null : parseMoney(e.target.value);
      if(item.valorHE!==null && item.horas) item.value = round2(item.valorHE*item.horas);
      scheduleSave(); recalcSalarios(sal, i);
    });
    heInput.addEventListener('blur', e=>{ e.target.value = (privacyMode && heDisplay()!=='') ? PRIV_MASK : heDisplay(); });

    const horasInput = tr.querySelector('[data-role=horas]');
    horasInput.value = item.horas===null||item.horas===undefined ? '' : moneyDisplay(item.horas);
    horasInput.addEventListener('input', e=>{
      item.horas = e.target.value===''? null : parseMoney(e.target.value);
      if(item.valorHE!==null && item.horas) item.value = round2(item.valorHE*item.horas);
      scheduleSave(); recalcSalarios(sal, i);
    });
    horasInput.addEventListener('blur', e=>{ e.target.value = item.horas===null||item.horas===undefined?'':moneyDisplay(item.horas); });

    if(!isHE){
      bindMoneyInputPriv(tr.querySelector('[data-role=value]'), ()=>item.value, v=>item.value=v, ()=>{
        const cell = document.getElementById('sal-total-cell');
        if(cell) cell.textContent = fmtPriv(salaryTotal(sal));
      });
    } else {
      const valInput = tr.querySelector('[data-role=value]');
      valInput.value = privacyMode ? PRIV_MASK : moneyDisplay(item.value);
      valInput.addEventListener('focus', ()=>{ if(privacyMode) valInput.value = moneyDisplay(item.value); });
      valInput.addEventListener('blur', ()=>{ if(privacyMode) valInput.value = PRIV_MASK; });
    }
    tr.querySelector('[data-role=del]').addEventListener('click', ()=>{ sal.items.splice(i,1); scheduleSave(); renderSection(); });
    body.appendChild(tr);
  });
  card.querySelector('#btnAddSalItem').addEventListener('click', ()=>{
    sal.items.push({desc:'', valorHE:null, horas:null, value:0}); scheduleSave(); renderSection();
  });

  return el;
}
function round2(n){ return Math.round(n*100)/100; }
function recalcSalarios(sal, i){
  const valInput = document.getElementById('sal-value-'+i);
  if(valInput){
    const focused = document.activeElement===valInput;
    valInput.value = (privacyMode && !focused) ? PRIV_MASK : moneyDisplay(sal.items[i].value);
  }
  const totalCell = document.getElementById('sal-total-cell');
  if(totalCell) totalCell.textContent = fmtPriv(salaryTotal(sal));
}

