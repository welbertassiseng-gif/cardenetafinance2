/* =========================================================
   RENDER: INVESTIMENTO REAL — simulador mês a mês, editável em linha
========================================================= */
let chartRealInvestRef = null;

function riMoneyFmt2(n){
  // sempre "R$ 1.234,56" com 2 casas — usa o fmt() padrão do app (já é pt-BR/BRL)
  return fmt(n);
}
function riRateFmt2(taxa){
  const n = Number(taxa) || 0;
  return n.toLocaleString('pt-BR', {minimumFractionDigits:2, maximumFractionDigits:2});
}

function renderRealInvest(sectionId){
  sectionId = sectionId || 'realInvest';
  const el = document.createElement('div');
  const cfg = state.navConfig.find(n=>n.id===sectionId);
  const title = cfg ? cfg.label : 'Investimento Real';
  const ri = getRIData(sectionId);
  const result = computeRealInvestSchedule(sectionId);
  const hasMonths = ri.months.length > 0;

  el.innerHTML = `
    <div class="page-header">
      <div>
        <h2>${escapeHtml(title)}</h2>
        <div class="desc">Simulador de juros compostos mês a mês. Edite qualquer aporte ou taxa e tudo recalcula sozinho — inclusive os meses seguintes.</div>
      </div>
    </div>

    <div class="card">
      <h3>Valor inicial <span class="hint">o que você já tem, antes dos aportes mensais</span></h3>
      <input type="text" inputmode="decimal" class="modal-money" id="riInitialValue" style="max-width:260px; font-size:17px; padding:12px 13px;">
    </div>

    <div class="grid-3" style="margin-top:4px;">
      <div class="stat"><div class="label">Valor inicial</div><div class="value mono" id="ri-card-initial">${fmt(result.initial)}</div></div>
      <div class="stat"><div class="label">Total aportado</div><div class="value mono" id="ri-card-aportado">${fmt(result.totalAportado)}</div></div>
      <div class="stat pos"><div class="label">Rendimento total</div><div class="value mono" id="ri-card-rendimento">${fmt(result.rendimentoTotal)}</div></div>
    </div>
    <div class="grid-3" style="margin-top:14px;">
      <div class="stat pos" style="grid-column:1/-1;"><div class="label">Montante atual</div><div class="value mono" id="ri-card-montante" style="font-size:26px;">${fmt(result.montanteAtual)}</div></div>
    </div>

    <div class="card" style="margin-top:22px;">
      <h3>Evolução do patrimônio</h3>
      <div id="riChartCardBody">
        ${!hasMonths ? `
          <div class="empty-state">Adicione ao menos um mês para ver a curva de crescimento do patrimônio.</div>
        ` : `
          <div class="chart-wrap" id="riChartWrap">
            <div class="chart-skeleton" id="riChartSkeleton">
              <div class="skel-bars"><span></span><span></span><span></span><span></span><span></span></div>
              <div class="skel-label">carregando gráfico…</div>
            </div>
            <canvas id="chartRealInvest" style="display:none;"></canvas>
          </div>
        `}
      </div>
    </div>

    <div class="card">
      <h3>Simulação mês a mês <span class="hint">${ri.months.length} mês${ri.months.length===1?'':'es'}</span></h3>
      <div class="table-wrap"><table class="responsive-table">
        <thead><tr>
          <th style="width:150px">Mês</th>
          <th class="num">Saldo inicial</th>
          <th class="num" style="width:120px">Aporte</th>
          <th class="num" style="width:150px">Taxa</th>
          <th class="num">Rendimento</th>
          <th class="num">Montante</th>
          <th style="width:50px"></th>
        </tr></thead>
        <tbody id="riMonthsBody"></tbody>
      </table></div>
      <button class="btn secondary small" id="btnAddMonth" style="margin-top:14px;">+ Adicionar mês</button>
      <div class="small-note">Taxa anual é convertida matematicamente para o mês: (1 + taxa anual)^(1/12) − 1. O saldo inicial de cada mês é sempre o montante do mês anterior — não é editável, porque é resultado do cálculo.</div>
    </div>
  `;

  // ---- Valor inicial ----
  const recalc = ()=>recalcRealInvest(sectionId);
  const initialInput = el.querySelector('#riInitialValue');
  bindMoneyInput(initialInput, ()=>ri.initialValue, v=>{ ri.initialValue = v; }, recalc);

  // ---- Linhas de meses ----
  const body = el.querySelector('#riMonthsBody');
  if(!hasMonths){
    body.innerHTML = `<tr><td colspan="7"><div class="empty-state">Nenhum mês cadastrado ainda. Clique em "+ Adicionar mês" para começar.</div></td></tr>`;
  }
  result.rows.forEach((row, i)=>{
    const m = ri.months[i];
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="cell-plain"><input type="month" value="${escAttr(m.monthKey)}" data-role="monthKey"></td>
      <td class="num" data-label="Saldo inicial" id="ri-saldoinicial-${i}" style="color:var(--ink-soft);">${fmt(row.saldoInicial)}</td>
      <td class="num" data-label="Aporte"><input type="text" inputmode="decimal" class="money" data-role="aporte"></td>
      <td data-label="Taxa" style="display:flex; gap:6px; align-items:center; justify-content:flex-end;">
        <input type="text" inputmode="decimal" class="money" data-role="taxa" style="max-width:70px;">
        <select data-role="tipoTaxa" style="width:auto; min-width:76px;">
          <option value="anual" ${m.tipoTaxa!=='mensal'?'selected':''}>a.a.</option>
          <option value="mensal" ${m.tipoTaxa==='mensal'?'selected':''}>a.m.</option>
        </select>
      </td>
      <td class="num mono" data-label="Rendimento" id="ri-rendimento-${i}" style="color:var(--forest);">${fmt(row.rendimento)}</td>
      <td class="num mono" data-label="Montante" id="ri-montante-${i}" style="font-weight:600;">${fmt(row.montante)}</td>
      <td><button class="icon-btn" data-role="delMonth" title="excluir mês">✕</button></td>
    `;
    tr.querySelector('[data-role=monthKey]').addEventListener('change', e=>{
      m.monthKey = e.target.value; scheduleSave(); recalc();
    });
    bindMoneyInput(tr.querySelector('[data-role=aporte]'), ()=>m.aporte, v=>{ m.aporte=v; }, recalc);
    bindMoneyInput(tr.querySelector('[data-role=taxa]'), ()=>m.taxa, v=>{ m.taxa=v; }, recalc);
    tr.querySelector('[data-role=tipoTaxa]').addEventListener('change', e=>{
      m.tipoTaxa = e.target.value; scheduleSave(); recalc();
    });
    tr.querySelector('[data-role=delMonth]').addEventListener('click', ()=>{
      if(!confirm(`Excluir ${riFormatMonthLabel(m.monthKey)}? Os meses seguintes serão recalculados.`)) return;
      ri.months.splice(i,1);
      scheduleSave(); renderSection();
    });
    body.appendChild(tr);
  });

  el.querySelector('#btnAddMonth').addEventListener('click', ()=>{
    const last = ri.months[ri.months.length-1];
    const nextKey = last ? riNextMonthKey(last.monthKey) : riMonthKeyNow();
    ri.months.push({ id: uid(), monthKey: nextKey, aporte: 0, taxa: 0, tipoTaxa: 'anual' });
    scheduleSave(); renderSection();
  });

  return el;
}

// Recalcula tudo (cards, cada linha, gráfico) sem reconstruir os campos — mantém o foco ao digitar.
function recalcRealInvest(sectionId){
  const result = computeRealInvestSchedule(sectionId);

  const elInit = document.getElementById('ri-card-initial'); if(elInit) elInit.textContent = fmt(result.initial);
  const elAport = document.getElementById('ri-card-aportado'); if(elAport) elAport.textContent = fmt(result.totalAportado);
  const elRend = document.getElementById('ri-card-rendimento'); if(elRend) elRend.textContent = fmt(result.rendimentoTotal);
  const elMont = document.getElementById('ri-card-montante'); if(elMont) elMont.textContent = fmt(result.montanteAtual);

  result.rows.forEach((row,i)=>{
    const si = document.getElementById('ri-saldoinicial-'+i); if(si) si.textContent = fmt(row.saldoInicial);
    const rend = document.getElementById('ri-rendimento-'+i); if(rend) rend.textContent = fmt(row.rendimento);
    const mont = document.getElementById('ri-montante-'+i); if(mont) mont.textContent = fmt(row.montante);
  });

  updateRealInvestChart(result);
}

function drawRealInvestChart(sectionId){
  const canvas = document.getElementById('chartRealInvest');
  const skeleton = document.getElementById('riChartSkeleton');
  if(!canvas) return;
  if(privacyMode){ // modo privado: ocultar projeção de investimento real
    if(chartRealInvestRef){ chartRealInvestRef.destroy(); chartRealInvestRef=null; }
    canvas.style.display = 'none';
    if(skeleton){ skeleton.style.display = 'flex'; skeleton.innerHTML = `<div class="empty-state" style="padding:44px 16px;">🔒 Valores ocultos — toque no olhinho para mostrar o gráfico.</div>`; }
    return;
  }
  try{
    if(typeof Chart === 'undefined') throw new Error('Chart.js indisponível');
    const result = computeRealInvestSchedule(sectionId);
    const labels = result.rows.map(r=>riFormatMonthLabel(r.monthKey));
    const aportadoAcumulado = [];
    let acc = 0;
    result.rows.forEach(r=>{ acc += r.aporte; aportadoAcumulado.push(acc); });
    const montanteData = result.rows.map(r=>r.montante);

    if(chartRealInvestRef){ chartRealInvestRef.destroy(); chartRealInvestRef=null; }
    chartRealInvestRef = new Chart(canvas.getContext('2d'), {
      type:'line',
      data:{ labels, datasets:[
        {label:'Aportado (acumulado)', data:aportadoAcumulado, borderColor:'#94A3B8', backgroundColor:'rgba(148,163,184,0.08)', borderDash:[4,3], tension:0.15, pointRadius:3, borderWidth:2},
        {label:'Patrimônio (com juros)', data:montanteData, borderColor:'#3B82F6', backgroundColor:'rgba(59,130,246,0.12)', fill:true, tension:0.25, pointRadius:3, borderWidth:2.5},
      ]},
      options:{
        responsive:true, maintainAspectRatio:false,
        plugins:{legend:{labels:{font:{family:'JetBrains Mono', size:11}}}},
        scales:{
          y:{ticks:{font:{family:'JetBrains Mono', size:10}}, grid:{color:'#E2E8F0'}, beginAtZero:true},
          x:{ticks:{font:{family:'JetBrains Mono', size:10}, maxRotation:0, autoSkip:true, maxTicksLimit:8}, grid:{display:false}}
        }
      }
    });
    if(skeleton) skeleton.style.display='none';
    canvas.style.display='block';
  }catch(err){
    console.error('Erro ao renderizar gráfico de Investimento Real:', err);
    const body = document.getElementById('riChartCardBody');
    if(body) body.innerHTML = `<div class="empty-state">Não foi possível carregar o gráfico agora. Recarregue a página.</div>`;
  }
}

// Atualiza o gráfico já existente em tempo real (sem destruir/recriar) enquanto o usuário digita.
function updateRealInvestChart(result){
  if(!chartRealInvestRef) return;
  const labels = result.rows.map(r=>riFormatMonthLabel(r.monthKey));
  const aportadoAcumulado = [];
  let acc = 0;
  result.rows.forEach(r=>{ acc += r.aporte; aportadoAcumulado.push(acc); });
  const montanteData = result.rows.map(r=>r.montante);
  chartRealInvestRef.data.labels = labels;
  chartRealInvestRef.data.datasets[0].data = aportadoAcumulado;
  chartRealInvestRef.data.datasets[1].data = montanteData;
  chartRealInvestRef.update('none');
}

