/* =========================================================
   RENDER: BLOCO DE NOTAS — várias notas, estilo "Notas" do iPhone
========================================================= */
let notesOpenId = null; // id da nota aberta pra edição (null = lista)

function migrateNotes(){
  if(!Array.isArray(state.notesList)){
    state.notesList = [];
    if(typeof state.notes === 'string' && state.notes.trim()){
      state.notesList.push({ id: uid(), title:'', body: state.notes, updatedAt: new Date().toISOString() });
    }
    delete state.notes;
    scheduleSave();
  }
}
function noteDisplayTitle(n){
  if(n.title && n.title.trim()) return n.title.trim();
  const lines = String(n.body||'').split('\n');
  return lines[0].trim() || 'Nova nota';
}

function formatNoteDate(iso){
  try{
    const d = new Date(iso);
    const data = d.toLocaleDateString('pt-BR', {day:'2-digit', month:'short', year:'numeric'});
    const hora = d.toLocaleTimeString('pt-BR', {hour:'2-digit', minute:'2-digit'});
    return `${data} · ${hora}`;
  }catch(e){ return ''; }
}

function renderNotas(){
  migrateNotes();
  const el = document.createElement('div');
  if(notesOpenId && state.notesList.find(n=>n.id===notesOpenId)){
    renderNoteEditor(el);
  } else {
    notesOpenId = null;
    renderNotesList(el);
  }
  return el;
}

function renderNotesList(el){
  const notes = [...state.notesList].sort((a,b)=> new Date(b.updatedAt) - new Date(a.updatedAt));
  el.innerHTML = `
    <div class="page-header">
      <div><h2>Bloco de Notas</h2><div class="desc">Um espaço livre pra anotações — lembretes, ideias, o que quiser.</div></div>
    </div>
    <button class="btn secondary small" id="btnNewNote" style="margin-bottom:16px;">+ nova nota</button>
    <div id="notesListWrap"></div>
  `;
  const wrap = el.querySelector('#notesListWrap');
  if(notes.length===0){
    wrap.innerHTML = `<div class="card" style="text-align:center; color:var(--ink-soft);">Nenhuma nota ainda. Toque em "+ nova nota" pra começar.</div>`;
  } else {
    notes.forEach(n=>{
      const title = noteDisplayTitle(n);
      const hasCustomTitle = !!(n.title && n.title.trim());
      const bodyLines = String(n.body||'').split('\n');
      const snippet = (hasCustomTitle ? bodyLines : bodyLines.slice(1)).join(' ').trim();
      const card = document.createElement('div');
      card.className = 'card note-card';
      card.innerHTML = `
        <div class="note-card-body">
          <h4 class="note-title">${escapeHtml(title)}</h4>
          <div class="note-meta">${formatNoteDate(n.updatedAt)}${snippet ? ' — ' + escapeHtml(snippet.slice(0,90)) : ''}</div>
        </div>
        <button class="nhi-trash-btn note-trash" data-delnote="${escAttr(n.id)}" title="excluir nota">🗑</button>
      `;
      card.querySelector('.note-card-body').addEventListener('click', ()=>{ notesOpenId = n.id; renderSection(); });
      card.querySelector('[data-delnote]').addEventListener('click', async (e)=>{
        e.stopPropagation();
        if(!confirm(`Excluir a nota "${title}"?`)) return;
        state.notesList = state.notesList.filter(x=>x.id!==n.id);
        renderSection();
        await persistState();
      });
      wrap.appendChild(card);
    });
  }
  el.querySelector('#btnNewNote').addEventListener('click', ()=>{
    const note = { id: uid(), title:'', body:'', updatedAt: new Date().toISOString() };
    state.notesList.unshift(note);
    notesOpenId = note.id;
    scheduleSave();
    renderSection();
  });
}

function renderNoteEditor(el){
  const note = state.notesList.find(n=>n.id===notesOpenId);
  el.innerHTML = `
    <div class="page-header">
      <div>
        <button class="btn secondary small" id="btnBackNotes">← todas as notas</button>
        <div class="desc" id="noteUpdatedLabel" style="margin-top:10px;">${formatNoteDate(note.updatedAt)}</div>
      </div>
      <button class="nhi-trash-btn" id="btnDeleteNote" title="excluir nota" style="font-size:17px;">🗑</button>
    </div>
    <div class="card">
      <input type="text" id="noteTitle" style="width:100%; border:none; padding:0 0 10px; margin-bottom:10px; border-bottom:1px solid var(--paper-line); font-family:'Space Grotesk',sans-serif; font-weight:700; font-size:19px; color:var(--forest); background:none;" placeholder="Título da nota (opcional)">
      <textarea id="noteBody" style="width:100%; min-height:400px; border:none; padding:0; font-family:'DM Sans',sans-serif; font-size:15px; line-height:1.6; color:var(--ink); resize:vertical; background:none;" placeholder="Escreva aqui…"></textarea>
    </div>
  `;
  const titleInput = el.querySelector('#noteTitle');
  titleInput.value = note.title || '';
  titleInput.addEventListener('input', ()=>{
    note.title = titleInput.value;
    note.updatedAt = new Date().toISOString();
    const lbl = el.querySelector('#noteUpdatedLabel');
    if(lbl) lbl.textContent = formatNoteDate(note.updatedAt);
    scheduleSave();
  });
  const ta = el.querySelector('#noteBody');
  ta.value = note.body;
  ta.addEventListener('input', ()=>{
    note.body = ta.value;
    note.updatedAt = new Date().toISOString();
    const lbl = el.querySelector('#noteUpdatedLabel');
    if(lbl) lbl.textContent = formatNoteDate(note.updatedAt);
    scheduleSave();
  });
  el.querySelector('#btnBackNotes').addEventListener('click', ()=>{ notesOpenId = null; renderSection(); });
  el.querySelector('#btnDeleteNote').addEventListener('click', async ()=>{
    if(!confirm('Excluir esta nota?')) return;
    state.notesList = state.notesList.filter(n=>n.id!==note.id);
    notesOpenId = null;
    renderSection();
    await persistState();
  });
  setTimeout(()=>ta.focus(), 0);
}

