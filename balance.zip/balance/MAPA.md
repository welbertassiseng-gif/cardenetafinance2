# Balance — mapa dos arquivos

Abra `index.html` (tem só o HTML das telas). Estilos em `css/`, lógica em `js/`, imagens em `assets/`.
**Suba a pasta inteira** na hospedagem (não só o index.html).

## Ordem dos scripts (importa!)
Os arquivos `js/` são scripts comuns que compartilham o mesmo escopo global e são carregados na ordem do número.
Funções/variáveis de um arquivo podem ser usadas por qualquer outro, mas **código que roda na hora do carregamento**
só pode usar o que está em arquivos de número menor. `99-iniciar.js` precisa ser sempre o último.

## JavaScript
| Arquivo | Linhas | Conteúdo |
|---|---|---|
| `js/01-config-supabase.js` | 34 | CONFIGURAÇÃO DO SUPABASE |
| `js/02-helpers.js` | 71 | HELPERS GERAIS |
| `js/03-estado.js` | 42 | ESTADO |
| `js/04-sidebar-recolhivel.js` | 20 | BARRA LATERAL RECOLHÍVEL (desktop) |
| `js/05-desfazer-refazer.js` | 92 | DESFAZER / REFAZER |
| `js/06-sincronizacao.js` | 187 | SINCRONIZAÇÃO ENTRE DISPOSITIVOS |
| `js/07-menu-lateral.js` | 382 | MENU LATERAL — editável, com exclusão e restauração |
| `js/08-calculos.js` | 36 | CÁLCULOS |
| `js/09-investimento-real-simulador.js` | 132 | INVESTIMENTO REAL — simulador sequencial mês a mês |
| `js/10-notificacoes.js` | 264 | NOTIFICAÇÕES — alertas reais calculados a partir dos dados |
| `js/11-render-inicio.js` | 184 | RENDER: INÍCIO (com seletor de mês) |
| `js/12-render-gastos-mensais.js` | 88 | RENDER: GASTOS MENSAIS |
| `js/13-despesas-1-icones-e-dados.js` | 291 | RENDER: GASTOS MENSAIS (Despesas) — Todas · Categorias · Detalhe da categoria |
| `js/14-despesas-2-resumo-modais-menu.js` | 153 |  |
| `js/15-despesas-3-acoes-categoria.js` | 222 |  |
| `js/16-despesas-4-transacoes-parcelas.js` | 200 |  |
| `js/17-despesas-5-filtros-e-lista.js` | 180 |  |
| `js/18-despesas-6-visoes.js` | 231 |  |
| `js/19-despesas-7-pagina.js` | 115 |  |
| `js/20-render-gastos-fixos.js` | 45 | RENDER: GASTOS FIXOS |
| `js/21-render-salarios.js` | 120 | RENDER: SALÁRIOS |
| `js/22-render-a-receber.js` | 117 | RENDER: DINHEIRO A RECEBER |
| `js/23-render-investimentos.js` | 120 | RENDER: INVESTIMENTOS |
| `js/24-render-carteira.js` | 462 | RENDER: CARTEIRA DE INVESTIMENTOS — saldo por item, aporte/retirada com histórico, |
| `js/25-render-bloco-notas.js` | 133 | RENDER: BLOCO DE NOTAS — várias notas, estilo "Notas" do iPhone |
| `js/26-render-secao-custom.js` | 48 | RENDER: SEÇÃO PERSONALIZADA (criada pelo usuário no menu) |
| `js/27-render-investimento-real.js` | 211 | RENDER: INVESTIMENTO REAL — simulador mês a mês, editável em linha |
| `js/28-roteador.js` | 39 | ROTEADOR DE SEÇÕES |
| `js/29-auth.js` | 199 | AUTENTICAÇÃO (Supabase Auth — conta real, e-mail + senha) |
| `js/30-tema.js` | 18 | TEMA (claro / escuro) |
| `js/31-modal-configuracoes.js` | 64 | MODAL DE CONFIGURAÇÕES |
| `js/32-boot-e-entrar-no-app.js` | 79 |  |
| `js/33-botoes-do-app.js` | 102 |  |
| `js/34-vigia-notificacoes.js` | 28 |  |
| `js/35-ajuda.js` | 181 | AJUDA — guia "Como usar" + dúvidas frequentes + busca |
| `js/99-iniciar.js` | 5 | BOOT |

## CSS
| Arquivo | Linhas |
|---|---|
| `css/01-base.css` | 439 |
| `css/02-app-mobile.css` | 157 |
| `css/03-modal.css` | 22 |
| `css/04-redesign.css` | 124 |
| `css/05-landing.css` | 203 |
| `css/06-despesas.css` | 278 |
| `css/07-ajuda.css` | 51 |

## Onde mexer em cada assunto
- Convite / esqueci a senha / login: `js/29-auth.js` (telas e envio), `js/32-boot-e-entrar-no-app.js` (leitura do link do e-mail), `js/01-config-supabase.js` (chaves e `SITE_URL`)
- Telas de login/landing (HTML): `index.html` (`landingScreen`, `authScreen`)
- Menu lateral: `js/07-menu-lateral.js` · Despesas: `js/13` a `js/19` · Ajuda: `js/35-ajuda.js`
